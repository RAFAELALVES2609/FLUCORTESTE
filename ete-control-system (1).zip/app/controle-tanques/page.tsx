"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import { Download, Save } from "lucide-react"

// Tipos para os tanques
type TanqueVolume = {
  id: string
  nome: string
  volumeA: string
  volumeB: string
  volumeC: string
  diferenca: string
}

export default function ControleTanques() {
  const { toast } = useToast()
  const [turno, setTurno] = useState("A")
  const [data, setData] = useState(new Date().toISOString().split("T")[0])

  // Estado inicial para os tanques
  const [tanquesOleosos, setTanquesOleosos] = useState<TanqueVolume[]>([
    { id: "TQ31", nome: "TQ 31", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ32", nome: "TQ 32", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ33", nome: "TQ 33", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ34", nome: "TQ 34", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ35", nome: "TQ 35", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
  ])

  const [tanquesFisicoQuimico, setTanquesFisicoQuimico] = useState<TanqueVolume[]>([
    { id: "TQ41", nome: "TQ 41", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ42", nome: "TQ 42", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ43", nome: "TQ 43", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ44", nome: "TQ 44", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ51", nome: "TQ 51", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ52", nome: "TQ 52", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ53", nome: "TQ 53", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
  ])

  const [tanquesConcentrado, setTanquesConcentrado] = useState<TanqueVolume[]>([
    { id: "TQ61", nome: "TQ 61", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
  ])

  const [tanquesTratamentoLodo, setTanquesTratamentoLodo] = useState<TanqueVolume[]>([
    { id: "TL01", nome: "TL 01", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TL02", nome: "TL 02", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
  ])

  const [tanquesBiologico, setTanquesBiologico] = useState<TanqueVolume[]>([
    { id: "TQ71", nome: "TQ 71", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ72", nome: "TQ 72", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
  ])

  const [tanquesTerciario, setTanquesTerciario] = useState<TanqueVolume[]>([
    { id: "TQ73", nome: "TQ 73", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ74", nome: "TQ 74", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
    { id: "TQ75", nome: "TQ 75", volumeA: "", volumeB: "", volumeC: "", diferenca: "" },
  ])

  // Calcular diferenças quando os volumes são atualizados
  useEffect(() => {
    const calcularDiferencas = (tanques: TanqueVolume[]) => {
      return tanques.map((tanque) => {
        const volumeA = Number.parseFloat(tanque.volumeA) || 0
        const volumeC = Number.parseFloat(tanque.volumeC) || 0
        const diferenca = (volumeC - volumeA).toFixed(2)
        return { ...tanque, diferenca: diferenca.toString() }
      })
    }

    // Usar uma função de atualização de estado que não depende do estado atual
    // Isso evita o loop infinito
    const atualizarDiferencas = () => {
      setTanquesOleosos((prev) => {
        const novoEstado = calcularDiferencas(prev)
        // Comparar se realmente houve mudança para evitar atualizações desnecessárias
        return JSON.stringify(novoEstado) !== JSON.stringify(prev) ? novoEstado : prev
      })

      setTanquesFisicoQuimico((prev) => {
        const novoEstado = calcularDiferencas(prev)
        return JSON.stringify(novoEstado) !== JSON.stringify(prev) ? novoEstado : prev
      })

      setTanquesConcentrado((prev) => {
        const novoEstado = calcularDiferencas(prev)
        return JSON.stringify(novoEstado) !== JSON.stringify(prev) ? novoEstado : prev
      })

      setTanquesTratamentoLodo((prev) => {
        const novoEstado = calcularDiferencas(prev)
        return JSON.stringify(novoEstado) !== JSON.stringify(prev) ? novoEstado : prev
      })

      setTanquesBiologico((prev) => {
        const novoEstado = calcularDiferencas(prev)
        return JSON.stringify(novoEstado) !== JSON.stringify(prev) ? novoEstado : prev
      })

      setTanquesTerciario((prev) => {
        const novoEstado = calcularDiferencas(prev)
        return JSON.stringify(novoEstado) !== JSON.stringify(prev) ? novoEstado : prev
      })
    }

    atualizarDiferencas()
    // Executar apenas quando os valores de volume mudarem
  }, [])

  // Atualizar volume de um tanque
  const atualizarVolume = (
    id: string,
    valor: string,
    turnoAtual: string,
    setTanques: React.Dispatch<React.SetStateAction<TanqueVolume[]>>,
  ) => {
    setTanques((prev) => {
      const tanquesAtualizados = prev.map((tanque) => {
        if (tanque.id === id) {
          const tanqueAtualizado = {
            ...tanque,
            ...(turnoAtual === "A" ? { volumeA: valor } : turnoAtual === "B" ? { volumeB: valor } : { volumeC: valor }),
          }

          // Calcular diferença imediatamente
          const volumeA = Number.parseFloat(turnoAtual === "A" ? valor : tanque.volumeA) || 0
          const volumeC = Number.parseFloat(turnoAtual === "C" ? valor : tanque.volumeC) || 0
          tanqueAtualizado.diferenca = (volumeC - volumeA).toFixed(2)

          return tanqueAtualizado
        }
        return tanque
      })

      return tanquesAtualizados
    })
  }

  const salvarDados = () => {
    toast({
      title: "Dados salvos com sucesso!",
      description: `Volumes do turno ${turno} atualizados para ${data}.`,
    })
  }

  const gerarRelatorio = () => {
    toast({
      title: "Relatório gerado!",
      description: "O relatório diário foi gerado e está disponível para download.",
    })
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Controle Físico dos Tanques</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="w-full md:w-1/3">
          <Label htmlFor="data">Data</Label>
          <Input id="data" type="date" value={data} onChange={(e) => setData(e.target.value)} />
        </div>
        <div className="w-full md:w-1/3">
          <Label htmlFor="turno">Turno</Label>
          <Select value={turno} onValueChange={setTurno}>
            <SelectTrigger id="turno">
              <SelectValue placeholder="Selecione o turno" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="A">Turno A</SelectItem>
              <SelectItem value="B">Turno B</SelectItem>
              <SelectItem value="C">Turno C</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="w-full md:w-1/3 flex items-end">
          <Button onClick={salvarDados} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Salvar Dados
          </Button>
        </div>
      </div>

      <Tabs defaultValue="oleosos" className="w-full">
        <TabsList className="grid grid-cols-3 md:grid-cols-6">
          <TabsTrigger value="oleosos">Oleosos</TabsTrigger>
          <TabsTrigger value="fisico-quimico">Físico Químico</TabsTrigger>
          <TabsTrigger value="concentrado">Concentrado</TabsTrigger>
          <TabsTrigger value="lodo">Tratamento de Lodo</TabsTrigger>
          <TabsTrigger value="biologico">Tratamento Biológico</TabsTrigger>
          <TabsTrigger value="terciario">Tratamento Terciário</TabsTrigger>
        </TabsList>

        <TabsContent value="oleosos">
          <Card>
            <CardHeader>
              <CardTitle>Tanques Oleosos</CardTitle>
              <CardDescription>Controle de volumes por turno</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanque</TableHead>
                    <TableHead>Turno A</TableHead>
                    <TableHead>Turno B</TableHead>
                    <TableHead>Turno C</TableHead>
                    <TableHead>Diferença (C-A)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tanquesOleosos.map((tanque) => (
                    <TableRow key={tanque.id}>
                      <TableCell className="font-medium">{tanque.nome}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeA}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "A", setTanquesOleosos)}
                          disabled={turno !== "A"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeB}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "B", setTanquesOleosos)}
                          disabled={turno !== "B"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeC}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "C", setTanquesOleosos)}
                          disabled={turno !== "C"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell
                        className={
                          Number.parseFloat(tanque.diferenca) < 0
                            ? "text-red-500"
                            : Number.parseFloat(tanque.diferenca) > 0
                              ? "text-green-500"
                              : ""
                        }
                      >
                        {tanque.diferenca}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fisico-quimico">
          <Card>
            <CardHeader>
              <CardTitle>Tanques Físico Químico</CardTitle>
              <CardDescription>Controle de volumes por turno</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanque</TableHead>
                    <TableHead>Turno A</TableHead>
                    <TableHead>Turno B</TableHead>
                    <TableHead>Turno C</TableHead>
                    <TableHead>Diferença (C-A)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tanquesFisicoQuimico.map((tanque) => (
                    <TableRow key={tanque.id}>
                      <TableCell className="font-medium">{tanque.nome}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeA}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "A", setTanquesFisicoQuimico)}
                          disabled={turno !== "A"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeB}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "B", setTanquesFisicoQuimico)}
                          disabled={turno !== "B"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeC}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "C", setTanquesFisicoQuimico)}
                          disabled={turno !== "C"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell
                        className={
                          Number.parseFloat(tanque.diferenca) < 0
                            ? "text-red-500"
                            : Number.parseFloat(tanque.diferenca) > 0
                              ? "text-green-500"
                              : ""
                        }
                      >
                        {tanque.diferenca}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="concentrado">
          <Card>
            <CardHeader>
              <CardTitle>Tanque de Concentrado</CardTitle>
              <CardDescription>Controle de volume por turno</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanque</TableHead>
                    <TableHead>Turno A</TableHead>
                    <TableHead>Turno B</TableHead>
                    <TableHead>Turno C</TableHead>
                    <TableHead>Diferença (C-A)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tanquesConcentrado.map((tanque) => (
                    <TableRow key={tanque.id}>
                      <TableCell className="font-medium">{tanque.nome}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeA}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "A", setTanquesConcentrado)}
                          disabled={turno !== "A"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeB}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "B", setTanquesConcentrado)}
                          disabled={turno !== "B"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeC}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "C", setTanquesConcentrado)}
                          disabled={turno !== "C"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell
                        className={
                          Number.parseFloat(tanque.diferenca) < 0
                            ? "text-red-500"
                            : Number.parseFloat(tanque.diferenca) > 0
                              ? "text-green-500"
                              : ""
                        }
                      >
                        {tanque.diferenca}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lodo">
          <Card>
            <CardHeader>
              <CardTitle>Tanques de Tratamento de Lodo</CardTitle>
              <CardDescription>Controle de volumes por turno</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanque</TableHead>
                    <TableHead>Turno A</TableHead>
                    <TableHead>Turno B</TableHead>
                    <TableHead>Turno C</TableHead>
                    <TableHead>Diferença (C-A)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tanquesTratamentoLodo.map((tanque) => (
                    <TableRow key={tanque.id}>
                      <TableCell className="font-medium">{tanque.nome}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeA}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "A", setTanquesTratamentoLodo)}
                          disabled={turno !== "A"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeB}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "B", setTanquesTratamentoLodo)}
                          disabled={turno !== "B"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeC}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "C", setTanquesTratamentoLodo)}
                          disabled={turno !== "C"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell
                        className={
                          Number.parseFloat(tanque.diferenca) < 0
                            ? "text-red-500"
                            : Number.parseFloat(tanque.diferenca) > 0
                              ? "text-green-500"
                              : ""
                        }
                      >
                        {tanque.diferenca}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="biologico">
          <Card>
            <CardHeader>
              <CardTitle>Tanques de Tratamento Biológico</CardTitle>
              <CardDescription>Controle de volumes por turno</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanque</TableHead>
                    <TableHead>Turno A</TableHead>
                    <TableHead>Turno B</TableHead>
                    <TableHead>Turno C</TableHead>
                    <TableHead>Diferença (C-A)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tanquesBiologico.map((tanque) => (
                    <TableRow key={tanque.id}>
                      <TableCell className="font-medium">{tanque.nome}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeA}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "A", setTanquesBiologico)}
                          disabled={turno !== "A"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeB}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "B", setTanquesBiologico)}
                          disabled={turno !== "B"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeC}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "C", setTanquesBiologico)}
                          disabled={turno !== "C"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell
                        className={
                          Number.parseFloat(tanque.diferenca) < 0
                            ? "text-red-500"
                            : Number.parseFloat(tanque.diferenca) > 0
                              ? "text-green-500"
                              : ""
                        }
                      >
                        {tanque.diferenca}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="terciario">
          <Card>
            <CardHeader>
              <CardTitle>Tanques de Tratamento Terciário</CardTitle>
              <CardDescription>Controle de volumes por turno</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanque</TableHead>
                    <TableHead>Turno A</TableHead>
                    <TableHead>Turno B</TableHead>
                    <TableHead>Turno C</TableHead>
                    <TableHead>Diferença (C-A)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tanquesTerciario.map((tanque) => (
                    <TableRow key={tanque.id}>
                      <TableCell className="font-medium">{tanque.nome}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeA}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "A", setTanquesTerciario)}
                          disabled={turno !== "A"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeB}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "B", setTanquesTerciario)}
                          disabled={turno !== "B"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={tanque.volumeC}
                          onChange={(e) => atualizarVolume(tanque.id, e.target.value, "C", setTanquesTerciario)}
                          disabled={turno !== "C"}
                          placeholder="Volume"
                        />
                      </TableCell>
                      <TableCell
                        className={
                          Number.parseFloat(tanque.diferenca) < 0
                            ? "text-red-500"
                            : Number.parseFloat(tanque.diferenca) > 0
                              ? "text-green-500"
                              : ""
                        }
                      >
                        {tanque.diferenca}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-6">
        <Button onClick={gerarRelatorio} variant="outline" className="w-full">
          <Download className="mr-2 h-4 w-4" />
          Gerar Relatório Diário
        </Button>
      </div>
    </div>
  )
}
