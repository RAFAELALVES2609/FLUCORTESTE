"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { Camera, CalendarIcon, Save, Upload, X } from "lucide-react"

type AtividadeApoio = "lideranca" | "brigadista" | "cipeiro" | "operador_empilhadeira" | "nenhuma"

type Funcionario = {
  nome: string
  funcao: string
  dataAdmissao: Date
  turno: "1" | "2" | "3" | "ADM"
  atividadesApoio: AtividadeApoio[]
  horarioEntrada: string
  horarioSaida: string
  horarioIntervalo: string
  foto?: string
  login: string
  senha: string
  aceiteLGPD: boolean
}

export default function CadastroPerfilSimples() {
  const { toast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [funcionario, setFuncionario] = useState<Funcionario>({
    nome: "",
    funcao: "",
    dataAdmissao: new Date(),
    turno: "1",
    atividadesApoio: [],
    horarioEntrada: "06:00",
    horarioSaida: "14:45",
    horarioIntervalo: "10:00 - 11:00",
    foto: undefined,
    login: "",
    senha: "",
    aceiteLGPD: false,
  })

  // Função para atualizar os horários com base no turno selecionado
  const atualizarHorariosPorTurno = (turno: string) => {
    switch (turno) {
      case "1":
        setFuncionario({
          ...funcionario,
          turno: "1",
          horarioEntrada: "06:00",
          horarioSaida: "14:45",
          horarioIntervalo: "10:00 - 11:00",
        })
        break
      case "2":
        setFuncionario({
          ...funcionario,
          turno: "2",
          horarioEntrada: "13:55",
          horarioSaida: "22:35",
          horarioIntervalo: "18:00 - 19:00",
        })
        break
      case "3":
        setFuncionario({
          ...funcionario,
          turno: "3",
          horarioEntrada: "22:13",
          horarioSaida: "06:00",
          horarioIntervalo: "02:00 - 03:00",
        })
        break
      case "ADM":
        setFuncionario({
          ...funcionario,
          turno: "ADM",
          horarioEntrada: "08:00",
          horarioSaida: "17:00",
          horarioIntervalo: "12:00 - 13:00",
        })
        break
      default:
        break
    }
  }

  // Função para lidar com o upload de foto
  const handleFotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setFuncionario({
          ...funcionario,
          foto: reader.result as string,
        })
      }
      reader.readAsDataURL(file)
    }
  }

  // Função para lidar com a alteração de atividades de apoio
  const handleAtividadeApoioChange = (atividade: AtividadeApoio, checked: boolean) => {
    if (checked) {
      setFuncionario({
        ...funcionario,
        atividadesApoio: [...funcionario.atividadesApoio, atividade],
      })
    } else {
      setFuncionario({
        ...funcionario,
        atividadesApoio: funcionario.atividadesApoio.filter((a) => a !== atividade),
      })
    }
  }

  // Função para salvar o cadastro
  const salvarCadastro = () => {
    // Validação básica
    if (!funcionario.nome || !funcionario.funcao || !funcionario.login || !funcionario.senha) {
      toast({
        title: "Erro ao salvar",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    if (!funcionario.aceiteLGPD) {
      toast({
        title: "Erro ao salvar",
        description: "É necessário aceitar os termos de LGPD.",
        variant: "destructive",
      })
      return
    }

    // Aqui você implementaria a lógica para salvar no banco de dados
    // Por enquanto, apenas mostramos uma mensagem de sucesso
    toast({
      title: "Cadastro salvo com sucesso!",
      description: `O perfil de ${funcionario.nome} foi cadastrado.`,
    })
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Cadastro de Perfil</h1>

      <Card>
        <CardHeader>
          <CardTitle>Dados Pessoais e Funcionais</CardTitle>
          <CardDescription>Preencha os dados do funcionário para cadastro no sistema</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col md:flex-row gap-6">
            <div className="flex-1 space-y-4">
              <div>
                <Label htmlFor="nome">Nome Completo*</Label>
                <Input
                  id="nome"
                  value={funcionario.nome}
                  onChange={(e) => setFuncionario({ ...funcionario, nome: e.target.value })}
                  placeholder="Nome completo do funcionário"
                />
              </div>

              <div>
                <Label htmlFor="funcao">Função*</Label>
                <Input
                  id="funcao"
                  value={funcionario.funcao}
                  onChange={(e) => setFuncionario({ ...funcionario, funcao: e.target.value })}
                  placeholder="Função do funcionário"
                />
              </div>

              <div>
                <Label htmlFor="data-admissao">Data de Admissão*</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {funcionario.dataAdmissao ? (
                        format(funcionario.dataAdmissao, "PPP", { locale: ptBR })
                      ) : (
                        <span>Selecione uma data</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={funcionario.dataAdmissao}
                      onSelect={(date) => date && setFuncionario({ ...funcionario, dataAdmissao: date })}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <Label htmlFor="turno">Turno*</Label>
                <Select
                  value={funcionario.turno}
                  onValueChange={(value: "1" | "2" | "3" | "ADM") => atualizarHorariosPorTurno(value)}
                >
                  <SelectTrigger id="turno">
                    <SelectValue placeholder="Selecione o turno" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Turno 1 (06:00 às 14:45)</SelectItem>
                    <SelectItem value="2">Turno 2 (13:55 às 22:35)</SelectItem>
                    <SelectItem value="3">Turno 3 (22:13 às 06:00)</SelectItem>
                    <SelectItem value="ADM">Administrativo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Atividades de Apoio</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="lideranca"
                      checked={funcionario.atividadesApoio.includes("lideranca")}
                      onCheckedChange={(checked) => handleAtividadeApoioChange("lideranca", checked as boolean)}
                    />
                    <label
                      htmlFor="lideranca"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Liderança de Área
                    </label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="brigadista"
                      checked={funcionario.atividadesApoio.includes("brigadista")}
                      onCheckedChange={(checked) => handleAtividadeApoioChange("brigadista", checked as boolean)}
                    />
                    <label
                      htmlFor="brigadista"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Brigadista
                    </label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="cipeiro"
                      checked={funcionario.atividadesApoio.includes("cipeiro")}
                      onCheckedChange={(checked) => handleAtividadeApoioChange("cipeiro", checked as boolean)}
                    />
                    <label
                      htmlFor="cipeiro"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      CIPEIRO
                    </label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="operador_empilhadeira"
                      checked={funcionario.atividadesApoio.includes("operador_empilhadeira")}
                      onCheckedChange={(checked) =>
                        handleAtividadeApoioChange("operador_empilhadeira", checked as boolean)
                      }
                    />
                    <label
                      htmlFor="operador_empilhadeira"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Operador de Empilhadeira
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex-1 space-y-4">
              <div className="flex flex-col items-center justify-center space-y-4">
                <div className="relative w-40 h-40 border-2 border-dashed rounded-lg flex items-center justify-center overflow-hidden">
                  {funcionario.foto ? (
                    <>
                      <img
                        src={funcionario.foto || "/placeholder.svg"}
                        alt="Foto do funcionário"
                        className="w-full h-full object-cover"
                      />
                      <button
                        className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1"
                        onClick={() => setFuncionario({ ...funcionario, foto: undefined })}
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center text-muted-foreground">
                      <Camera className="h-10 w-10 mb-2" />
                      <span className="text-sm">Foto do Funcionário</span>
                    </div>
                  )}
                </div>
                <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={handleFotoUpload} />
                <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                  <Upload className="h-4 w-4 mr-2" />
                  Carregar Foto
                </Button>
              </div>

              <div>
                <Label htmlFor="horario-entrada">Horário de Entrada</Label>
                <Input
                  id="horario-entrada"
                  type="time"
                  value={funcionario.horarioEntrada}
                  onChange={(e) => setFuncionario({ ...funcionario, horarioEntrada: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="horario-saida">Horário de Saída</Label>
                <Input
                  id="horario-saida"
                  type="time"
                  value={funcionario.horarioSaida}
                  onChange={(e) => setFuncionario({ ...funcionario, horarioSaida: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="horario-intervalo">Horário de Intervalo</Label>
                <Input
                  id="horario-intervalo"
                  value={funcionario.horarioIntervalo}
                  onChange={(e) => setFuncionario({ ...funcionario, horarioIntervalo: e.target.value })}
                  placeholder="Ex: 12:00 - 13:00"
                />
              </div>

              <div>
                <Label htmlFor="login">Login*</Label>
                <Input
                  id="login"
                  value={funcionario.login}
                  onChange={(e) => setFuncionario({ ...funcionario, login: e.target.value })}
                  placeholder="Login para acesso ao sistema"
                />
              </div>

              <div>
                <Label htmlFor="senha">Senha*</Label>
                <Input
                  id="senha"
                  type="password"
                  value={funcionario.senha}
                  onChange={(e) => setFuncionario({ ...funcionario, senha: e.target.value })}
                  placeholder="Senha para acesso ao sistema"
                />
              </div>
            </div>
          </div>

          <div className="border p-4 rounded-md bg-muted/30">
            <div className="flex items-start space-x-2">
              <Checkbox
                id="aceite-lgpd"
                checked={funcionario.aceiteLGPD}
                onCheckedChange={(checked) => setFuncionario({ ...funcionario, aceiteLGPD: checked as boolean })}
              />
              <div>
                <label
                  htmlFor="aceite-lgpd"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Aceito os termos de uso e política de privacidade
                </label>
                <p className="text-xs text-muted-foreground mt-1">
                  Ao marcar esta opção, você concorda com o tratamento dos seus dados pessoais conforme a Lei Geral de
                  Proteção de Dados (LGPD) para fins de gestão de recursos humanos, controle de acesso e segurança. Seus
                  dados serão armazenados de forma segura e não serão compartilhados com terceiros sem o seu
                  consentimento prévio.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={salvarCadastro}>
            <Save className="h-4 w-4 mr-2" />
            Salvar Cadastro
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
