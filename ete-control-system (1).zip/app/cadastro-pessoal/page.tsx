"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Edit, Plus, Trash2, UserPlus } from "lucide-react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"

type Funcionario = {
  id: string
  nome: string
  cargo: string
  setor: "operacao" | "laboratorio" | "lideranca" | "administrativo"
  turno: "A" | "B" | "C" | "ADM"
  dataAdmissao: Date
  telefone: string
  email: string
  ativo: boolean
}

type Escala = {
  id: string
  nome: string
  tipo: "6x1" | "5x2" | "4x4" | "12x36"
  cicloSemanas: number
  folgas: {
    semana: number
    dias: number[] // 0 = domingo, 1 = segunda, etc.
  }[]
}

type FuncionarioEscala = {
  funcionarioId: string
  escalaId: string
  dataInicio: Date
  observacoes: string
}

export default function CadastroPessoal() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("funcionarios")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [escalaDialogOpen, setEscalaDialogOpen] = useState(false)
  const [atribuirEscalaDialogOpen, setAtribuirEscalaDialogOpen] = useState(false)
  const [funcionarioEmEdicao, setFuncionarioEmEdicao] = useState<Funcionario | null>(null)
  const [escalaEmEdicao, setEscalaEmEdicao] = useState<Escala | null>(null)
  const [funcionarioSelecionado, setFuncionarioSelecionado] = useState<string>("")
  const [escalaSelecionada, setEscalaSelecionada] = useState<string>("")
  const [dataInicioEscala, setDataInicioEscala] = useState<Date>(new Date())
  const [observacoesEscala, setObservacoesEscala] = useState<string>("")

  const [novoFuncionario, setNovoFuncionario] = useState<Omit<Funcionario, "id">>({
    nome: "",
    cargo: "",
    setor: "operacao",
    turno: "A",
    dataAdmissao: new Date(),
    telefone: "",
    email: "",
    ativo: true,
  })

  const [novaEscala, setNovaEscala] = useState<Omit<Escala, "id">>({
    nome: "",
    tipo: "6x1",
    cicloSemanas: 1,
    folgas: [
      {
        semana: 1,
        dias: [0], // Domingo
      },
    ],
  })

  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([
    {
      id: "1",
      nome: "João Silva",
      cargo: "Operador",
      setor: "operacao",
      turno: "A",
      dataAdmissao: new Date(2020, 5, 15),
      telefone: "(11) 98765-4321",
      email: "joao.silva@flucor.com.br",
      ativo: true,
    },
    {
      id: "2",
      nome: "Maria Oliveira",
      cargo: "Supervisora",
      setor: "lideranca",
      turno: "ADM",
      dataAdmissao: new Date(2018, 3, 10),
      telefone: "(11) 91234-5678",
      email: "maria.oliveira@flucor.com.br",
      ativo: true,
    },
    {
      id: "3",
      nome: "Carlos Santos",
      cargo: "Técnico de Laboratório",
      setor: "laboratorio",
      turno: "B",
      dataAdmissao: new Date(2021, 1, 20),
      telefone: "(11) 95555-9999",
      email: "carlos.santos@flucor.com.br",
      ativo: true,
    },
    {
      id: "4",
      nome: "Ana Souza",
      cargo: "Analista Administrativo",
      setor: "administrativo",
      turno: "ADM",
      dataAdmissao: new Date(2019, 8, 5),
      telefone: "(11) 94444-8888",
      email: "ana.souza@flucor.com.br",
      ativo: true,
    },
  ])

  const [escalas, setEscalas] = useState<Escala[]>([
    {
      id: "1",
      nome: "Escala 6x1 - Padrão",
      tipo: "6x1",
      cicloSemanas: 1,
      folgas: [
        {
          semana: 1,
          dias: [0], // Domingo
        },
      ],
    },
    {
      id: "2",
      nome: "Escala 6x1 - Rodízio",
      tipo: "6x1",
      cicloSemanas: 3,
      folgas: [
        {
          semana: 1,
          dias: [0], // Domingo
        },
        {
          semana: 2,
          dias: [6], // Sábado
        },
        {
          semana: 3,
          dias: [0, 6], // Sábado e Domingo
        },
      ],
    },
    {
      id: "3",
      nome: "Escala 5x2 - Administrativo",
      tipo: "5x2",
      cicloSemanas: 1,
      folgas: [
        {
          semana: 1,
          dias: [0, 6], // Sábado e Domingo
        },
      ],
    },
  ])

  const [funcionariosEscalas, setFuncionariosEscalas] = useState<FuncionarioEscala[]>([
    {
      funcionarioId: "1",
      escalaId: "2",
      dataInicio: new Date(2023, 0, 1),
      observacoes: "Início do ciclo na semana 1",
    },
    {
      funcionarioId: "2",
      escalaId: "3",
      dataInicio: new Date(2022, 0, 1),
      observacoes: "Horário administrativo",
    },
    {
      funcionarioId: "3",
      escalaId: "2",
      dataInicio: new Date(2023, 1, 15),
      observacoes: "Início do ciclo na semana 2",
    },
    {
      funcionarioId: "4",
      escalaId: "3",
      dataInicio: new Date(2022, 8, 1),
      observacoes: "Horário administrativo",
    },
  ])

  const adicionarFuncionario = () => {
    if (!novoFuncionario.nome || !novoFuncionario.cargo || !novoFuncionario.setor || !novoFuncionario.turno) {
      toast({
        title: "Erro ao adicionar funcionário",
        description: "Nome, cargo, setor e turno são obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (funcionarios.length + 1).toString()
    const funcionarioCompleto: Funcionario = {
      id: novoId,
      ...novoFuncionario,
    }

    setFuncionarios([...funcionarios, funcionarioCompleto])
    setNovoFuncionario({
      nome: "",
      cargo: "",
      setor: "operacao",
      turno: "A",
      dataAdmissao: new Date(),
      telefone: "",
      email: "",
      ativo: true,
    })
    setDialogOpen(false)

    toast({
      title: "Funcionário adicionado",
      description: "O novo funcionário foi adicionado com sucesso.",
    })
  }

  const adicionarEscala = () => {
    if (!novaEscala.nome || !novaEscala.tipo || novaEscala.cicloSemanas < 1 || novaEscala.folgas.length === 0) {
      toast({
        title: "Erro ao adicionar escala",
        description: "Nome, tipo, ciclo de semanas e folgas são obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (escalas.length + 1).toString()
    const escalaCompleta: Escala = {
      id: novoId,
      ...novaEscala,
    }

    setEscalas([...escalas, escalaCompleta])
    setNovaEscala({
      nome: "",
      tipo: "6x1",
      cicloSemanas: 1,
      folgas: [
        {
          semana: 1,
          dias: [0], // Domingo
        },
      ],
    })
    setEscalaDialogOpen(false)

    toast({
      title: "Escala adicionada",
      description: "A nova escala foi adicionada com sucesso.",
    })
  }

  const atribuirEscala = () => {
    if (!funcionarioSelecionado || !escalaSelecionada || !dataInicioEscala) {
      toast({
        title: "Erro ao atribuir escala",
        description: "Funcionário, escala e data de início são obrigatórios.",
        variant: "destructive",
      })
      return
    }

    // Verificar se já existe uma atribuição para este funcionário
    const atribuicaoExistente = funcionariosEscalas.find((fe) => fe.funcionarioId === funcionarioSelecionado)

    if (atribuicaoExistente) {
      // Atualizar a atribuição existente
      setFuncionariosEscalas(
        funcionariosEscalas.map((fe) =>
          fe.funcionarioId === funcionarioSelecionado
            ? {
                funcionarioId: funcionarioSelecionado,
                escalaId: escalaSelecionada,
                dataInicio: dataInicioEscala,
                observacoes: observacoesEscala,
              }
            : fe,
        ),
      )
    } else {
      // Criar uma nova atribuição
      setFuncionariosEscalas([
        ...funcionariosEscalas,
        {
          funcionarioId: funcionarioSelecionado,
          escalaId: escalaSelecionada,
          dataInicio: dataInicioEscala,
          observacoes: observacoesEscala,
        },
      ])
    }

    setFuncionarioSelecionado("")
    setEscalaSelecionada("")
    setDataInicioEscala(new Date())
    setObservacoesEscala("")
    setAtribuirEscalaDialogOpen(false)

    toast({
      title: "Escala atribuída",
      description: "A escala foi atribuída ao funcionário com sucesso.",
    })
  }

  const editarFuncionario = (funcionario: Funcionario) => {
    setFuncionarioEmEdicao(funcionario)
    setDialogOpen(true)
  }

  const editarEscala = (escala: Escala) => {
    setEscalaEmEdicao(escala)
    setEscalaDialogOpen(true)
  }

  const salvarEdicaoFuncionario = () => {
    if (!funcionarioEmEdicao) return

    setFuncionarios(
      funcionarios.map((funcionario) =>
        funcionario.id === funcionarioEmEdicao.id ? funcionarioEmEdicao : funcionario,
      ),
    )

    setDialogOpen(false)
    setFuncionarioEmEdicao(null)

    toast({
      title: "Funcionário atualizado",
      description: "As informações do funcionário foram atualizadas com sucesso.",
    })
  }

  const salvarEdicaoEscala = () => {
    if (!escalaEmEdicao) return

    setEscalas(escalas.map((escala) => (escala.id === escalaEmEdicao.id ? escalaEmEdicao : escala)))

    setEscalaDialogOpen(false)
    setEscalaEmEdicao(null)

    toast({
      title: "Escala atualizada",
      description: "As informações da escala foram atualizadas com sucesso.",
    })
  }

  const removerFuncionario = (id: string) => {
    // Verificar se o funcionário tem escala atribuída
    const temEscala = funcionariosEscalas.some((fe) => fe.funcionarioId === id)
    if (temEscala) {
      toast({
        title: "Não é possível remover o funcionário",
        description: "Este funcionário possui uma escala atribuída.",
        variant: "destructive",
      })
      return
    }

    setFuncionarios(funcionarios.filter((funcionario) => funcionario.id !== id))

    toast({
      title: "Funcionário removido",
      description: "O funcionário foi removido com sucesso.",
    })
  }

  const removerEscala = (id: string) => {
    // Verificar se a escala está atribuída a algum funcionário
    const escalaAtribuida = funcionariosEscalas.some((fe) => fe.escalaId === id)
    if (escalaAtribuida) {
      toast({
        title: "Não é possível remover a escala",
        description: "Esta escala está atribuída a um ou mais funcionários.",
        variant: "destructive",
      })
      return
    }

    setEscalas(escalas.filter((escala) => escala.id !== id))

    toast({
      title: "Escala removida",
      description: "A escala foi removida com sucesso.",
    })
  }

  const removerAtribuicaoEscala = (funcionarioId: string) => {
    setFuncionariosEscalas(funcionariosEscalas.filter((fe) => fe.funcionarioId !== funcionarioId))

    toast({
      title: "Atribuição removida",
      description: "A atribuição de escala foi removida com sucesso.",
    })
  }

  const getNomeFuncionario = (id: string) => {
    const funcionario = funcionarios.find((f) => f.id === id)
    return funcionario ? funcionario.nome : "Não encontrado"
  }

  const getNomeEscala = (id: string) => {
    const escala = escalas.find((e) => e.id === id)
    return escala ? escala.nome : "Não encontrada"
  }

  const getEscalaFuncionario = (funcionarioId: string) => {
    const atribuicao = funcionariosEscalas.find((fe) => fe.funcionarioId === funcionarioId)
    if (!atribuicao) return "Não atribuída"

    const escala = escalas.find((e) => e.id === atribuicao.escalaId)
    return escala ? escala.nome : "Não encontrada"
  }

  const getDiasSemana = (dia: number) => {
    const dias = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"]
    return dias[dia]
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Cadastro de Pessoal e Escalas</h1>

      <Tabs defaultValue="funcionarios" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="funcionarios">Funcionários</TabsTrigger>
          <TabsTrigger value="escalas">Escalas</TabsTrigger>
          <TabsTrigger value="atribuicoes">Atribuições de Escalas</TabsTrigger>
        </TabsList>

        <TabsContent value="funcionarios" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Funcionários</CardTitle>
                <CardDescription>Gerenciamento de funcionários da unidade</CardDescription>
              </div>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    onClick={() => {
                      setFuncionarioEmEdicao(null)
                      setNovoFuncionario({
                        nome: "",
                        cargo: "",
                        setor: "operacao",
                        turno: "A",
                        dataAdmissao: new Date(),
                        telefone: "",
                        email: "",
                        ativo: true,
                      })
                    }}
                  >
                    <UserPlus className="mr-2 h-4 w-4" />
                    Novo Funcionário
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>
                      {funcionarioEmEdicao ? "Editar Funcionário" : "Adicionar Novo Funcionário"}
                    </DialogTitle>
                    <DialogDescription>
                      {funcionarioEmEdicao
                        ? "Edite as informações do funcionário."
                        : "Preencha as informações para cadastrar um novo funcionário."}
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div>
                      <Label htmlFor="nome-funcionario">Nome</Label>
                      <Input
                        id="nome-funcionario"
                        value={funcionarioEmEdicao ? funcionarioEmEdicao.nome : novoFuncionario.nome}
                        onChange={(e) => {
                          if (funcionarioEmEdicao) {
                            setFuncionarioEmEdicao({ ...funcionarioEmEdicao, nome: e.target.value })
                          } else {
                            setNovoFuncionario({ ...novoFuncionario, nome: e.target.value })
                          }
                        }}
                        placeholder="Ex: João Silva"
                      />
                    </div>
                    <div>
                      <Label htmlFor="cargo-funcionario">Cargo</Label>
                      <Input
                        id="cargo-funcionario"
                        value={funcionarioEmEdicao ? funcionarioEmEdicao.cargo : novoFuncionario.cargo}
                        onChange={(e) => {
                          if (funcionarioEmEdicao) {
                            setFuncionarioEmEdicao({ ...funcionarioEmEdicao, cargo: e.target.value })
                          } else {
                            setNovoFuncionario({ ...novoFuncionario, cargo: e.target.value })
                          }
                        }}
                        placeholder="Ex: Operador"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="setor-funcionario">Setor</Label>
                        <Select
                          value={funcionarioEmEdicao ? funcionarioEmEdicao.setor : novoFuncionario.setor}
                          onValueChange={(value: "operacao" | "laboratorio" | "lideranca" | "administrativo") => {
                            if (funcionarioEmEdicao) {
                              setFuncionarioEmEdicao({ ...funcionarioEmEdicao, setor: value })
                            } else {
                              setNovoFuncionario({ ...novoFuncionario, setor: value })
                            }
                          }}
                        >
                          <SelectTrigger id="setor-funcionario">
                            <SelectValue placeholder="Selecione o setor" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="operacao">Operação</SelectItem>
                            <SelectItem value="laboratorio">Laboratório</SelectItem>
                            <SelectItem value="lideranca">Liderança</SelectItem>
                            <SelectItem value="administrativo">Administrativo</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="turno-funcionario">Turno</Label>
                        <Select
                          value={funcionarioEmEdicao ? funcionarioEmEdicao.turno : novoFuncionario.turno}
                          onValueChange={(value: "A" | "B" | "C" | "ADM") => {
                            if (funcionarioEmEdicao) {
                              setFuncionarioEmEdicao({ ...funcionarioEmEdicao, turno: value })
                            } else {
                              setNovoFuncionario({ ...novoFuncionario, turno: value })
                            }
                          }}
                        >
                          <SelectTrigger id="turno-funcionario">
                            <SelectValue placeholder="Selecione o turno" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="A">Turno A</SelectItem>
                            <SelectItem value="B">Turno B</SelectItem>
                            <SelectItem value="C">Turno C</SelectItem>
                            <SelectItem value="ADM">Administrativo</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="data-admissao">Data de Admissão</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !funcionarioEmEdicao?.dataAdmissao &&
                                !novoFuncionario.dataAdmissao &&
                                "text-muted-foreground",
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {funcionarioEmEdicao?.dataAdmissao
                              ? format(funcionarioEmEdicao.dataAdmissao, "PPP", { locale: ptBR })
                              : novoFuncionario.dataAdmissao
                                ? format(novoFuncionario.dataAdmissao, "PPP", { locale: ptBR })
                                : "Selecione uma data"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={
                              funcionarioEmEdicao ? funcionarioEmEdicao.dataAdmissao : novoFuncionario.dataAdmissao
                            }
                            onSelect={(date) => {
                              if (date) {
                                if (funcionarioEmEdicao) {
                                  setFuncionarioEmEdicao({ ...funcionarioEmEdicao, dataAdmissao: date })
                                } else {
                                  setNovoFuncionario({ ...novoFuncionario, dataAdmissao: date })
                                }
                              }
                            }}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div>
                      <Label htmlFor="telefone-funcionario">Telefone</Label>
                      <Input
                        id="telefone-funcionario"
                        value={funcionarioEmEdicao ? funcionarioEmEdicao.telefone : novoFuncionario.telefone}
                        onChange={(e) => {
                          if (funcionarioEmEdicao) {
                            setFuncionarioEmEdicao({ ...funcionarioEmEdicao, telefone: e.target.value })
                          } else {
                            setNovoFuncionario({ ...novoFuncionario, telefone: e.target.value })
                          }
                        }}
                        placeholder="Ex: (11) 98765-4321"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email-funcionario">Email</Label>
                      <Input
                        id="email-funcionario"
                        type="email"
                        value={funcionarioEmEdicao ? funcionarioEmEdicao.email : novoFuncionario.email}
                        onChange={(e) => {
                          if (funcionarioEmEdicao) {
                            setFuncionarioEmEdicao({ ...funcionarioEmEdicao, email: e.target.value })
                          } else {
                            setNovoFuncionario({ ...novoFuncionario, email: e.target.value })
                          }
                        }}
                        placeholder="Ex: joao.silva@flucor.com.br"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="ativo-funcionario"
                        checked={funcionarioEmEdicao ? funcionarioEmEdicao.ativo : novoFuncionario.ativo}
                        onChange={(e) => {
                          if (funcionarioEmEdicao) {
                            setFuncionarioEmEdicao({ ...funcionarioEmEdicao, ativo: e.target.checked })
                          } else {
                            setNovoFuncionario({ ...novoFuncionario, ativo: e.target.checked })
                          }
                        }}
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <label
                        htmlFor="ativo-funcionario"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Funcionário Ativo
                      </label>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={funcionarioEmEdicao ? salvarEdicaoFuncionario : adicionarFuncionario}>
                      {funcionarioEmEdicao ? "Salvar Alterações" : "Adicionar Funcionário"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Cargo</TableHead>
                    <TableHead>Setor</TableHead>
                    <TableHead>Turno</TableHead>
                    <TableHead>Escala</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {funcionarios.map((funcionario) => (
                    <TableRow key={funcionario.id}>
                      <TableCell className="font-medium">{funcionario.nome}</TableCell>
                      <TableCell>{funcionario.cargo}</TableCell>
                      <TableCell>
                        {funcionario.setor === "operacao" && "Operação"}
                        {funcionario.setor === "laboratorio" && "Laboratório"}
                        {funcionario.setor === "lideranca" && "Liderança"}
                        {funcionario.setor === "administrativo" && "Administrativo"}
                      </TableCell>
                      <TableCell>Turno {funcionario.turno}</TableCell>
                      <TableCell>{getEscalaFuncionario(funcionario.id)}</TableCell>
                      <TableCell>
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${
                            funcionario.ativo
                              ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
                              : "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
                          }`}
                        >
                          {funcionario.ativo ? "Ativo" : "Inativo"}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => editarFuncionario(funcionario)}>
                            <Edit className="h-4 w-4 text-blue-500" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => removerFuncionario(funcionario.id)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="escalas" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Escalas</CardTitle>
                <CardDescription>Gerenciamento de escalas de trabalho</CardDescription>
              </div>
              <Dialog open={escalaDialogOpen} onOpenChange={setEscalaDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    onClick={() => {
                      setEscalaEmEdicao(null)
                      setNovaEscala({
                        nome: "",
                        tipo: "6x1",
                        cicloSemanas: 1,
                        folgas: [
                          {
                            semana: 1,
                            dias: [0], // Domingo
                          },
                        ],
                      })
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Nova Escala
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>{escalaEmEdicao ? "Editar Escala" : "Adicionar Nova Escala"}</DialogTitle>
                    <DialogDescription>
                      {escalaEmEdicao
                        ? "Edite as informações da escala."
                        : "Preencha as informações para criar uma nova escala."}
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div>
                      <Label htmlFor="nome-escala">Nome da Escala</Label>
                      <Input
                        id="nome-escala"
                        value={escalaEmEdicao ? escalaEmEdicao.nome : novaEscala.nome}
                        onChange={(e) => {
                          if (escalaEmEdicao) {
                            setEscalaEmEdicao({ ...escalaEmEdicao, nome: e.target.value })
                          } else {
                            setNovaEscala({ ...novaEscala, nome: e.target.value })
                          }
                        }}
                        placeholder="Ex: Escala 6x1 - Padrão"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="tipo-escala">Tipo de Escala</Label>
                        <Select
                          value={escalaEmEdicao ? escalaEmEdicao.tipo : novaEscala.tipo}
                          onValueChange={(value: "6x1" | "5x2" | "4x4" | "12x36") => {
                            if (escalaEmEdicao) {
                              setEscalaEmEdicao({ ...escalaEmEdicao, tipo: value })
                            } else {
                              setNovaEscala({ ...novaEscala, tipo: value })
                            }
                          }}
                        >
                          <SelectTrigger id="tipo-escala">
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="6x1">6x1</SelectItem>
                            <SelectItem value="5x2">5x2</SelectItem>
                            <SelectItem value="4x4">4x4</SelectItem>
                            <SelectItem value="12x36">12x36</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="ciclo-semanas">Ciclo (Semanas)</Label>
                        <Input
                          id="ciclo-semanas"
                          type="number"
                          min="1"
                          max="4"
                          value={escalaEmEdicao ? escalaEmEdicao.cicloSemanas : novaEscala.cicloSemanas}
                          onChange={(e) => {
                            const valor = Number.parseInt(e.target.value)
                            if (valor >= 1 && valor <= 4) {
                              if (escalaEmEdicao) {
                                setEscalaEmEdicao({ ...escalaEmEdicao, cicloSemanas: valor })
                              } else {
                                setNovaEscala({ ...novaEscala, cicloSemanas: valor })
                              }
                            }
                          }}
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="mb-2 block">Folgas</Label>
                      <div className="space-y-4 border rounded-md p-3">
                        {(escalaEmEdicao ? escalaEmEdicao.folgas : novaEscala.folgas).map((folga, index) => (
                          <div key={index} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <h4 className="text-sm font-medium">Semana {folga.semana}</h4>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  if (escalaEmEdicao) {
                                    setEscalaEmEdicao({
                                      ...escalaEmEdicao,
                                      folgas: escalaEmEdicao.folgas.filter((_, i) => i !== index),
                                    })
                                  } else {
                                    setNovaEscala({
                                      ...novaEscala,
                                      folgas: novaEscala.folgas.filter((_, i) => i !== index),
                                    })
                                  }
                                }}
                              >
                                <Trash2 className="h-3 w-3 text-red-500" />
                              </Button>
                            </div>
                            <div className="grid grid-cols-7 gap-1">
                              {[0, 1, 2, 3, 4, 5, 6].map((dia) => (
                                <div key={dia} className="flex flex-col items-center">
                                  <label className="text-xs">{dia === 0 ? "D" : dia === 6 ? "S" : dia}</label>
                                  <input
                                    type="checkbox"
                                    checked={folga.dias.includes(dia)}
                                    onChange={(e) => {
                                      const novosDias = e.target.checked
                                        ? [...folga.dias, dia]
                                        : folga.dias.filter((d) => d !== dia)

                                      const novasFolgas = escalaEmEdicao
                                        ? [...escalaEmEdicao.folgas]
                                        : [...novaEscala.folgas]

                                      novasFolgas[index] = {
                                        ...novasFolgas[index],
                                        dias: novosDias,
                                      }

                                      if (escalaEmEdicao) {
                                        setEscalaEmEdicao({
                                          ...escalaEmEdicao,
                                          folgas: novasFolgas,
                                        })
                                      } else {
                                        setNovaEscala({
                                          ...novaEscala,
                                          folgas: novasFolgas,
                                        })
                                      }
                                    }}
                                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full"
                          onClick={() => {
                            const cicloSemanas = escalaEmEdicao ? escalaEmEdicao.cicloSemanas : novaEscala.cicloSemanas
                            const folgas = escalaEmEdicao ? escalaEmEdicao.folgas : novaEscala.folgas

                            // Encontrar a próxima semana disponível
                            const semanasExistentes = folgas.map((f) => f.semana)
                            let proximaSemana = 1
                            while (semanasExistentes.includes(proximaSemana) && proximaSemana <= cicloSemanas) {
                              proximaSemana++
                            }

                            if (proximaSemana > cicloSemanas) {
                              toast({
                                title: "Limite de semanas atingido",
                                description: `Você já definiu folgas para todas as ${cicloSemanas} semanas do ciclo.`,
                                variant: "destructive",
                              })
                              return
                            }

                            const novaFolga = {
                              semana: proximaSemana,
                              dias: [0], // Domingo por padrão
                            }

                            if (escalaEmEdicao) {
                              setEscalaEmEdicao({
                                ...escalaEmEdicao,
                                folgas: [...escalaEmEdicao.folgas, novaFolga],
                              })
                            } else {
                              setNovaEscala({
                                ...novaEscala,
                                folgas: [...novaEscala.folgas, novaFolga],
                              })
                            }
                          }}
                        >
                          <Plus className="mr-2 h-3 w-3" />
                          Adicionar Semana
                        </Button>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setEscalaDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={escalaEmEdicao ? salvarEdicaoEscala : adicionarEscala}>
                      {escalaEmEdicao ? "Salvar Alterações" : "Adicionar Escala"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Ciclo (Semanas)</TableHead>
                    <TableHead>Folgas</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {escalas.map((escala) => (
                    <TableRow key={escala.id}>
                      <TableCell className="font-medium">{escala.nome}</TableCell>
                      <TableCell>{escala.tipo}</TableCell>
                      <TableCell>{escala.cicloSemanas}</TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {escala.folgas.map((folga, index) => (
                            <div key={index} className="text-xs">
                              <span className="font-medium">Semana {folga.semana}:</span>{" "}
                              {folga.dias.map((dia) => getDiasSemana(dia)).join(", ")}
                            </div>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => editarEscala(escala)}>
                            <Edit className="h-4 w-4 text-blue-500" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => removerEscala(escala.id)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="atribuicoes" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Atribuições de Escalas</CardTitle>
                <CardDescription>Gerenciamento de escalas por funcionário</CardDescription>
              </div>
              <Dialog open={atribuirEscalaDialogOpen} onOpenChange={setAtribuirEscalaDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Atribuir Escala
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Atribuir Escala a Funcionário</DialogTitle>
                    <DialogDescription>Selecione o funcionário e a escala que deseja atribuir.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div>
                      <Label htmlFor="funcionario-escala">Funcionário</Label>
                      <Select value={funcionarioSelecionado} onValueChange={setFuncionarioSelecionado}>
                        <SelectTrigger id="funcionario-escala">
                          <SelectValue placeholder="Selecione o funcionário" />
                        </SelectTrigger>
                        <SelectContent>
                          {funcionarios.map((funcionario) => (
                            <SelectItem key={funcionario.id} value={funcionario.id}>
                              {funcionario.nome} - Turno {funcionario.turno}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="escala-atribuicao">Escala</Label>
                      <Select value={escalaSelecionada} onValueChange={setEscalaSelecionada}>
                        <SelectTrigger id="escala-atribuicao">
                          <SelectValue placeholder="Selecione a escala" />
                        </SelectTrigger>
                        <SelectContent>
                          {escalas.map((escala) => (
                            <SelectItem key={escala.id} value={escala.id}>
                              {escala.nome}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="data-inicio-escala">Data de Início</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !dataInicioEscala && "text-muted-foreground",
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {dataInicioEscala
                              ? format(dataInicioEscala, "PPP", { locale: ptBR })
                              : "Selecione uma data"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={dataInicioEscala}
                            onSelect={(date) => date && setDataInicioEscala(date)}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div>
                      <Label htmlFor="observacoes-escala">Observações</Label>
                      <Input
                        id="observacoes-escala"
                        value={observacoesEscala}
                        onChange={(e) => setObservacoesEscala(e.target.value)}
                        placeholder="Ex: Início do ciclo na semana 1"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setAtribuirEscalaDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={atribuirEscala}>Atribuir Escala</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Funcionário</TableHead>
                    <TableHead>Escala</TableHead>
                    <TableHead>Data de Início</TableHead>
                    <TableHead>Observações</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {funcionariosEscalas.map((fe) => (
                    <TableRow key={fe.funcionarioId}>
                      <TableCell className="font-medium">{getNomeFuncionario(fe.funcionarioId)}</TableCell>
                      <TableCell>{getNomeEscala(fe.escalaId)}</TableCell>
                      <TableCell>{format(fe.dataInicio, "dd/MM/yyyy")}</TableCell>
                      <TableCell>{fe.observacoes}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => removerAtribuicaoEscala(fe.funcionarioId)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
