"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { format } from "date-fns"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { CalendarIcon, Plus, Search } from "lucide-react"
import { Badge } from "@/components/ui/badge"

type TipoManutencao = "preventiva" | "corretiva" | "especificacao_tecnica"

type Manutencao = {
  id: string
  equipamento: string
  processo: string
  tipo: TipoManutencao
  dataHoraInicio: Date
  dataHoraFim?: Date
  turno: "A" | "B" | "C" | "ADM"
  responsavel: string
  pecasUtilizadas: string[]
  descricaoServico: string
  comentarios?: string
  status: "em_andamento" | "concluida" | "cancelada"
}

export default function ManutencoesDiarias() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("em_andamento")
  const [dialogNovaManutencaoAberto, setDialogNovaManutencaoAberto] = useState(false)
  const [filtroEquipamento, setFiltroEquipamento] = useState("")
  const [filtroPeriodo, setFiltroPeriodo] = useState<"hoje" | "semana" | "mes" | "todos">("todos")

  const [novaManutencao, setNovaManutencao] = useState<Omit<Manutencao, "id" | "status">>({
    equipamento: "",
    processo: "",
    tipo: "corretiva",
    dataHoraInicio: new Date(),
    turno: "A",
    responsavel: "",
    pecasUtilizadas: [],
    descricaoServico: "",
  })

  const [novaPeca, setNovaPeca] = useState("")

  // Estado para manutenções
  const [manutencoes, setManutencoes] = useState<Manutencao[]>([
    {
      id: "1",
      equipamento: "Bomba Centrífuga BC-101",
      processo: "Transferência de Efluente",
      tipo: "corretiva",
      dataHoraInicio: new Date(new Date().setHours(new Date().getHours() - 3)),
      dataHoraFim: new Date(),
      turno: "A",
      responsavel: "Carlos Santos",
      pecasUtilizadas: ['Selo mecânico 2"', "Rolamento 6205"],
      descricaoServico: "Substituição de selo mecânico com vazamento",
      comentarios: "Verificar alinhamento do acoplamento na próxima manutenção preventiva",
      status: "concluida",
    },
    {
      id: "2",
      equipamento: "Filtro Prensa FP-203",
      processo: "Desidratação de Lodo",
      tipo: "preventiva",
      dataHoraInicio: new Date(),
      turno: "B",
      responsavel: "Maria Oliveira",
      pecasUtilizadas: ["Óleo hidráulico 10L", "Filtro de óleo"],
      descricaoServico: "Troca de óleo hidráulico e filtro conforme cronograma",
      status: "em_andamento",
    },
    {
      id: "3",
      equipamento: "Soprador S-301",
      processo: "Aeração",
      tipo: "especificacao_tecnica",
      dataHoraInicio: new Date(new Date().setDate(new Date().getDate() - 1)),
      dataHoraFim: new Date(new Date().setDate(new Date().getDate() - 1)),
      turno: "C",
      responsavel: "Pedro Almeida",
      pecasUtilizadas: ["Kit de reparo", "Correia V 3L"],
      descricaoServico: "Ajuste de tensão das correias e verificação de vibração conforme especificação do fabricante",
      comentarios: "Vibração dentro dos parâmetros aceitáveis",
      status: "concluida",
    },
  ])

  // Função para adicionar nova manutenção
  const adicionarManutencao = () => {
    if (
      !novaManutencao.equipamento ||
      !novaManutencao.processo ||
      !novaManutencao.descricaoServico ||
      !novaManutencao.responsavel
    ) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (manutencoes.length + 1).toString()
    const manutencaoCompleta: Manutencao = {
      id: novoId,
      ...novaManutencao,
      status: "em_andamento",
    }

    setManutencoes([...manutencoes, manutencaoCompleta])
    setNovaManutencao({
      equipamento: "",
      processo: "",
      tipo: "corretiva",
      dataHoraInicio: new Date(),
      turno: "A",
      responsavel: "",
      pecasUtilizadas: [],
      descricaoServico: "",
    })
    setDialogNovaManutencaoAberto(false)

    toast({
      title: "Manutenção registrada",
      description: "A nova manutenção foi registrada com sucesso.",
    })
  }

  // Função para adicionar peça à lista
  const adicionarPeca = () => {
    if (!novaPeca.trim()) return

    setNovaManutencao({
      ...novaManutencao,
      pecasUtilizadas: [...novaManutencao.pecasUtilizadas, novaPeca.trim()],
    })
    setNovaPeca("")
  }

  // Função para remover peça da lista
  const removerPeca = (index: number) => {
    const novasPecas = [...novaManutencao.pecasUtilizadas]
    novasPecas.splice(index, 1)
    setNovaManutencao({
      ...novaManutencao,
      pecasUtilizadas: novasPecas,
    })
  }

  // Função para atualizar status da manutenção
  const atualizarStatusManutencao = (id: string, novoStatus: "em_andamento" | "concluida" | "cancelada") => {
    const manutencoesAtualizadas = manutencoes.map((manutencao) => {
      if (manutencao.id === id) {
        const manutencaoAtualizada = { ...manutencao, status: novoStatus }

        // Atualizar data de fim se concluída
        if (novoStatus === "concluida" && !manutencaoAtualizada.dataHoraFim) {
          manutencaoAtualizada.dataHoraFim = new Date()
        }

        return manutencaoAtualizada
      }
      return manutencao
    })

    setManutencoes(manutencoesAtualizadas)

    toast({
      title: "Status atualizado",
      description: "O status da manutenção foi atualizado com sucesso.",
    })
  }

  // Função para obter a cor do tipo de manutenção
  const getTipoManutencaoColor = (tipo: TipoManutencao) => {
    switch (tipo) {
      case "preventiva":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
      case "corretiva":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      case "especificacao_tecnica":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  // Função para obter o texto do tipo de manutenção
  const getTipoManutencaoText = (tipo: TipoManutencao) => {
    switch (tipo) {
      case "preventiva":
        return "Preventiva"
      case "corretiva":
        return "Corretiva"
      case "especificacao_tecnica":
        return "Especificação Técnica"
      default:
        return "Não definido"
    }
  }

  // Função para obter a cor do status
  const getStatusColor = (status: string) => {
    switch (status) {
      case "em_andamento":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
      case "concluida":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "cancelada":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  // Função para obter o texto do status
  const getStatusText = (status: string) => {
    switch (status) {
      case "em_andamento":
        return "Em Andamento"
      case "concluida":
        return "Concluída"
      case "cancelada":
        return "Cancelada"
      default:
        return "Não definido"
    }
  }

  // Filtrar manutenções por equipamento e período
  const filtrarManutencoes = (manutencoes: Manutencao[]) => {
    let manutencoesFiltradasPorEquipamento = manutencoes

    if (filtroEquipamento) {
      manutencoesFiltradasPorEquipamento = manutencoesFiltradasPorEquipamento.filter((m) =>
        m.equipamento.toLowerCase().includes(filtroEquipamento.toLowerCase()),
      )
    }

    let manutencoesFiltradasPorPeriodo = manutencoesFiltradasPorEquipamento

    if (filtroPeriodo !== "todos") {
      const hoje = new Date()
      hoje.setHours(0, 0, 0, 0)

      const umaSemanaAtras = new Date(hoje)
      umaSemanaAtras.setDate(hoje.getDate() - 7)

      const umMesAtras = new Date(hoje)
      umMesAtras.setMonth(hoje.getMonth() - 1)

      manutencoesFiltradasPorPeriodo = manutencoesFiltradasPorEquipamento.filter((m) => {
        const dataManutencao = new Date(m.dataHoraInicio)

        if (filtroPeriodo === "hoje") {
          return dataManutencao >= hoje
        } else if (filtroPeriodo === "semana") {
          return dataManutencao >= umaSemanaAtras
        } else if (filtroPeriodo === "mes") {
          return dataManutencao >= umMesAtras
        }

        return true
      })
    }

    return manutencoesFiltradasPorPeriodo
  }

  // Manutenções filtradas por status e outros filtros
  const manutencoesEmAndamento = filtrarManutencoes(manutencoes.filter((m) => m.status === "em_andamento"))

  const manutencoesConcluidas = filtrarManutencoes(
    manutencoes.filter((m) => m.status === "concluida" || m.status === "cancelada"),
  )

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Manutenções Diárias</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Filtrar por equipamento..."
            value={filtroEquipamento}
            onChange={(e) => setFiltroEquipamento(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select
          value={filtroPeriodo}
          onValueChange={(value: "hoje" | "semana" | "mes" | "todos") => setFiltroPeriodo(value)}
        >
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="hoje">Hoje</SelectItem>
            <SelectItem value="semana">Última semana</SelectItem>
            <SelectItem value="mes">Último mês</SelectItem>
            <SelectItem value="todos">Todos</SelectItem>
          </SelectContent>
        </Select>
        <Dialog open={dialogNovaManutencaoAberto} onOpenChange={setDialogNovaManutencaoAberto}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Nova Manutenção
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Registrar Nova Manutenção</DialogTitle>
              <DialogDescription>Preencha as informações para registrar uma nova manutenção.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div>
                <Label htmlFor="equipamento">Equipamento*</Label>
                <Input
                  id="equipamento"
                  value={novaManutencao.equipamento}
                  onChange={(e) => setNovaManutencao({ ...novaManutencao, equipamento: e.target.value })}
                  placeholder="Ex: Bomba Centrífuga BC-101"
                />
              </div>
              <div>
                <Label htmlFor="processo">Processo*</Label>
                <Input
                  id="processo"
                  value={novaManutencao.processo}
                  onChange={(e) => setNovaManutencao({ ...novaManutencao, processo: e.target.value })}
                  placeholder="Ex: Transferência de Efluente"
                />
              </div>
              <div>
                <Label htmlFor="tipo-manutencao">Tipo de Manutenção*</Label>
                <Select
                  value={novaManutencao.tipo}
                  onValueChange={(value: TipoManutencao) => setNovaManutencao({ ...novaManutencao, tipo: value })}
                >
                  <SelectTrigger id="tipo-manutencao">
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="preventiva">Preventiva</SelectItem>
                    <SelectItem value="corretiva">Corretiva</SelectItem>
                    <SelectItem value="especificacao_tecnica">Especificação Técnica</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="data-hora-inicio">Data/Hora Início*</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {novaManutencao.dataHoraInicio ? (
                          format(novaManutencao.dataHoraInicio, "dd/MM/yyyy HH:mm")
                        ) : (
                          <span>Selecione uma data</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={novaManutencao.dataHoraInicio}
                        onSelect={(date) => date && setNovaManutencao({ ...novaManutencao, dataHoraInicio: date })}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div>
                  <Label htmlFor="turno">Turno*</Label>
                  <Select
                    value={novaManutencao.turno}
                    onValueChange={(value: "A" | "B" | "C" | "ADM") =>
                      setNovaManutencao({ ...novaManutencao, turno: value })
                    }
                  >
                    <SelectTrigger id="turno">
                      <SelectValue placeholder="Selecione o turno" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A">Turno A</SelectItem>
                      <SelectItem value="B">Turno B</SelectItem>
                      <SelectItem value="C">Turno C</SelectItem>
                      <SelectItem value="ADM">ADM</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="responsavel">Responsável*</Label>
                <Input
                  id="responsavel"
                  value={novaManutencao.responsavel}
                  onChange={(e) => setNovaManutencao({ ...novaManutencao, responsavel: e.target.value })}
                  placeholder="Nome do responsável"
                />
              </div>
              <div>
                <Label htmlFor="descricao-servico">Descrição do Serviço*</Label>
                <Textarea
                  id="descricao-servico"
                  value={novaManutencao.descricaoServico}
                  onChange={(e) => setNovaManutencao({ ...novaManutencao, descricaoServico: e.target.value })}
                  placeholder="Descreva o serviço realizado"
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="pecas-utilizadas">Peças/Materiais Utilizados</Label>
                <div className="flex gap-2 mb-2">
                  <Input
                    id="pecas-utilizadas"
                    value={novaPeca}
                    onChange={(e) => setNovaPeca(e.target.value)}
                    placeholder="Ex: Rolamento 6205"
                    className="flex-1"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault()
                        adicionarPeca()
                      }
                    }}
                  />
                  <Button type="button" onClick={adicionarPeca} variant="secondary">
                    Adicionar
                  </Button>
                </div>
                {novaManutencao.pecasUtilizadas.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {novaManutencao.pecasUtilizadas.map((peca, index) => (
                      <Badge key={index} variant="secondary" className="flex items-center gap-1">
                        {peca}
                        <button
                          type="button"
                          className="ml-1 rounded-full h-4 w-4 inline-flex items-center justify-center text-xs hover:bg-muted"
                          onClick={() => removerPeca(index)}
                        >
                          ×
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
              <div>
                <Label htmlFor="comentarios">Comentários</Label>
                <Textarea
                  id="comentarios"
                  value={novaManutencao.comentarios || ""}
                  onChange={(e) => setNovaManutencao({ ...novaManutencao, comentarios: e.target.value })}
                  placeholder="Observações adicionais sobre a manutenção"
                  rows={2}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogNovaManutencaoAberto(false)}>
                Cancelar
              </Button>
              <Button onClick={adicionarManutencao}>Registrar Manutenção</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="em_andamento" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="em_andamento">Em Andamento</TabsTrigger>
          <TabsTrigger value="concluidas">Concluídas</TabsTrigger>
        </TabsList>

        <TabsContent value="em_andamento" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Manutenções em Andamento</CardTitle>
              <CardDescription>Manutenções que estão sendo executadas atualmente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {manutencoesEmAndamento.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Nenhuma manutenção em andamento encontrada.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {manutencoesEmAndamento.map((manutencao) => (
                      <Card key={manutencao.id} className="overflow-hidden">
                        <div className="h-2 bg-yellow-500" />
                        <CardContent className="p-6">
                          <div className="flex justify-between items-start">
                            <div>
                              <div className="flex items-center gap-2 mb-2">
                                <h3 className="text-lg font-medium">{manutencao.equipamento}</h3>
                                <span
                                  className={`px-3 py-1 rounded-full text-xs ${getTipoManutencaoColor(manutencao.tipo)}`}
                                >
                                  {getTipoManutencaoText(manutencao.tipo)}
                                </span>
                              </div>
                              <p className="text-sm text-muted-foreground">{manutencao.processo}</p>
                              <div className="mt-3 space-y-1">
                                <p className="text-sm">
                                  <span className="font-medium">Início:</span>{" "}
                                  {format(new Date(manutencao.dataHoraInicio), "dd/MM/yyyy HH:mm")}
                                </p>
                                <p className="text-sm">
                                  <span className="font-medium">Turno:</span> Turno {manutencao.turno}
                                </p>
                                <p className="text-sm">
                                  <span className="font-medium">Responsável:</span> {manutencao.responsavel}
                                </p>
                              </div>
                              <div className="mt-3">
                                <p className="text-sm font-medium">Descrição do Serviço:</p>
                                <p className="text-sm">{manutencao.descricaoServico}</p>
                              </div>
                              {manutencao.pecasUtilizadas.length > 0 && (
                                <div className="mt-3">
                                  <p className="text-sm font-medium">Peças/Materiais Utilizados:</p>
                                  <div className="flex flex-wrap gap-2 mt-1">
                                    {manutencao.pecasUtilizadas.map((peca, index) => (
                                      <Badge key={index} variant="outline">
                                        {peca}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                              {manutencao.comentarios && (
                                <div className="mt-3 p-2 bg-muted rounded-md">
                                  <p className="text-sm font-medium">Comentários:</p>
                                  <p className="text-sm">{manutencao.comentarios}</p>
                                </div>
                              )}
                            </div>
                            <div className="flex flex-col items-end gap-2">
                              <Select
                                value={manutencao.status}
                                onValueChange={(value: "em_andamento" | "concluida" | "cancelada") =>
                                  atualizarStatusManutencao(manutencao.id, value)
                                }
                              >
                                <SelectTrigger className="h-8 w-[130px]">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="em_andamento">Em Andamento</SelectItem>
                                  <SelectItem value="concluida">Concluída</SelectItem>
                                  <SelectItem value="cancelada">Cancelada</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="concluidas" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Manutenções Concluídas</CardTitle>
              <CardDescription>Histórico de manutenções concluídas ou canceladas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {manutencoesConcluidas.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">Nenhuma manutenção concluída encontrada.</div>
                ) : (
                  <div className="space-y-4">
                    {manutencoesConcluidas.map((manutencao) => (
                      <Card key={manutencao.id} className="overflow-hidden">
                        <div className={`h-2 ${manutencao.status === "concluida" ? "bg-green-500" : "bg-red-500"}`} />
                        <CardContent className="p-6">
                          <div className="flex justify-between items-start">
                            <div>
                              <div className="flex items-center gap-2 mb-2">
                                <h3 className="text-lg font-medium">{manutencao.equipamento}</h3>
                                <span
                                  className={`px-3 py-1 rounded-full text-xs ${getTipoManutencaoColor(manutencao.tipo)}`}
                                >
                                  {getTipoManutencaoText(manutencao.tipo)}
                                </span>
                                <span className={`px-3 py-1 rounded-full text-xs ${getStatusColor(manutencao.status)}`}>
                                  {getStatusText(manutencao.status)}
                                </span>
                              </div>
                              <p className="text-sm text-muted-foreground">{manutencao.processo}</p>
                              <div className="mt-3 space-y-1">
                                <p className="text-sm">
                                  <span className="font-medium">Início:</span>{" "}
                                  {format(new Date(manutencao.dataHoraInicio), "dd/MM/yyyy HH:mm")}
                                </p>
                                {manutencao.dataHoraFim && (
                                  <p className="text-sm">
                                    <span className="font-medium">Término:</span>{" "}
                                    {format(new Date(manutencao.dataHoraFim), "dd/MM/yyyy HH:mm")}
                                  </p>
                                )}
                                <p className="text-sm">
                                  <span className="font-medium">Turno:</span> Turno {manutencao.turno}
                                </p>
                                <p className="text-sm">
                                  <span className="font-medium">Responsável:</span> {manutencao.responsavel}
                                </p>
                              </div>
                              <div className="mt-3">
                                <p className="text-sm font-medium">Descrição do Serviço:</p>
                                <p className="text-sm">{manutencao.descricaoServico}</p>
                              </div>
                              {manutencao.pecasUtilizadas.length > 0 && (
                                <div className="mt-3">
                                  <p className="text-sm font-medium">Peças/Materiais Utilizados:</p>
                                  <div className="flex flex-wrap gap-2 mt-1">
                                    {manutencao.pecasUtilizadas.map((peca, index) => (
                                      <Badge key={index} variant="outline">
                                        {peca}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                              {manutencao.comentarios && (
                                <div className="mt-3 p-2 bg-muted rounded-md">
                                  <p className="text-sm font-medium">Comentários:</p>
                                  <p className="text-sm">{manutencao.comentarios}</p>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
