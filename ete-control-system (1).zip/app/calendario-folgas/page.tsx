"use client"

import { useState } from "react"
import { format, addDays, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { useToast } from "@/components/ui/use-toast"
import { CalendarIcon, Check, Clock } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

type SemanaEscala = "A" | "B" | "C"
type StatusFerias = "solicitado" | "aprovado" | "negado"

interface SolicitacaoFerias {
  id: string
  dataInicio: Date
  dataFim: Date
  status: StatusFerias
}

export default function CalendarioFolgas() {
  const { toast } = useToast()
  const [semanaAtual, setSemanaAtual] = useState<SemanaEscala>("A")
  const [mesAtual, setMesAtual] = useState<Date>(new Date())
  const [solicitacaoFerias, setSolicitacaoFerias] = useState<{
    dataInicio: Date | undefined
    dataFim: Date | undefined
  }>({
    dataInicio: undefined,
    dataFim: undefined,
  })
  const [solicitacoes, setSolicitacoes] = useState<SolicitacaoFerias[]>([
    {
      id: "1",
      dataInicio: addDays(new Date(), 30),
      dataFim: addDays(new Date(), 44),
      status: "solicitado",
    },
    {
      id: "2",
      dataInicio: addDays(new Date(), 60),
      dataFim: addDays(new Date(), 74),
      status: "aprovado",
    },
  ])

  // Função para verificar se uma data é folga com base na semana da escala
  const isFolga = (date: Date) => {
    const dia = date.getDay() // 0 = domingo, 6 = sábado

    // Lógica para determinar se é folga com base na semana atual
    if (semanaAtual === "A") {
      return dia === 0 // Domingo é folga na semana A
    } else if (semanaAtual === "B") {
      return dia === 6 // Sábado é folga na semana B
    } else if (semanaAtual === "C") {
      return dia === 0 || dia === 6 // Sábado e domingo são folgas na semana C
    }

    return false
  }

  // Função para verificar se uma data está dentro de alguma solicitação de férias
  const verificarFerias = (date: Date): { emFerias: boolean; status: StatusFerias | null } => {
    for (const solicitacao of solicitacoes) {
      if (date >= solicitacao.dataInicio && date <= solicitacao.dataFim) {
        return { emFerias: true, status: solicitacao.status }
      }
    }
    return { emFerias: false, status: null }
  }

  // Função para solicitar férias
  const solicitarFerias = () => {
    if (!solicitacaoFerias.dataInicio || !solicitacaoFerias.dataFim) {
      toast({
        title: "Erro na solicitação",
        description: "Selecione as datas de início e fim das férias.",
        variant: "destructive",
      })
      return
    }

    // Verificar se o período é válido (mínimo 14 dias, máximo 30 dias)
    const diffTime = Math.abs(solicitacaoFerias.dataFim.getTime() - solicitacaoFerias.dataInicio.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1

    if (diffDays < 14) {
      toast({
        title: "Período inválido",
        description: "O período mínimo de férias é de 14 dias.",
        variant: "destructive",
      })
      return
    }

    if (diffDays > 30) {
      toast({
        title: "Período inválido",
        description: "O período máximo de férias é de 30 dias.",
        variant: "destructive",
      })
      return
    }

    // Adicionar nova solicitação
    const novaSolicitacao: SolicitacaoFerias = {
      id: Date.now().toString(),
      dataInicio: solicitacaoFerias.dataInicio,
      dataFim: solicitacaoFerias.dataFim,
      status: "solicitado",
    }

    setSolicitacoes([...solicitacoes, novaSolicitacao])
    setSolicitacaoFerias({ dataInicio: undefined, dataFim: undefined })

    toast({
      title: "Solicitação enviada",
      description: `Férias solicitadas de ${format(solicitacaoFerias.dataInicio, "dd/MM/yyyy")} a ${format(
        solicitacaoFerias.dataFim,
        "dd/MM/yyyy",
      )}.`,
    })
  }

  // Função para aprovar uma solicitação (simulação)
  const aprovarSolicitacao = (id: string) => {
    setSolicitacoes(solicitacoes.map((sol) => (sol.id === id ? { ...sol, status: "aprovado" as StatusFerias } : sol)))

    toast({
      title: "Solicitação aprovada",
      description: "A solicitação de férias foi aprovada com sucesso.",
    })
  }

  // Função para negar uma solicitação (simulação)
  const negarSolicitacao = (id: string) => {
    setSolicitacoes(solicitacoes.map((sol) => (sol.id === id ? { ...sol, status: "negado" as StatusFerias } : sol)))

    toast({
      title: "Solicitação negada",
      description: "A solicitação de férias foi negada.",
      variant: "destructive",
    })
  }

  // Renderizar dias do mês atual com indicação de folgas e férias
  const renderDiasMes = () => {
    const diasDoMes = eachDayOfInterval({
      start: startOfMonth(mesAtual),
      end: endOfMonth(mesAtual),
    })

    return (
      <div className="grid grid-cols-7 gap-1">
        {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((dia) => (
          <div key={dia} className="text-center font-medium py-2">
            {dia}
          </div>
        ))}

        {diasDoMes.map((dia) => {
          const { emFerias, status } = verificarFerias(dia)
          const folga = isFolga(dia)

          let bgClass = ""
          if (emFerias) {
            bgClass =
              status === "solicitado"
                ? "bg-yellow-100 dark:bg-yellow-900/20"
                : status === "aprovado"
                  ? "bg-green-100 dark:bg-green-900/20"
                  : "bg-red-100 dark:bg-red-900/20"
          } else if (folga) {
            bgClass = "bg-blue-100 dark:bg-blue-900/20"
          }

          return (
            <div
              key={dia.toString()}
              className={`border rounded-md p-2 text-center ${bgClass} ${
                !isSameMonth(dia, mesAtual) ? "text-muted-foreground" : ""
              } ${isSameDay(dia, new Date()) ? "border-primary" : ""}`}
            >
              <div>{format(dia, "d")}</div>
              {folga && <div className="text-xs mt-1">Folga</div>}
              {emFerias && (
                <div className="text-xs mt-1">
                  {status === "solicitado" ? "Solicitado" : status === "aprovado" ? "Aprovado" : "Negado"}
                </div>
              )}
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Calendário de Folgas e Férias</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Calendário - {format(mesAtual, "MMMM yyyy", { locale: ptBR })}</CardTitle>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setMesAtual(new Date(mesAtual.getFullYear(), mesAtual.getMonth() - 1, 1))}
                >
                  Anterior
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setMesAtual(new Date(mesAtual.getFullYear(), mesAtual.getMonth() + 1, 1))}
                >
                  Próximo
                </Button>
              </div>
            </div>
            <CardDescription>
              Visualize suas folgas e férias. Semana atual: <strong>{semanaAtual}</strong>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <Label htmlFor="semana-escala">Semana da Escala</Label>
              <Select value={semanaAtual} onValueChange={(value: SemanaEscala) => setSemanaAtual(value)}>
                <SelectTrigger id="semana-escala" className="w-full md:w-[200px]">
                  <SelectValue placeholder="Selecione a semana" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">Semana A (Folga no Domingo)</SelectItem>
                  <SelectItem value="B">Semana B (Folga no Sábado)</SelectItem>
                  <SelectItem value="C">Semana C (Folga no Sábado e Domingo)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="overflow-x-auto">{renderDiasMes()}</div>

            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-blue-100 dark:bg-blue-900/20"></div>
                <span className="text-sm">Folga</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-yellow-100 dark:bg-yellow-900/20"></div>
                <span className="text-sm">Férias Solicitadas</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-green-100 dark:bg-green-900/20"></div>
                <span className="text-sm">Férias Aprovadas</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-red-100 dark:bg-red-900/20"></div>
                <span className="text-sm">Férias Negadas</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Solicitar Férias</CardTitle>
              <CardDescription>Selecione o período desejado para suas férias</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="data-inicio">Data de Início</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {solicitacaoFerias.dataInicio ? (
                        format(solicitacaoFerias.dataInicio, "PPP", { locale: ptBR })
                      ) : (
                        <span>Selecione uma data</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={solicitacaoFerias.dataInicio}
                      onSelect={(date) => date && setSolicitacaoFerias({ ...solicitacaoFerias, dataInicio: date })}
                      initialFocus
                      disabled={(date) => date < new Date()}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <Label htmlFor="data-fim">Data de Fim</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {solicitacaoFerias.dataFim ? (
                        format(solicitacaoFerias.dataFim, "PPP", { locale: ptBR })
                      ) : (
                        <span>Selecione uma data</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={solicitacaoFerias.dataFim}
                      onSelect={(date) => date && setSolicitacaoFerias({ ...solicitacaoFerias, dataFim: date })}
                      initialFocus
                      disabled={(date) =>
                        date < new Date() ||
                        (solicitacaoFerias.dataInicio ? date < solicitacaoFerias.dataInicio : false)
                      }
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={solicitarFerias}>
                Solicitar Férias
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Solicitações de Férias</CardTitle>
              <CardDescription>Acompanhe o status das suas solicitações</CardDescription>
            </CardHeader>
            <CardContent>
              {solicitacoes.length > 0 ? (
                <div className="space-y-3">
                  {solicitacoes.map((solicitacao) => (
                    <div
                      key={solicitacao.id}
                      className={`border rounded-md p-3 ${
                        solicitacao.status === "solicitado"
                          ? "border-yellow-200 bg-yellow-50 dark:bg-yellow-900/10"
                          : solicitacao.status === "aprovado"
                            ? "border-green-200 bg-green-50 dark:bg-green-900/10"
                            : "border-red-200 bg-red-50 dark:bg-red-900/10"
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">
                            {format(solicitacao.dataInicio, "dd/MM/yyyy")} até{" "}
                            {format(solicitacao.dataFim, "dd/MM/yyyy")}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {solicitacao.status === "solicitado" ? (
                              <span className="flex items-center">
                                <Clock className="h-3 w-3 mr-1" /> Aguardando aprovação
                              </span>
                            ) : solicitacao.status === "aprovado" ? (
                              <span className="flex items-center">
                                <Check className="h-3 w-3 mr-1" /> Aprovado
                              </span>
                            ) : (
                              "Negado"
                            )}
                          </p>
                        </div>
                        {solicitacao.status === "solicitado" && (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8 bg-green-100 hover:bg-green-200 dark:bg-green-900/20 dark:hover:bg-green-900/30"
                              onClick={() => aprovarSolicitacao(solicitacao.id)}
                            >
                              Aprovar
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8 bg-red-100 hover:bg-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/30"
                              onClick={() => negarSolicitacao(solicitacao.id)}
                            >
                              Negar
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-4">Nenhuma solicitação de férias.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
