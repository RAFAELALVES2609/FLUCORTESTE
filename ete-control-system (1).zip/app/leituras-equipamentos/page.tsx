"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Download, Save } from "lucide-react"

type LeituraHidrometro = {
  turno: string
  vazao: string
  somatorio: string
  diferenca: string
}

export default function LeiturasEquipamentos() {
  const { toast } = useToast()
  const [data, setData] = useState(new Date().toISOString().split("T")[0])
  const [turnoAtual, setTurnoAtual] = useState("A")
  const [mediaVazao, setMediaVazao] = useState("0")

  const [leituras, setLeituras] = useState<LeituraHidrometro[]>([
    { turno: "A", vazao: "", somatorio: "", diferenca: "" },
    { turno: "B", vazao: "", somatorio: "", diferenca: "" },
    { turno: "C", vazao: "", somatorio: "", diferenca: "" },
  ])

  // Função para calcular diferenças e média
  const calcularDiferencasEMedia = (leiturasAtuais: LeituraHidrometro[]) => {
    // Criar uma cópia para não modificar o estado diretamente
    const leiturasAtualizadas = [...leiturasAtuais]

    // Calcular diferenças
    for (let i = 1; i < leiturasAtualizadas.length; i++) {
      const somaAnterior = Number.parseFloat(leiturasAtualizadas[i - 1].somatorio) || 0
      const somaAtual = Number.parseFloat(leiturasAtualizadas[i].somatorio) || 0

      if (somaAnterior > 0 && somaAtual > 0) {
        leiturasAtualizadas[i].diferenca = (somaAtual - somaAnterior).toFixed(2)
      } else {
        leiturasAtualizadas[i].diferenca = ""
      }
    }

    // Calcular média de vazão
    const vazoes = leiturasAtualizadas
      .map((leitura) => Number.parseFloat(leitura.vazao))
      .filter((vazao) => !isNaN(vazao))
    let novaMedia = "0"

    if (vazoes.length > 0) {
      const soma = vazoes.reduce((acc, curr) => acc + curr, 0)
      novaMedia = (soma / vazoes.length).toFixed(2)
    }

    return { leiturasAtualizadas, novaMedia }
  }

  // Executar apenas uma vez na montagem do componente
  useEffect(() => {
    const { leiturasAtualizadas, novaMedia } = calcularDiferencasEMedia(leituras)
    setLeituras(leiturasAtualizadas)
    setMediaVazao(novaMedia)
    // Array de dependências vazio para executar apenas uma vez
  }, [])

  const atualizarLeitura = (turno: string, campo: "vazao" | "somatorio", valor: string) => {
    // Usar o padrão de atualização funcional para evitar problemas com fechamentos (closures)
    setLeituras((leiturasAtuais) => {
      const novasLeituras = leiturasAtuais.map((leitura) =>
        leitura.turno === turno ? { ...leitura, [campo]: valor } : leitura,
      )

      // Calcular diferenças e média imediatamente após a atualização
      const { leiturasAtualizadas, novaMedia } = calcularDiferencasEMedia(novasLeituras)

      // Atualizar a média de vazão
      setMediaVazao(novaMedia)

      return leiturasAtualizadas
    })
  }

  const salvarDados = () => {
    toast({
      title: "Dados salvos com sucesso!",
      description: `Leituras do turno ${turnoAtual} atualizadas para ${data}.`,
    })
  }

  const gerarRelatorio = () => {
    toast({
      title: "Relatório gerado!",
      description: "O relatório de leituras foi gerado e está disponível para download.",
    })
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Leituras de Equipamentos e Medições</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="w-full md:w-1/3">
          <Label htmlFor="data-leitura">Data</Label>
          <Input id="data-leitura" type="date" value={data} onChange={(e) => setData(e.target.value)} />
        </div>
        <div className="w-full md:w-1/3">
          <Label htmlFor="turno-leitura">Turno Atual</Label>
          <Select value={turnoAtual} onValueChange={setTurnoAtual}>
            <SelectTrigger id="turno-leitura">
              <SelectValue placeholder="Selecione o turno" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="A">Turno A</SelectItem>
              <SelectItem value="B">Turno B</SelectItem>
              <SelectItem value="C">Turno C</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="w-full md:w-1/3 flex items-end">
          <Button onClick={salvarDados} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Salvar Dados
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Leitura do Hidrômetro</CardTitle>
          <CardDescription>Registro de leituras por turno</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Turno</TableHead>
                <TableHead>m³/h</TableHead>
                <TableHead>∑M³</TableHead>
                <TableHead>Diferença</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leituras.map((leitura) => (
                <TableRow key={leitura.turno}>
                  <TableCell className="font-medium">Turno {leitura.turno}</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={leitura.vazao}
                      onChange={(e) => atualizarLeitura(leitura.turno, "vazao", e.target.value)}
                      disabled={turnoAtual !== leitura.turno}
                      placeholder="Vazão"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={leitura.somatorio}
                      onChange={(e) => atualizarLeitura(leitura.turno, "somatorio", e.target.value)}
                      disabled={turnoAtual !== leitura.turno}
                      placeholder="Somatório"
                    />
                  </TableCell>
                  <TableCell>{leitura.diferenca}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-lg">
            <span className="font-medium">Média de Vazão Diária:</span> {mediaVazao} m³/h
          </div>
          <Button variant="outline" onClick={gerarRelatorio}>
            <Download className="mr-2 h-4 w-4" />
            Gerar Relatório
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
