"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Download, Plus, Save } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Tipo para insumos
type Insumo = {
  id: string
  codigo: string
  descricao: string
  disponivel: number
  minimo: number
  critico: number
  maximo: number
  saldo: number
  manhaSaldo?: number
  tardeSaldo?: number
}

export default function ControleEstoque() {
  const { toast } = useToast()
  const [turno, setTurno] = useState("manha")
  const [data, setData] = useState(new Date().toISOString().split("T")[0])
  const [novoInsumo, setNovoInsumo] = useState<Omit<Insumo, "id" | "saldo"> & { id?: string; saldo?: number }>({
    codigo: "",
    descricao: "",
    disponivel: 0,
    minimo: 0,
    critico: 0,
    maximo: 0,
  })
  const [dialogOpen, setDialogOpen] = useState(false)

  // Estado inicial para os insumos
  const [insumos, setInsumos] = useState<Insumo[]>([
    {
      id: "1",
      codigo: "PAC 18%",
      descricao: "POLICLORETO DE ALUMINIO -PAC 18%",
      disponivel: 1000,
      minimo: 500,
      critico: 300,
      maximo: 2000,
      saldo: 1000,
      manhaSaldo: 1000,
      tardeSaldo: 950,
    },
    {
      id: "2",
      codigo: "HIDRÓXIDO DE CÁLCIO",
      descricao: "HIDROXIDO DE CÁLCIO HIDRATADA (CAL QUÍMICO)",
      disponivel: 800,
      minimo: 400,
      critico: 200,
      maximo: 1500,
      saldo: 800,
      manhaSaldo: 800,
      tardeSaldo: 750,
    },
    {
      id: "3",
      codigo: "ÁCIDO FOSFÓRICO",
      descricao: "ÁCIDO FOSFÓRICO INDUSTRIAL SOLUÇÃO 75%",
      disponivel: 600,
      minimo: 300,
      critico: 150,
      maximo: 1200,
      saldo: 600,
      manhaSaldo: 600,
      tardeSaldo: 580,
    },
    {
      id: "4",
      codigo: "SNF FLONEX 910SH",
      descricao: "POLÍMERO ANIÔNICO – FLONEX 910SH",
      disponivel: 400,
      minimo: 200,
      critico: 100,
      maximo: 800,
      saldo: 400,
      manhaSaldo: 400,
      tardeSaldo: 380,
    },
    {
      id: "5",
      codigo: "SNF FLONE 4190SH",
      descricao: "POLÍMERO CATIÔNICO – FLONE 4190SH",
      disponivel: 350,
      minimo: 200,
      critico: 100,
      maximo: 700,
      saldo: 350,
      manhaSaldo: 350,
      tardeSaldo: 330,
    },
    {
      id: "6",
      codigo: "SNF FLONE 4350SH",
      descricao: "POLÍMERO CATIÔNICO – FLONE 4350SH",
      disponivel: 300,
      minimo: 150,
      critico: 80,
      maximo: 600,
      saldo: 300,
      manhaSaldo: 300,
      tardeSaldo: 280,
    },
    {
      id: "7",
      codigo: "BARRILHA LEVE",
      descricao: "BARRILHA LEVE – CARBONATO DE SÓDIO SÓLIDO",
      disponivel: 250,
      minimo: 150,
      critico: 80,
      maximo: 500,
      saldo: 250,
      manhaSaldo: 250,
      tardeSaldo: 230,
    },
    {
      id: "8",
      codigo: "ANTIESPUMANTE",
      descricao: "ANTIESPUMANTE KG",
      disponivel: 100,
      minimo: 50,
      critico: 30,
      maximo: 200,
      saldo: 100,
      manhaSaldo: 100,
      tardeSaldo: 90,
    },
    {
      id: "9",
      codigo: "ALUMINATO DE SÓDIO",
      descricao: "ALUMINATO DE SÓDIO (NaAIO2)",
      disponivel: 200,
      minimo: 100,
      critico: 50,
      maximo: 400,
      saldo: 200,
      manhaSaldo: 200,
      tardeSaldo: 180,
    },
  ])

  const atualizarSaldoInsumo = (id: string, valor: number) => {
    setInsumos((prev) =>
      prev.map((insumo) =>
        insumo.id === id
          ? {
              ...insumo,
              ...(turno === "manha"
                ? { manhaSaldo: valor, disponivel: valor }
                : { tardeSaldo: valor, disponivel: valor }),
              saldo: turno === "manha" ? valor : insumo.saldo,
            }
          : insumo,
      ),
    )
  }

  const adicionarInsumo = () => {
    if (!novoInsumo.codigo || !novoInsumo.descricao) {
      toast({
        title: "Erro ao adicionar insumo",
        description: "Código e descrição são obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (insumos.length + 1).toString()
    const insumoCompleto: Insumo = {
      id: novoId,
      codigo: novoInsumo.codigo,
      descricao: novoInsumo.descricao,
      disponivel: novoInsumo.disponivel,
      minimo: novoInsumo.minimo,
      critico: novoInsumo.critico,
      maximo: novoInsumo.maximo,
      saldo: novoInsumo.disponivel,
      manhaSaldo: novoInsumo.disponivel,
      tardeSaldo: novoInsumo.disponivel,
    }

    setInsumos([...insumos, insumoCompleto])
    setNovoInsumo({
      codigo: "",
      descricao: "",
      disponivel: 0,
      minimo: 0,
      critico: 0,
      maximo: 0,
    })
    setDialogOpen(false)

    toast({
      title: "Insumo adicionado",
      description: "O novo insumo foi adicionado com sucesso.",
    })
  }

  const salvarDados = () => {
    toast({
      title: "Dados salvos com sucesso!",
      description: `Estoque do turno da ${turno} atualizado para ${data}.`,
    })
  }

  const gerarRelatorio = () => {
    toast({
      title: "Relatório gerado!",
      description: "O relatório de estoque foi gerado e está disponível para download.",
    })
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Controle de Estoque Físico da Unidade</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="w-full md:w-1/3">
          <Label htmlFor="data-estoque">Data</Label>
          <Input id="data-estoque" type="date" value={data} onChange={(e) => setData(e.target.value)} />
        </div>
        <div className="w-full md:w-1/3">
          <Label htmlFor="turno-estoque">Turno</Label>
          <Tabs value={turno} onValueChange={setTurno} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="manha">Manhã</TabsTrigger>
              <TabsTrigger value="tarde">Tarde</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        <div className="w-full md:w-1/3 flex items-end">
          <Button onClick={salvarDados} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Salvar Dados
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Estoque de Insumos - Conferência Física</CardTitle>
            <CardDescription>Controle de estoque por turno</CardDescription>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Novo Insumo
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar Novo Insumo</DialogTitle>
                <DialogDescription>
                  Preencha as informações do novo insumo para adicionar ao controle de estoque.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="codigo">Código</Label>
                    <Input
                      id="codigo"
                      value={novoInsumo.codigo}
                      onChange={(e) => setNovoInsumo({ ...novoInsumo, codigo: e.target.value })}
                      placeholder="Código do insumo"
                    />
                  </div>
                  <div>
                    <Label htmlFor="disponivel">Disponível</Label>
                    <Input
                      id="disponivel"
                      type="number"
                      value={novoInsumo.disponivel}
                      onChange={(e) => setNovoInsumo({ ...novoInsumo, disponivel: Number(e.target.value) })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="descricao">Descrição</Label>
                  <Input
                    id="descricao"
                    value={novoInsumo.descricao}
                    onChange={(e) => setNovoInsumo({ ...novoInsumo, descricao: e.target.value })}
                    placeholder="Descrição completa do insumo"
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="minimo">Mínimo</Label>
                    <Input
                      id="minimo"
                      type="number"
                      value={novoInsumo.minimo}
                      onChange={(e) => setNovoInsumo({ ...novoInsumo, minimo: Number(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="critico">Crítico</Label>
                    <Input
                      id="critico"
                      type="number"
                      value={novoInsumo.critico}
                      onChange={(e) => setNovoInsumo({ ...novoInsumo, critico: Number(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="maximo">Máximo</Label>
                    <Input
                      id="maximo"
                      type="number"
                      value={novoInsumo.maximo}
                      onChange={(e) => setNovoInsumo({ ...novoInsumo, maximo: Number(e.target.value) })}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={adicionarInsumo}>Adicionar Insumo</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Disponível</TableHead>
                <TableHead>Mínimo</TableHead>
                <TableHead>Crítico</TableHead>
                <TableHead>Máximo</TableHead>
                <TableHead>Saldo</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {insumos.map((insumo) => (
                <TableRow
                  key={insumo.id}
                  className={
                    insumo.disponivel <= insumo.critico
                      ? "bg-red-100 dark:bg-red-900/20"
                      : insumo.disponivel <= insumo.minimo
                        ? "bg-yellow-100 dark:bg-yellow-900/20"
                        : ""
                  }
                >
                  <TableCell className="font-medium">{insumo.codigo}</TableCell>
                  <TableCell>{insumo.descricao}</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={turno === "manha" ? insumo.manhaSaldo : insumo.tardeSaldo}
                      onChange={(e) => atualizarSaldoInsumo(insumo.id, Number(e.target.value))}
                      className={
                        insumo.disponivel <= insumo.critico
                          ? "border-red-500"
                          : insumo.disponivel <= insumo.minimo
                            ? "border-yellow-500"
                            : ""
                      }
                    />
                  </TableCell>
                  <TableCell>{insumo.minimo}</TableCell>
                  <TableCell>{insumo.critico}</TableCell>
                  <TableCell>{insumo.maximo}</TableCell>
                  <TableCell>{insumo.saldo}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={gerarRelatorio}>
            <Download className="mr-2 h-4 w-4" />
            Gerar Relatório para Compras
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
