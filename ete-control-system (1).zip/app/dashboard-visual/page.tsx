"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { TankIcon } from "@/components/icons/tank-icon"
import { TruckIcon } from "@/components/icons/truck-icon"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertCircle, Calendar, CheckCircle, Clock, Download, Info } from "lucide-react"

export default function DashboardVisual() {
  const [areaAtiva, setAreaAtiva] = useState("oleosos")

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Dashboard Visual da Planta</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="w-full md:w-1/2">
          <Label htmlFor="area-filtro">Área da Planta</Label>
          <Select value={areaAtiva} onValueChange={setAreaAtiva}>
            <SelectTrigger id="area-filtro">
              <SelectValue placeholder="Selecione a área" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="oleosos">Tanques Oleosos</SelectItem>
              <SelectItem value="fisico-quimico">Físico Químico</SelectItem>
              <SelectItem value="concentrado">Concentrado/Beneficiamento</SelectItem>
              <SelectItem value="lodo">Tratamento de Lodo</SelectItem>
              <SelectItem value="biologico">Tratamento Biológico</SelectItem>
              <SelectItem value="terciario">Tratamento Terciário</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="w-full md:w-1/2 flex items-end">
          <Button variant="outline" className="w-full">
            <Download className="mr-2 h-4 w-4" />
            Exportar Diagrama
          </Button>
        </div>
      </div>

      <Tabs defaultValue="diagrama" className="w-full">
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="diagrama">Diagrama da Planta</TabsTrigger>
          <TabsTrigger value="atividades">Atividades e Ocorrências</TabsTrigger>
        </TabsList>

        <TabsContent value="diagrama">
          <Card>
            <CardHeader>
              <CardTitle>Diagrama Visual - {getAreaTitle(areaAtiva)}</CardTitle>
              <CardDescription>Visualização dos tanques e status atual</CardDescription>
            </CardHeader>
            <CardContent>
              {areaAtiva === "oleosos" && <DiagramaOleosos />}
              {areaAtiva === "fisico-quimico" && <DiagramaFisicoQuimico />}
              {areaAtiva === "concentrado" && <DiagramaConcentrado />}
              {areaAtiva === "lodo" && <DiagramaLodo />}
              {areaAtiva === "biologico" && <DiagramaBiologico />}
              {areaAtiva === "terciario" && <DiagramaTerciario />}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="atividades">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                  Ocorrências Operacionais
                </CardTitle>
                <CardDescription>Ocorrências registradas hoje</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="border rounded-md p-3 bg-red-50 dark:bg-red-900/10">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">Vazamento</h4>
                        <p className="text-sm text-muted-foreground">
                          Pequeno vazamento identificado na tubulação do TQ 34
                        </p>
                      </div>
                      <Badge variant="outline" className="bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300">
                        Crítico
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>Registrado às 08:15</span>
                    </div>
                  </div>

                  <div className="border rounded-md p-3 bg-yellow-50 dark:bg-yellow-900/10">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">Manutenção</h4>
                        <p className="text-sm text-muted-foreground">Manutenção preventiva na bomba B-2 em andamento</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
                      >
                        Em andamento
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>Registrado às 09:30</span>
                    </div>
                  </div>

                  <div className="border rounded-md p-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">Falha</h4>
                        <p className="text-sm text-muted-foreground">Falha no sensor de nível do TQ 43 corrigida</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
                      >
                        Resolvido
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>Registrado às 07:45</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-blue-500" />
                  Próximas Atividades
                </CardTitle>
                <CardDescription>Atividades programadas para hoje</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="border rounded-md p-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">Transferência</h4>
                        <p className="text-sm text-muted-foreground">Transferência do TQ 41 para TQ 42</p>
                        <p className="text-xs text-muted-foreground mt-1">Responsável: João Silva</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
                      >
                        Em andamento
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>10:00 - 12:00</span>
                    </div>
                  </div>

                  <div className="border rounded-md p-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">Carregamento</h4>
                        <p className="text-sm text-muted-foreground">Carregamento de caminhão no TQ 64</p>
                        <p className="text-xs text-muted-foreground mt-1">Responsável: Carlos Santos</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
                      >
                        Pendente
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>14:00 - 15:30</span>
                    </div>
                  </div>

                  <div className="border rounded-md p-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">Limpeza</h4>
                        <p className="text-sm text-muted-foreground">Limpeza dos filtros do sistema terciário</p>
                        <p className="text-xs text-muted-foreground mt-1">Responsável: Equipe Manutenção</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
                      >
                        Concluído
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <CheckCircle className="h-3 w-3" />
                      <span>Concluído às 09:15</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TruckIcon status="loading" size="sm" className="mr-1" />
                  Próximos Carregamentos
                </CardTitle>
                <CardDescription>Carregamentos programados</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border rounded-md p-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">TQ 64 → Unidade de Tratamento Externa</h4>
                        <p className="text-sm text-muted-foreground">Transportadora: TransEfluentes Ltda</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
                      >
                        Em andamento
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>Hoje, 10:30 - 12:00</span>
                    </div>
                  </div>

                  <div className="border rounded-md p-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">TQ 61 → Unidade de Beneficiamento</h4>
                        <p className="text-sm text-muted-foreground">Transportadora: LogiTrans S.A.</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
                      >
                        Pendente
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>Amanhã, 08:00 - 09:30</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function getAreaTitle(area: string) {
  switch (area) {
    case "oleosos":
      return "Tanques Oleosos"
    case "fisico-quimico":
      return "Físico Químico"
    case "concentrado":
      return "Concentrado/Beneficiamento"
    case "lodo":
      return "Tratamento de Lodo"
    case "biologico":
      return "Tratamento Biológico"
    case "terciario":
      return "Tratamento Terciário/Polimento"
    default:
      return ""
  }
}

function DiagramaOleosos() {
  return (
    <div className="relative bg-gray-100 dark:bg-gray-800 p-6 rounded-lg min-h-[500px]">
      <div className="absolute top-4 right-4">
        <Badge variant="outline" className="flex items-center gap-1">
          <Info className="h-3 w-3" />
          Atualizado: 02/05/2025 08:30
        </Badge>
      </div>

      {/* Linha de tanques */}
      <div className="flex flex-wrap justify-center gap-8 mb-12">
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={85} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 31</span>
          <span className="text-xs">4250 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={65} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 32</span>
          <span className="text-xs">3250 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={30} status="warning" size="lg" />
          <span className="mt-2 font-medium">TQ 33</span>
          <span className="text-xs">1500 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={10} status="critical" size="lg" />
          <span className="mt-2 font-medium">TQ 34</span>
          <span className="text-xs">500 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={50} status="maintenance" size="lg" />
          <span className="mt-2 font-medium">TQ 35</span>
          <span className="text-xs">2500 m³</span>
        </div>
      </div>

      {/* Próximo carregamento */}
      <div className="flex justify-center gap-16 mb-12">
        <div className="flex flex-col items-center">
          <TruckIcon status="loading" size="lg" />
          <span className="mt-1 text-sm">Próximo Carregamento</span>
          <span className="text-xs">TQ 34 → Unidade Externa</span>
          <span className="text-xs">Hoje, 14:30</span>
        </div>
      </div>

      {/* Alertas */}
      <div className="absolute bottom-4 left-4 right-4">
        <div className="bg-red-100 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-2 flex items-start gap-2">
          <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800 dark:text-red-300">Alerta: Nível crítico no TQ 34</p>
            <p className="text-xs text-red-700 dark:text-red-400">Programar transferência ou descarga imediata</p>
          </div>
        </div>
      </div>
    </div>
  )
}

function DiagramaFisicoQuimico() {
  return (
    <div className="relative bg-gray-100 dark:bg-gray-800 p-6 rounded-lg min-h-[500px]">
      <div className="absolute top-4 right-4">
        <Badge variant="outline" className="flex items-center gap-1">
          <Info className="h-3 w-3" />
          Atualizado: 02/05/2025 08:30
        </Badge>
      </div>

      {/* Linha de tanques */}
      <div className="flex flex-wrap justify-center gap-8 mb-12">
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={75} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 41</span>
          <span className="text-xs">3000 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={60} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 42</span>
          <span className="text-xs">2400 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={90} status="warning" size="lg" />
          <span className="mt-2 font-medium">TQ 43</span>
          <span className="text-xs">3600 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={45} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 44</span>
          <span className="text-xs">1800 m³</span>
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-8 mb-12">
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={55} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 51</span>
          <span className="text-xs">1650 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={40} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 52</span>
          <span className="text-xs">1200 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={25} status="warning" size="lg" />
          <span className="mt-2 font-medium">TQ 53</span>
          <span className="text-xs">750 m³</span>
        </div>
      </div>

      {/* Alertas */}
      <div className="absolute bottom-4 left-4 right-4">
        <div className="bg-yellow-100 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-md p-2 flex items-start gap-2">
          <AlertCircle className="h-5 w-5 text-yellow-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-yellow-800 dark:text-yellow-300">Alerta: Nível alto no TQ 43</p>
            <p className="text-xs text-yellow-700 dark:text-yellow-400">
              Programar transferência para evitar transbordamento
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function DiagramaConcentrado() {
  return (
    <div className="relative bg-gray-100 dark:bg-gray-800 p-6 rounded-lg min-h-[500px]">
      <div className="absolute top-4 right-4">
        <Badge variant="outline" className="flex items-center gap-1">
          <Info className="h-3 w-3" />
          Atualizado: 02/05/2025 08:30
        </Badge>
      </div>

      {/* Linha de tanques */}
      <div className="flex flex-wrap justify-center gap-8 mb-12">
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={65} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 61</span>
          <span className="text-xs">1300 m³</span>
        </div>
      </div>

      {/* Próximo carregamento */}
      <div className="flex justify-center gap-16 mb-12">
        <div className="flex flex-col items-center">
          <TruckIcon status="loading" size="lg" />
          <span className="mt-1 text-sm">Próximo Carregamento</span>
          <span className="text-xs">TQ 61 → Unidade de Beneficiamento</span>
          <span className="text-xs">Amanhã, 08:00</span>
        </div>
      </div>
    </div>
  )
}

function DiagramaLodo() {
  return (
    <div className="relative bg-gray-100 dark:bg-gray-800 p-6 rounded-lg min-h-[500px]">
      <div className="absolute top-4 right-4">
        <Badge variant="outline" className="flex items-center gap-1">
          <Info className="h-3 w-3" />
          Atualizado: 02/05/2025 08:30
        </Badge>
      </div>

      {/* Linha de tanques */}
      <div className="flex flex-wrap justify-center gap-8 mb-12">
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={70} status="normal" size="lg" />
          <span className="mt-2 font-medium">TL 01</span>
          <span className="text-xs">1050 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={45} status="normal" size="lg" />
          <span className="mt-2 font-medium">TL 02</span>
          <span className="text-xs">675 m³</span>
        </div>
      </div>

      {/* Próximo carregamento */}
      <div className="flex justify-center gap-16">
        <div className="flex flex-col items-center">
          <TruckIcon status="loading" size="lg" />
          <span className="mt-1 text-sm">Próximo Carregamento</span>
          <span className="text-xs">TL 01 → Descarte</span>
          <span className="text-xs">Quinta-feira, 10:00</span>
        </div>
      </div>
    </div>
  )
}

function DiagramaBiologico() {
  return (
    <div className="relative bg-gray-100 dark:bg-gray-800 p-6 rounded-lg min-h-[500px]">
      <div className="absolute top-4 right-4">
        <Badge variant="outline" className="flex items-center gap-1">
          <Info className="h-3 w-3" />
          Atualizado: 02/05/2025 08:30
        </Badge>
      </div>

      {/* Linha de tanques */}
      <div className="flex flex-wrap justify-center gap-8 mb-12">
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={60} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 71</span>
          <span className="text-xs">1800 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={75} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 72</span>
          <span className="text-xs">2250 m³</span>
        </div>
      </div>
    </div>
  )
}

function DiagramaTerciario() {
  return (
    <div className="relative bg-gray-100 dark:bg-gray-800 p-6 rounded-lg min-h-[500px]">
      <div className="absolute top-4 right-4">
        <Badge variant="outline" className="flex items-center gap-1">
          <Info className="h-3 w-3" />
          Atualizado: 02/05/2025 08:30
        </Badge>
      </div>

      {/* Linha de tanques */}
      <div className="flex flex-wrap justify-center gap-8 mb-12">
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={80} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 73</span>
          <span className="text-xs">2000 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={65} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 74</span>
          <span className="text-xs">1625 m³</span>
        </div>
        <div className="flex flex-col items-center">
          <TankIcon fillLevel={50} status="normal" size="lg" />
          <span className="mt-2 font-medium">TQ 75</span>
          <span className="text-xs">1250 m³</span>
        </div>
      </div>
    </div>
  )
}
