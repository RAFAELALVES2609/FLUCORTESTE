"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Lock, LogIn, User } from "lucide-react"

export default function Login() {
  const router = useRouter()
  const { toast } = useToast()
  const [credentials, setCredentials] = useState({
    login: "",
    senha: "",
  })
  const [loading, setLoading] = useState(false)

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulação de autenticação
    setTimeout(() => {
      // Aqui você implementaria a lógica real de autenticação
      if (credentials.login === "admin" && credentials.senha === "admin") {
        toast({
          title: "Login realizado com sucesso!",
          description: "Bem-vindo ao sistema de controle da ETE. (Perfil: Administrador)",
        })
        router.push("/painel-principal")
      } else if (credentials.login === "operador" && credentials.senha === "operador") {
        toast({
          title: "Login realizado com sucesso!",
          description: "Bem-vindo ao sistema de controle da ETE. (Perfil: Operador)",
        })
        router.push("/painel-principal")
      } else if (credentials.login === "lab" && credentials.senha === "lab") {
        toast({
          title: "Login realizado com sucesso!",
          description: "Bem-vindo ao sistema de controle da ETE. (Perfil: Laboratório)",
        })
        router.push("/laboratorio")
      } else {
        toast({
          title: "Erro de autenticação",
          description: "Login ou senha incorretos. Tente novamente.",
          variant: "destructive",
        })
      }
      setLoading(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/40 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-4">
            <div className="flex items-center gap-2">
              <div className="relative h-12 w-12">
                <div className="absolute inset-0 rounded-full bg-[#800020]"></div>
                <div className="absolute inset-[15%] rounded-full bg-yellow-400"></div>
                <div className="absolute inset-[30%] rounded-full bg-blue-500"></div>
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-2xl leading-none">FLUCOR</span>
                <span className="text-sm leading-none">UNIDADE MOGI DAS CRUZES</span>
              </div>
            </div>
          </div>
          <CardTitle className="text-2xl text-center">Login</CardTitle>
          <CardDescription className="text-center">Entre com suas credenciais para acessar o sistema</CardDescription>
        </CardHeader>
        <form onSubmit={handleLogin}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="login">Login</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="login"
                  placeholder="Seu login"
                  className="pl-10"
                  value={credentials.login}
                  onChange={(e) => setCredentials({ ...credentials, login: e.target.value })}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="senha">Senha</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="senha"
                  type="password"
                  placeholder="Sua senha"
                  className="pl-10"
                  value={credentials.senha}
                  onChange={(e) => setCredentials({ ...credentials, senha: e.target.value })}
                  required
                />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full" type="submit" disabled={loading}>
              {loading ? (
                <div className="flex items-center">
                  <div className="animate-spin mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full"></div>
                  Autenticando...
                </div>
              ) : (
                <>
                  <LogIn className="mr-2 h-4 w-4" />
                  Entrar
                </>
              )}
            </Button>
          </CardFooter>
        </form>
        <div className="px-6 pb-4 pt-1">
          <div className="text-xs text-muted-foreground">
            <p className="mb-1">Usuários para teste:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>
                <strong>Administrador:</strong> admin / admin
              </li>
              <li>
                <strong>Operador:</strong> operador / operador
              </li>
              <li>
                <strong>Laboratório:</strong> lab / lab
              </li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  )
}
