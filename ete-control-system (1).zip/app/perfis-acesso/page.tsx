"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Edit, Plus, Trash2, UserPlus } from "lucide-react"

type Perfil = {
  id: string
  nome: string
  tipo: "administrador" | "supervisor" | "operador" | "laboratorio" | "visualizacao"
  permissoes: {
    cadastroOrdens: boolean
    alteracaoOrdens: boolean
    cadastroTanques: boolean
    alteracaoTanques: boolean
    cadastroPessoal: boolean
    alteracaoPessoal: boolean
    cadastroEscalas: boolean
    alteracaoEscalas: boolean
    geracaoRelatorios: boolean
  }
}

type Usuario = {
  id: string
  nome: string
  email: string
  perfilId: string
  ativo: boolean
}

export default function PerfisAcesso() {
  const { toast } = useToast()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [usuarioDialogOpen, setUsuarioDialogOpen] = useState(false)
  const [perfilEmEdicao, setPerfilEmEdicao] = useState<Perfil | null>(null)
  const [usuarioEmEdicao, setUsuarioEmEdicao] = useState<Usuario | null>(null)

  const [novoPerfil, setNovoPerfil] = useState<Omit<Perfil, "id">>({
    nome: "",
    tipo: "operador",
    permissoes: {
      cadastroOrdens: false,
      alteracaoOrdens: false,
      cadastroTanques: false,
      alteracaoTanques: false,
      cadastroPessoal: false,
      alteracaoPessoal: false,
      cadastroEscalas: false,
      alteracaoEscalas: false,
      geracaoRelatorios: false,
    },
  })

  const [novoUsuario, setNovoUsuario] = useState<Omit<Usuario, "id">>({
    nome: "",
    email: "",
    perfilId: "",
    ativo: true,
  })

  const [perfis, setPerfis] = useState<Perfil[]>([
    {
      id: "1",
      nome: "Administrador",
      tipo: "administrador",
      permissoes: {
        cadastroOrdens: true,
        alteracaoOrdens: true,
        cadastroTanques: true,
        alteracaoTanques: true,
        cadastroPessoal: true,
        alteracaoPessoal: true,
        cadastroEscalas: true,
        alteracaoEscalas: true,
        geracaoRelatorios: true,
      },
    },
    {
      id: "2",
      nome: "Supervisor",
      tipo: "supervisor",
      permissoes: {
        cadastroOrdens: true,
        alteracaoOrdens: true,
        cadastroTanques: true,
        alteracaoTanques: true,
        cadastroPessoal: false,
        alteracaoPessoal: false,
        cadastroEscalas: true,
        alteracaoEscalas: true,
        geracaoRelatorios: true,
      },
    },
    {
      id: "3",
      nome: "Operador",
      tipo: "operador",
      permissoes: {
        cadastroOrdens: true,
        alteracaoOrdens: false,
        cadastroTanques: false,
        alteracaoTanques: false,
        cadastroPessoal: false,
        alteracaoPessoal: false,
        cadastroEscalas: false,
        alteracaoEscalas: false,
        geracaoRelatorios: false,
      },
    },
    {
      id: "4",
      nome: "Laboratório",
      tipo: "laboratorio",
      permissoes: {
        cadastroOrdens: false,
        alteracaoOrdens: false,
        cadastroTanques: false,
        alteracaoTanques: false,
        cadastroPessoal: false,
        alteracaoPessoal: false,
        cadastroEscalas: false,
        alteracaoEscalas: false,
        geracaoRelatorios: true,
      },
    },
    {
      id: "5",
      nome: "Visualização",
      tipo: "visualizacao",
      permissoes: {
        cadastroOrdens: false,
        alteracaoOrdens: false,
        cadastroTanques: false,
        alteracaoTanques: false,
        cadastroPessoal: false,
        alteracaoPessoal: false,
        cadastroEscalas: false,
        alteracaoEscalas: false,
        geracaoRelatorios: false,
      },
    },
  ])

  const [usuarios, setUsuarios] = useState<Usuario[]>([
    {
      id: "1",
      nome: "João Silva",
      email: "joao.silva@flucor.com.br",
      perfilId: "1",
      ativo: true,
    },
    {
      id: "2",
      nome: "Maria Oliveira",
      email: "maria.oliveira@flucor.com.br",
      perfilId: "2",
      ativo: true,
    },
    {
      id: "3",
      nome: "Carlos Santos",
      email: "carlos.santos@flucor.com.br",
      perfilId: "3",
      ativo: true,
    },
    {
      id: "4",
      nome: "Ana Souza",
      email: "ana.souza@flucor.com.br",
      perfilId: "4",
      ativo: true,
    },
  ])

  const adicionarPerfil = () => {
    if (!novoPerfil.nome || !novoPerfil.tipo) {
      toast({
        title: "Erro ao adicionar perfil",
        description: "Nome e tipo são obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (perfis.length + 1).toString()
    const perfilCompleto: Perfil = {
      id: novoId,
      ...novoPerfil,
    }

    setPerfis([...perfis, perfilCompleto])
    setNovoPerfil({
      nome: "",
      tipo: "operador",
      permissoes: {
        cadastroOrdens: false,
        alteracaoOrdens: false,
        cadastroTanques: false,
        alteracaoTanques: false,
        cadastroPessoal: false,
        alteracaoPessoal: false,
        cadastroEscalas: false,
        alteracaoEscalas: false,
        geracaoRelatorios: false,
      },
    })
    setDialogOpen(false)

    toast({
      title: "Perfil adicionado",
      description: "O novo perfil foi adicionado com sucesso.",
    })
  }

  const adicionarUsuario = () => {
    if (!novoUsuario.nome || !novoUsuario.email || !novoUsuario.perfilId) {
      toast({
        title: "Erro ao adicionar usuário",
        description: "Nome, email e perfil são obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (usuarios.length + 1).toString()
    const usuarioCompleto: Usuario = {
      id: novoId,
      ...novoUsuario,
    }

    setUsuarios([...usuarios, usuarioCompleto])
    setNovoUsuario({
      nome: "",
      email: "",
      perfilId: "",
      ativo: true,
    })
    setUsuarioDialogOpen(false)

    toast({
      title: "Usuário adicionado",
      description: "O novo usuário foi adicionado com sucesso.",
    })
  }

  const editarPerfil = (perfil: Perfil) => {
    setPerfilEmEdicao(perfil)
    setDialogOpen(true)
  }

  const editarUsuario = (usuario: Usuario) => {
    setUsuarioEmEdicao(usuario)
    setUsuarioDialogOpen(true)
  }

  const salvarEdicaoPerfil = () => {
    if (!perfilEmEdicao) return

    setPerfis(perfis.map((perfil) => (perfil.id === perfilEmEdicao.id ? perfilEmEdicao : perfil)))

    setDialogOpen(false)
    setPerfilEmEdicao(null)

    toast({
      title: "Perfil atualizado",
      description: "As informações do perfil foram atualizadas com sucesso.",
    })
  }

  const salvarEdicaoUsuario = () => {
    if (!usuarioEmEdicao) return

    setUsuarios(usuarios.map((usuario) => (usuario.id === usuarioEmEdicao.id ? usuarioEmEdicao : usuario)))

    setUsuarioDialogOpen(false)
    setUsuarioEmEdicao(null)

    toast({
      title: "Usuário atualizado",
      description: "As informações do usuário foram atualizadas com sucesso.",
    })
  }

  const removerPerfil = (id: string) => {
    // Verificar se há usuários usando este perfil
    const usuariosComPerfil = usuarios.filter((usuario) => usuario.perfilId === id)
    if (usuariosComPerfil.length > 0) {
      toast({
        title: "Não é possível remover o perfil",
        description: "Existem usuários associados a este perfil.",
        variant: "destructive",
      })
      return
    }

    setPerfis(perfis.filter((perfil) => perfil.id !== id))

    toast({
      title: "Perfil removido",
      description: "O perfil foi removido com sucesso.",
    })
  }

  const removerUsuario = (id: string) => {
    setUsuarios(usuarios.filter((usuario) => usuario.id !== id))

    toast({
      title: "Usuário removido",
      description: "O usuário foi removido com sucesso.",
    })
  }

  const getNomePerfil = (perfilId: string) => {
    const perfil = perfis.find((p) => p.id === perfilId)
    return perfil ? perfil.nome : "Não definido"
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Perfis de Acesso</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Perfis</CardTitle>
              <CardDescription>Gerenciamento de perfis de acesso</CardDescription>
            </div>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  onClick={() => {
                    setPerfilEmEdicao(null)
                    setNovoPerfil({
                      nome: "",
                      tipo: "operador",
                      permissoes: {
                        cadastroOrdens: false,
                        alteracaoOrdens: false,
                        cadastroTanques: false,
                        alteracaoTanques: false,
                        cadastroPessoal: false,
                        alteracaoPessoal: false,
                        cadastroEscalas: false,
                        alteracaoEscalas: false,
                        geracaoRelatorios: false,
                      },
                    })
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Novo Perfil
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>{perfilEmEdicao ? "Editar Perfil" : "Adicionar Novo Perfil"}</DialogTitle>
                  <DialogDescription>
                    {perfilEmEdicao
                      ? "Edite as informações do perfil de acesso."
                      : "Preencha as informações para criar um novo perfil de acesso."}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div>
                    <Label htmlFor="nome-perfil">Nome do Perfil</Label>
                    <Input
                      id="nome-perfil"
                      value={perfilEmEdicao ? perfilEmEdicao.nome : novoPerfil.nome}
                      onChange={(e) => {
                        if (perfilEmEdicao) {
                          setPerfilEmEdicao({ ...perfilEmEdicao, nome: e.target.value })
                        } else {
                          setNovoPerfil({ ...novoPerfil, nome: e.target.value })
                        }
                      }}
                      placeholder="Ex: Supervisor de Operações"
                    />
                  </div>
                  <div>
                    <Label htmlFor="tipo-perfil">Tipo de Perfil</Label>
                    <Select
                      value={perfilEmEdicao ? perfilEmEdicao.tipo : novoPerfil.tipo}
                      onValueChange={(
                        value: "administrador" | "supervisor" | "operador" | "laboratorio" | "visualizacao",
                      ) => {
                        if (perfilEmEdicao) {
                          setPerfilEmEdicao({ ...perfilEmEdicao, tipo: value })
                        } else {
                          setNovoPerfil({ ...novoPerfil, tipo: value })
                        }
                      }}
                    >
                      <SelectTrigger id="tipo-perfil">
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="administrador">Administrador</SelectItem>
                        <SelectItem value="supervisor">Supervisor</SelectItem>
                        <SelectItem value="operador">Operador</SelectItem>
                        <SelectItem value="laboratorio">Laboratório</SelectItem>
                        <SelectItem value="visualizacao">Visualização</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="mb-2 block">Permissões</Label>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="cadastro-ordens"
                          checked={
                            perfilEmEdicao
                              ? perfilEmEdicao.permissoes.cadastroOrdens
                              : novoPerfil.permissoes.cadastroOrdens
                          }
                          onCheckedChange={(checked) => {
                            if (perfilEmEdicao) {
                              setPerfilEmEdicao({
                                ...perfilEmEdicao,
                                permissoes: {
                                  ...perfilEmEdicao.permissoes,
                                  cadastroOrdens: checked as boolean,
                                },
                              })
                            } else {
                              setNovoPerfil({
                                ...novoPerfil,
                                permissoes: {
                                  ...novoPerfil.permissoes,
                                  cadastroOrdens: checked as boolean,
                                },
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor="cadastro-ordens"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Cadastro de Ordens
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="alteracao-ordens"
                          checked={
                            perfilEmEdicao
                              ? perfilEmEdicao.permissoes.alteracaoOrdens
                              : novoPerfil.permissoes.alteracaoOrdens
                          }
                          onCheckedChange={(checked) => {
                            if (perfilEmEdicao) {
                              setPerfilEmEdicao({
                                ...perfilEmEdicao,
                                permissoes: {
                                  ...perfilEmEdicao.permissoes,
                                  alteracaoOrdens: checked as boolean,
                                },
                              })
                            } else {
                              setNovoPerfil({
                                ...novoPerfil,
                                permissoes: {
                                  ...novoPerfil.permissoes,
                                  alteracaoOrdens: checked as boolean,
                                },
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor="alteracao-ordens"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Alteração de Ordens
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="cadastro-tanques"
                          checked={
                            perfilEmEdicao
                              ? perfilEmEdicao.permissoes.cadastroTanques
                              : novoPerfil.permissoes.cadastroTanques
                          }
                          onCheckedChange={(checked) => {
                            if (perfilEmEdicao) {
                              setPerfilEmEdicao({
                                ...perfilEmEdicao,
                                permissoes: {
                                  ...perfilEmEdicao.permissoes,
                                  cadastroTanques: checked as boolean,
                                },
                              })
                            } else {
                              setNovoPerfil({
                                ...novoPerfil,
                                permissoes: {
                                  ...novoPerfil.permissoes,
                                  cadastroTanques: checked as boolean,
                                },
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor="cadastro-tanques"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Cadastro de Tanques
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="alteracao-tanques"
                          checked={
                            perfilEmEdicao
                              ? perfilEmEdicao.permissoes.alteracaoTanques
                              : novoPerfil.permissoes.alteracaoTanques
                          }
                          onCheckedChange={(checked) => {
                            if (perfilEmEdicao) {
                              setPerfilEmEdicao({
                                ...perfilEmEdicao,
                                permissoes: {
                                  ...perfilEmEdicao.permissoes,
                                  alteracaoTanques: checked as boolean,
                                },
                              })
                            } else {
                              setNovoPerfil({
                                ...novoPerfil,
                                permissoes: {
                                  ...novoPerfil.permissoes,
                                  alteracaoTanques: checked as boolean,
                                },
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor="alteracao-tanques"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Alteração de Tanques
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="cadastro-pessoal"
                          checked={
                            perfilEmEdicao
                              ? perfilEmEdicao.permissoes.cadastroPessoal
                              : novoPerfil.permissoes.cadastroPessoal
                          }
                          onCheckedChange={(checked) => {
                            if (perfilEmEdicao) {
                              setPerfilEmEdicao({
                                ...perfilEmEdicao,
                                permissoes: {
                                  ...perfilEmEdicao.permissoes,
                                  cadastroPessoal: checked as boolean,
                                },
                              })
                            } else {
                              setNovoPerfil({
                                ...novoPerfil,
                                permissoes: {
                                  ...novoPerfil.permissoes,
                                  cadastroPessoal: checked as boolean,
                                },
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor="cadastro-pessoal"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Cadastro de Pessoal
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="alteracao-pessoal"
                          checked={
                            perfilEmEdicao
                              ? perfilEmEdicao.permissoes.alteracaoPessoal
                              : novoPerfil.permissoes.alteracaoPessoal
                          }
                          onCheckedChange={(checked) => {
                            if (perfilEmEdicao) {
                              setPerfilEmEdicao({
                                ...perfilEmEdicao,
                                permissoes: {
                                  ...perfilEmEdicao.permissoes,
                                  alteracaoPessoal: checked as boolean,
                                },
                              })
                            } else {
                              setNovoPerfil({
                                ...novoPerfil,
                                permissoes: {
                                  ...novoPerfil.permissoes,
                                  alteracaoPessoal: checked as boolean,
                                },
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor="alteracao-pessoal"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Alteração de Pessoal
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="cadastro-escalas"
                          checked={
                            perfilEmEdicao
                              ? perfilEmEdicao.permissoes.cadastroEscalas
                              : novoPerfil.permissoes.cadastroEscalas
                          }
                          onCheckedChange={(checked) => {
                            if (perfilEmEdicao) {
                              setPerfilEmEdicao({
                                ...perfilEmEdicao,
                                permissoes: {
                                  ...perfilEmEdicao.permissoes,
                                  cadastroEscalas: checked as boolean,
                                },
                              })
                            } else {
                              setNovoPerfil({
                                ...novoPerfil,
                                permissoes: {
                                  ...novoPerfil.permissoes,
                                  cadastroEscalas: checked as boolean,
                                },
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor="cadastro-escalas"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Cadastro de Escalas
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="alteracao-escalas"
                          checked={
                            perfilEmEdicao
                              ? perfilEmEdicao.permissoes.alteracaoEscalas
                              : novoPerfil.permissoes.alteracaoEscalas
                          }
                          onCheckedChange={(checked) => {
                            if (perfilEmEdicao) {
                              setPerfilEmEdicao({
                                ...perfilEmEdicao,
                                permissoes: {
                                  ...perfilEmEdicao.permissoes,
                                  alteracaoEscalas: checked as boolean,
                                },
                              })
                            } else {
                              setNovoPerfil({
                                ...novoPerfil,
                                permissoes: {
                                  ...novoPerfil.permissoes,
                                  alteracaoEscalas: checked as boolean,
                                },
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor="alteracao-escalas"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Alteração de Escalas
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="geracao-relatorios"
                          checked={
                            perfilEmEdicao
                              ? perfilEmEdicao.permissoes.geracaoRelatorios
                              : novoPerfil.permissoes.geracaoRelatorios
                          }
                          onCheckedChange={(checked) => {
                            if (perfilEmEdicao) {
                              setPerfilEmEdicao({
                                ...perfilEmEdicao,
                                permissoes: {
                                  ...perfilEmEdicao.permissoes,
                                  geracaoRelatorios: checked as boolean,
                                },
                              })
                            } else {
                              setNovoPerfil({
                                ...novoPerfil,
                                permissoes: {
                                  ...novoPerfil.permissoes,
                                  geracaoRelatorios: checked as boolean,
                                },
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor="geracao-relatorios"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Geração de Relatórios
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={perfilEmEdicao ? salvarEdicaoPerfil : adicionarPerfil}>
                    {perfilEmEdicao ? "Salvar Alterações" : "Adicionar Perfil"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {perfis.map((perfil) => (
                  <TableRow key={perfil.id}>
                    <TableCell className="font-medium">{perfil.nome}</TableCell>
                    <TableCell>
                      {perfil.tipo === "administrador" && "Administrador"}
                      {perfil.tipo === "supervisor" && "Supervisor"}
                      {perfil.tipo === "operador" && "Operador"}
                      {perfil.tipo === "laboratorio" && "Laboratório"}
                      {perfil.tipo === "visualizacao" && "Visualização"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" onClick={() => editarPerfil(perfil)}>
                          <Edit className="h-4 w-4 text-blue-500" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => removerPerfil(perfil.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Usuários</CardTitle>
              <CardDescription>Gerenciamento de usuários do sistema</CardDescription>
            </div>
            <Dialog open={usuarioDialogOpen} onOpenChange={setUsuarioDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  onClick={() => {
                    setUsuarioEmEdicao(null)
                    setNovoUsuario({
                      nome: "",
                      email: "",
                      perfilId: "",
                      ativo: true,
                    })
                  }}
                >
                  <UserPlus className="mr-2 h-4 w-4" />
                  Novo Usuário
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>{usuarioEmEdicao ? "Editar Usuário" : "Adicionar Novo Usuário"}</DialogTitle>
                  <DialogDescription>
                    {usuarioEmEdicao
                      ? "Edite as informações do usuário."
                      : "Preencha as informações para criar um novo usuário."}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div>
                    <Label htmlFor="nome-usuario">Nome do Usuário</Label>
                    <Input
                      id="nome-usuario"
                      value={usuarioEmEdicao ? usuarioEmEdicao.nome : novoUsuario.nome}
                      onChange={(e) => {
                        if (usuarioEmEdicao) {
                          setUsuarioEmEdicao({ ...usuarioEmEdicao, nome: e.target.value })
                        } else {
                          setNovoUsuario({ ...novoUsuario, nome: e.target.value })
                        }
                      }}
                      placeholder="Ex: João Silva"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email-usuario">Email</Label>
                    <Input
                      id="email-usuario"
                      type="email"
                      value={usuarioEmEdicao ? usuarioEmEdicao.email : novoUsuario.email}
                      onChange={(e) => {
                        if (usuarioEmEdicao) {
                          setUsuarioEmEdicao({ ...usuarioEmEdicao, email: e.target.value })
                        } else {
                          setNovoUsuario({ ...novoUsuario, email: e.target.value })
                        }
                      }}
                      placeholder="Ex: joao.silva@flucor.com.br"
                    />
                  </div>
                  <div>
                    <Label htmlFor="perfil-usuario">Perfil</Label>
                    <Select
                      value={usuarioEmEdicao ? usuarioEmEdicao.perfilId : novoUsuario.perfilId}
                      onValueChange={(value) => {
                        if (usuarioEmEdicao) {
                          setUsuarioEmEdicao({ ...usuarioEmEdicao, perfilId: value })
                        } else {
                          setNovoUsuario({ ...novoUsuario, perfilId: value })
                        }
                      }}
                    >
                      <SelectTrigger id="perfil-usuario">
                        <SelectValue placeholder="Selecione o perfil" />
                      </SelectTrigger>
                      <SelectContent>
                        {perfis.map((perfil) => (
                          <SelectItem key={perfil.id} value={perfil.id}>
                            {perfil.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="ativo-usuario"
                      checked={usuarioEmEdicao ? usuarioEmEdicao.ativo : novoUsuario.ativo}
                      onCheckedChange={(checked) => {
                        if (usuarioEmEdicao) {
                          setUsuarioEmEdicao({ ...usuarioEmEdicao, ativo: checked as boolean })
                        } else {
                          setNovoUsuario({ ...novoUsuario, ativo: checked as boolean })
                        }
                      }}
                    />
                    <label
                      htmlFor="ativo-usuario"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Usuário Ativo
                    </label>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setUsuarioDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={usuarioEmEdicao ? salvarEdicaoUsuario : adicionarUsuario}>
                    {usuarioEmEdicao ? "Salvar Alterações" : "Adicionar Usuário"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Perfil</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {usuarios.map((usuario) => (
                  <TableRow key={usuario.id}>
                    <TableCell className="font-medium">{usuario.nome}</TableCell>
                    <TableCell>{usuario.email}</TableCell>
                    <TableCell>{getNomePerfil(usuario.perfilId)}</TableCell>
                    <TableCell>
                      <span
                        className={`px-2 py-1 rounded-full text-xs ${
                          usuario.ativo
                            ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
                            : "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
                        }`}
                      >
                        {usuario.ativo ? "Ativo" : "Inativo"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" onClick={() => editarUsuario(usuario)}>
                          <Edit className="h-4 w-4 text-blue-500" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => removerUsuario(usuario.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
