"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import {
  Search,
  UserCheck,
  UserPlus,
  CalendarClock,
  ClipboardCheck,
  CheckCircle2,
  XCircle,
  FileText,
} from "lucide-react"

// Tipo para visitante
type Visitante = {
  id: string
  nome: string
  documento: string
  empresa: string
  telefone: string
  email?: string
  tipo: "cliente" | "fornecedor" | "prestador" | "autoridade" | "outro"
}

// Tipo para visita
type Visita = {
  id: string
  visitantes: Visitante[]
  dataEntrada: Date
  dataSaida?: Date
  motivo: string
  responsavelInterno: string
  setorVisitado: string
  status: "agendada" | "em_andamento" | "concluida" | "cancelada"
  observacoes?: string
  documentosApresentados: boolean
  integracaoRealizada: boolean
  episFornecidos?: string[]
}

export default function RegistroVisitas() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("registro")

  // Estado para visitantes cadastrados
  const [visitantesCadastrados, setVisitantesCadastrados] = useState<Visitante[]>([
    {
      id: "1",
      nome: "João Silva",
      documento: "123.456.789-00",
      empresa: "Empresa ABC",
      telefone: "(11) 98765-4321",
      email: "joao.silva@empresa.com",
      tipo: "fornecedor",
    },
    {
      id: "2",
      nome: "Maria Oliveira",
      documento: "987.654.321-00",
      empresa: "Consultoria XYZ",
      telefone: "(11) 91234-5678",
      email: "maria.oliveira@consultoria.com",
      tipo: "prestador",
    },
    {
      id: "3",
      nome: "Carlos Santos",
      documento: "456.789.123-00",
      empresa: "Cliente Final Ltda",
      telefone: "(11) 95555-9999",
      tipo: "cliente",
    },
    {
      id: "4",
      nome: "Ana Pereira",
      documento: "789.123.456-00",
      empresa: "Órgão Ambiental",
      telefone: "(11) 94444-3333",
      email: "ana.pereira@orgao.gov.br",
      tipo: "autoridade",
    },
  ])

  // Estado para visitas
  const [visitas, setVisitas] = useState<Visita[]>([
    {
      id: "1",
      visitantes: [visitantesCadastrados[0], visitantesCadastrados[1]],
      dataEntrada: new Date(new Date().setHours(new Date().getHours() - 3)),
      motivo: "Reunião de alinhamento sobre fornecimento de produtos químicos",
      responsavelInterno: "Roberto Almeida",
      setorVisitado: "Compras",
      status: "em_andamento",
      documentosApresentados: true,
      integracaoRealizada: true,
      episFornecidos: ["Capacete", "Óculos de proteção"],
    },
    {
      id: "2",
      visitantes: [visitantesCadastrados[2]],
      dataEntrada: new Date(new Date().setDate(new Date().getDate() - 1)),
      dataSaida: new Date(new Date().setDate(new Date().getDate() - 1)),
      motivo: "Visita técnica para avaliação de produto",
      responsavelInterno: "Carla Mendes",
      setorVisitado: "Produção",
      status: "concluida",
      observacoes: "Cliente satisfeito com a visita. Demonstrou interesse em aumentar o volume de compras.",
      documentosApresentados: true,
      integracaoRealizada: true,
      episFornecidos: ["Capacete", "Óculos de proteção", "Protetor auricular"],
    },
    {
      id: "3",
      visitantes: [visitantesCadastrados[3]],
      dataEntrada: new Date(new Date().setDate(new Date().getDate() + 2)),
      motivo: "Fiscalização ambiental de rotina",
      responsavelInterno: "Paulo Souza",
      setorVisitado: "ETE",
      status: "agendada",
      documentosApresentados: false,
      integracaoRealizada: false,
    },
  ])

  // Estado para novo visitante
  const [novoVisitante, setNovoVisitante] = useState<Omit<Visitante, "id">>({
    nome: "",
    documento: "",
    empresa: "",
    telefone: "",
    email: "",
    tipo: "fornecedor",
  })

  // Estado para nova visita
  const [novaVisita, setNovaVisita] = useState<{
    visitantesIds: string[]
    dataEntrada: Date
    motivo: string
    responsavelInterno: string
    setorVisitado: string
    observacoes?: string
    documentosApresentados: boolean
    integracaoRealizada: boolean
    episFornecidos: string[]
  }>({
    visitantesIds: [],
    dataEntrada: new Date(),
    motivo: "",
    responsavelInterno: "",
    setorVisitado: "",
    observacoes: "",
    documentosApresentados: false,
    integracaoRealizada: false,
    episFornecidos: [],
  })

  // Estado para filtro de visitas
  const [filtroVisitas, setFiltroVisitas] = useState({
    termo: "",
    status: "todas",
    periodo: "hoje",
  })

  // Estado para novo EPI
  const [novoEpi, setNovoEpi] = useState("")

  // Função para adicionar novo visitante
  const adicionarVisitante = () => {
    if (!novoVisitante.nome || !novoVisitante.documento || !novoVisitante.empresa || !novoVisitante.telefone) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios do visitante.",
        variant: "destructive",
      })
      return
    }

    const id = Date.now().toString()
    const visitante: Visitante = {
      id,
      ...novoVisitante,
    }

    setVisitantesCadastrados([...visitantesCadastrados, visitante])
    setNovoVisitante({
      nome: "",
      documento: "",
      empresa: "",
      telefone: "",
      email: "",
      tipo: "fornecedor",
    })

    toast({
      title: "Visitante cadastrado",
      description: "O visitante foi cadastrado com sucesso.",
    })
  }

  // Função para adicionar nova visita
  const adicionarVisita = () => {
    if (
      novaVisita.visitantesIds.length === 0 ||
      !novaVisita.motivo ||
      !novaVisita.responsavelInterno ||
      !novaVisita.setorVisitado
    ) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios da visita.",
        variant: "destructive",
      })
      return
    }

    const id = Date.now().toString()
    const visitantes = visitantesCadastrados.filter((v) => novaVisita.visitantesIds.includes(v.id))

    const visita: Visita = {
      id,
      visitantes,
      dataEntrada: novaVisita.dataEntrada,
      motivo: novaVisita.motivo,
      responsavelInterno: novaVisita.responsavelInterno,
      setorVisitado: novaVisita.setorVisitado,
      status: "agendada",
      observacoes: novaVisita.observacoes,
      documentosApresentados: novaVisita.documentosApresentados,
      integracaoRealizada: novaVisita.integracaoRealizada,
      episFornecidos: novaVisita.episFornecidos,
    }

    setVisitas([...visitas, visita])
    setNovaVisita({
      visitantesIds: [],
      dataEntrada: new Date(),
      motivo: "",
      responsavelInterno: "",
      setorVisitado: "",
      observacoes: "",
      documentosApresentados: false,
      integracaoRealizada: false,
      episFornecidos: [],
    })

    toast({
      title: "Visita registrada",
      description: "A visita foi registrada com sucesso.",
    })
  }

  // Função para adicionar EPI à lista
  const adicionarEpi = () => {
    if (!novoEpi) return

    if (!novaVisita.episFornecidos.includes(novoEpi)) {
      setNovaVisita({
        ...novaVisita,
        episFornecidos: [...novaVisita.episFornecidos, novoEpi],
      })
      setNovoEpi("")
    }
  }

  // Função para remover EPI da lista
  const removerEpi = (epi: string) => {
    setNovaVisita({
      ...novaVisita,
      episFornecidos: novaVisita.episFornecidos.filter((e) => e !== epi),
    })
  }

  // Função para iniciar visita
  const iniciarVisita = (id: string) => {
    setVisitas(
      visitas.map((visita) =>
        visita.id === id ? { ...visita, status: "em_andamento", dataEntrada: new Date() } : visita,
      ),
    )

    toast({
      title: "Visita iniciada",
      description: "A visita foi iniciada com sucesso.",
    })
  }

  // Função para concluir visita
  const concluirVisita = (id: string) => {
    setVisitas(
      visitas.map((visita) => (visita.id === id ? { ...visita, status: "concluida", dataSaida: new Date() } : visita)),
    )

    toast({
      title: "Visita concluída",
      description: "A visita foi concluída com sucesso.",
    })
  }

  // Função para cancelar visita
  const cancelarVisita = (id: string) => {
    setVisitas(visitas.map((visita) => (visita.id === id ? { ...visita, status: "cancelada" } : visita)))

    toast({
      title: "Visita cancelada",
      description: "A visita foi cancelada com sucesso.",
    })
  }

  // Função para filtrar visitas
  const filtrarVisitas = () => {
    let visitasFiltradas = [...visitas]

    // Filtrar por termo de busca
    if (filtroVisitas.termo) {
      const termo = filtroVisitas.termo.toLowerCase()
      visitasFiltradas = visitasFiltradas.filter(
        (visita) =>
          visita.visitantes.some((v) => v.nome.toLowerCase().includes(termo)) ||
          visita.visitantes.some((v) => v.empresa.toLowerCase().includes(termo)) ||
          visita.responsavelInterno.toLowerCase().includes(termo) ||
          visita.setorVisitado.toLowerCase().includes(termo) ||
          visita.motivo.toLowerCase().includes(termo),
      )
    }

    // Filtrar por status
    if (filtroVisitas.status !== "todas") {
      visitasFiltradas = visitasFiltradas.filter((visita) => visita.status === filtroVisitas.status)
    }

    // Filtrar por período
    const hoje = new Date()
    hoje.setHours(0, 0, 0, 0)

    const amanha = new Date(hoje)
    amanha.setDate(amanha.getDate() + 1)

    const inicioSemana = new Date(hoje)
    inicioSemana.setDate(inicioSemana.getDate() - inicioSemana.getDay())

    const fimSemana = new Date(inicioSemana)
    fimSemana.setDate(fimSemana.getDate() + 7)

    const inicioMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1)
    const fimMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0)

    switch (filtroVisitas.periodo) {
      case "hoje":
        visitasFiltradas = visitasFiltradas.filter((visita) => {
          const dataVisita = new Date(visita.dataEntrada)
          return dataVisita >= hoje && dataVisita < amanha
        })
        break
      case "semana":
        visitasFiltradas = visitasFiltradas.filter((visita) => {
          const dataVisita = new Date(visita.dataEntrada)
          return dataVisita >= inicioSemana && dataVisita < fimSemana
        })
        break
      case "mes":
        visitasFiltradas = visitasFiltradas.filter((visita) => {
          const dataVisita = new Date(visita.dataEntrada)
          return dataVisita >= inicioMes && dataVisita < fimMes
        })
        break
    }

    return visitasFiltradas
  }

  // Obter visitas filtradas
  const visitasFiltradas = filtrarVisitas()

  // Função para obter texto do status
  const getStatusText = (status: string) => {
    switch (status) {
      case "agendada":
        return "Agendada"
      case "em_andamento":
        return "Em Andamento"
      case "concluida":
        return "Concluída"
      case "cancelada":
        return "Cancelada"
      default:
        return status
    }
  }

  // Função para obter cor do status
  const getStatusColor = (status: string) => {
    switch (status) {
      case "agendada":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
      case "em_andamento":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
      case "concluida":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "cancelada":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  // Função para obter texto do tipo de visitante
  const getTipoVisitanteText = (tipo: string) => {
    switch (tipo) {
      case "cliente":
        return "Cliente"
      case "fornecedor":
        return "Fornecedor"
      case "prestador":
        return "Prestador de Serviço"
      case "autoridade":
        return "Autoridade"
      case "outro":
        return "Outro"
      default:
        return tipo
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6 flex items-center">
        <UserCheck className="mr-2 h-6 w-6" />
        Registro de Visitas
      </h1>

      <Tabs defaultValue="registro" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="registro">Registro de Visitas</TabsTrigger>
          <TabsTrigger value="visitantes">Cadastro de Visitantes</TabsTrigger>
          <TabsTrigger value="historico">Histórico de Visitas</TabsTrigger>
        </TabsList>

        {/* Tab de Registro de Visitas */}
        <TabsContent value="registro" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Nova Visita</CardTitle>
              <CardDescription>Registre uma nova visita à fábrica</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label>Visitantes</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                    <Select
                      value={novaVisita.visitantesIds.length > 0 ? novaVisita.visitantesIds[0] : ""}
                      onValueChange={(value) => {
                        const ids = [...novaVisita.visitantesIds]
                        if (!ids.includes(value)) {
                          ids.push(value)
                        }
                        setNovaVisita({ ...novaVisita, visitantesIds: ids })
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione os visitantes" />
                      </SelectTrigger>
                      <SelectContent>
                        {visitantesCadastrados.map((visitante) => (
                          <SelectItem key={visitante.id} value={visitante.id}>
                            {visitante.nome} - {visitante.empresa}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button variant="outline" onClick={() => setActiveTab("visitantes")} className="flex items-center">
                      <UserPlus className="mr-2 h-4 w-4" />
                      Cadastrar Novo Visitante
                    </Button>
                  </div>

                  {/* Lista de visitantes selecionados */}
                  {novaVisita.visitantesIds.length > 0 && (
                    <div className="mt-4 space-y-2">
                      <Label>Visitantes selecionados:</Label>
                      <div className="flex flex-wrap gap-2">
                        {novaVisita.visitantesIds.map((id) => {
                          const visitante = visitantesCadastrados.find((v) => v.id === id)
                          return visitante ? (
                            <Badge key={id} variant="secondary" className="flex items-center gap-1">
                              {visitante.nome} - {visitante.empresa}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-4 w-4 p-0 ml-1"
                                onClick={() => {
                                  setNovaVisita({
                                    ...novaVisita,
                                    visitantesIds: novaVisita.visitantesIds.filter((vId) => vId !== id),
                                  })
                                }}
                              >
                                <XCircle className="h-3 w-3" />
                              </Button>
                            </Badge>
                          ) : null
                        })}
                      </div>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="data-entrada">Data e Hora de Entrada</Label>
                    <div className="flex gap-2">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className="w-full justify-start text-left font-normal">
                            <CalendarClock className="mr-2 h-4 w-4" />
                            {format(novaVisita.dataEntrada, "PPP", { locale: ptBR })}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={novaVisita.dataEntrada}
                            onSelect={(date) => {
                              if (date) {
                                const newDate = new Date(date)
                                newDate.setHours(novaVisita.dataEntrada.getHours())
                                newDate.setMinutes(novaVisita.dataEntrada.getMinutes())
                                setNovaVisita({ ...novaVisita, dataEntrada: newDate })
                              }
                            }}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <Input
                        type="time"
                        value={format(novaVisita.dataEntrada, "HH:mm")}
                        onChange={(e) => {
                          const [hours, minutes] = e.target.value.split(":").map(Number)
                          const newDate = new Date(novaVisita.dataEntrada)
                          newDate.setHours(hours, minutes)
                          setNovaVisita({ ...novaVisita, dataEntrada: newDate })
                        }}
                        className="w-24"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="responsavel">Responsável Interno</Label>
                    <Input
                      id="responsavel"
                      placeholder="Nome do responsável interno"
                      value={novaVisita.responsavelInterno}
                      onChange={(e) => setNovaVisita({ ...novaVisita, responsavelInterno: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="setor">Setor a ser Visitado</Label>
                    <Select
                      value={novaVisita.setorVisitado}
                      onValueChange={(value) => setNovaVisita({ ...novaVisita, setorVisitado: value })}
                    >
                      <SelectTrigger id="setor">
                        <SelectValue placeholder="Selecione o setor" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Produção">Produção</SelectItem>
                        <SelectItem value="ETE">ETE</SelectItem>
                        <SelectItem value="Laboratório">Laboratório</SelectItem>
                        <SelectItem value="Almoxarifado">Almoxarifado</SelectItem>
                        <SelectItem value="Administrativo">Administrativo</SelectItem>
                        <SelectItem value="Compras">Compras</SelectItem>
                        <SelectItem value="Manutenção">Manutenção</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="motivo">Motivo da Visita</Label>
                    <Input
                      id="motivo"
                      placeholder="Motivo da visita"
                      value={novaVisita.motivo}
                      onChange={(e) => setNovaVisita({ ...novaVisita, motivo: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea
                    id="observacoes"
                    placeholder="Observações adicionais sobre a visita"
                    value={novaVisita.observacoes}
                    onChange={(e) => setNovaVisita({ ...novaVisita, observacoes: e.target.value })}
                    rows={3}
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="documentos"
                      checked={novaVisita.documentosApresentados}
                      onCheckedChange={(checked) =>
                        setNovaVisita({ ...novaVisita, documentosApresentados: checked as boolean })
                      }
                    />
                    <Label htmlFor="documentos">Documentos apresentados</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="integracao"
                      checked={novaVisita.integracaoRealizada}
                      onCheckedChange={(checked) =>
                        setNovaVisita({ ...novaVisita, integracaoRealizada: checked as boolean })
                      }
                    />
                    <Label htmlFor="integracao">Integração de segurança realizada</Label>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>EPIs Fornecidos</Label>
                  <div className="flex gap-2">
                    <Input placeholder="Adicionar EPI" value={novoEpi} onChange={(e) => setNovoEpi(e.target.value)} />
                    <Button onClick={adicionarEpi} type="button">
                      Adicionar
                    </Button>
                  </div>

                  {novaVisita.episFornecidos.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {novaVisita.episFornecidos.map((epi, index) => (
                        <Badge key={index} variant="outline" className="flex items-center gap-1">
                          {epi}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-4 w-4 p-0 ml-1"
                            onClick={() => removerEpi(epi)}
                          >
                            <XCircle className="h-3 w-3" />
                          </Button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={adicionarVisita} className="w-full">
                <UserPlus className="mr-2 h-4 w-4" />
                Registrar Visita
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Visitas em Andamento</CardTitle>
              <CardDescription>Visitas que estão ocorrendo atualmente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {visitas.filter((v) => v.status === "em_andamento").length === 0 ? (
                  <p className="text-center text-muted-foreground py-4">Não há visitas em andamento no momento.</p>
                ) : (
                  visitas
                    .filter((v) => v.status === "em_andamento")
                    .map((visita) => (
                      <div key={visita.id} className="border rounded-md p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium">{visita.visitantes.map((v) => v.nome).join(", ")}</h3>
                            <p className="text-sm text-muted-foreground">
                              {visita.visitantes.map((v) => v.empresa).join(", ")}
                            </p>
                            <div className="mt-2 space-y-1">
                              <p className="text-sm">
                                <span className="font-medium">Motivo:</span> {visita.motivo}
                              </p>
                              <p className="text-sm">
                                <span className="font-medium">Responsável:</span> {visita.responsavelInterno}
                              </p>
                              <p className="text-sm">
                                <span className="font-medium">Setor:</span> {visita.setorVisitado}
                              </p>
                              <p className="text-sm">
                                <span className="font-medium">Entrada:</span>{" "}
                                {format(new Date(visita.dataEntrada), "dd/MM/yyyy HH:mm")}
                              </p>
                            </div>
                          </div>
                          <Badge className={getStatusColor(visita.status)}>{getStatusText(visita.status)}</Badge>
                        </div>
                        <div className="mt-4 flex justify-end gap-2">
                          <Button variant="outline" size="sm" onClick={() => cancelarVisita(visita.id)}>
                            <XCircle className="mr-1 h-4 w-4" />
                            Cancelar
                          </Button>
                          <Button size="sm" onClick={() => concluirVisita(visita.id)}>
                            <CheckCircle2 className="mr-1 h-4 w-4" />
                            Concluir
                          </Button>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Visitas Agendadas</CardTitle>
              <CardDescription>Próximas visitas programadas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {visitas.filter((v) => v.status === "agendada").length === 0 ? (
                  <p className="text-center text-muted-foreground py-4">Não há visitas agendadas no momento.</p>
                ) : (
                  visitas
                    .filter((v) => v.status === "agendada")
                    .map((visita) => (
                      <div key={visita.id} className="border rounded-md p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium">{visita.visitantes.map((v) => v.nome).join(", ")}</h3>
                            <p className="text-sm text-muted-foreground">
                              {visita.visitantes.map((v) => v.empresa).join(", ")}
                            </p>
                            <div className="mt-2 space-y-1">
                              <p className="text-sm">
                                <span className="font-medium">Motivo:</span> {visita.motivo}
                              </p>
                              <p className="text-sm">
                                <span className="font-medium">Responsável:</span> {visita.responsavelInterno}
                              </p>
                              <p className="text-sm">
                                <span className="font-medium">Setor:</span> {visita.setorVisitado}
                              </p>
                              <p className="text-sm">
                                <span className="font-medium">Data Programada:</span>{" "}
                                {format(new Date(visita.dataEntrada), "dd/MM/yyyy HH:mm")}
                              </p>
                            </div>
                          </div>
                          <Badge className={getStatusColor(visita.status)}>{getStatusText(visita.status)}</Badge>
                        </div>
                        <div className="mt-4 flex justify-end gap-2">
                          <Button variant="outline" size="sm" onClick={() => cancelarVisita(visita.id)}>
                            <XCircle className="mr-1 h-4 w-4" />
                            Cancelar
                          </Button>
                          <Button size="sm" onClick={() => iniciarVisita(visita.id)}>
                            <CheckCircle2 className="mr-1 h-4 w-4" />
                            Iniciar
                          </Button>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Cadastro de Visitantes */}
        <TabsContent value="visitantes" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Cadastro de Visitantes</CardTitle>
              <CardDescription>Adicione novos visitantes ao sistema</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome Completo</Label>
                  <Input
                    id="nome"
                    placeholder="Nome do visitante"
                    value={novoVisitante.nome}
                    onChange={(e) => setNovoVisitante({ ...novoVisitante, nome: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="documento">Documento (CPF/RG)</Label>
                  <Input
                    id="documento"
                    placeholder="000.000.000-00"
                    value={novoVisitante.documento}
                    onChange={(e) => setNovoVisitante({ ...novoVisitante, documento: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="empresa">Empresa</Label>
                  <Input
                    id="empresa"
                    placeholder="Nome da empresa"
                    value={novoVisitante.empresa}
                    onChange={(e) => setNovoVisitante({ ...novoVisitante, empresa: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tipo">Tipo de Visitante</Label>
                  <Select
                    value={novoVisitante.tipo}
                    onValueChange={(value: "cliente" | "fornecedor" | "prestador" | "autoridade" | "outro") =>
                      setNovoVisitante({ ...novoVisitante, tipo: value })
                    }
                  >
                    <SelectTrigger id="tipo">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cliente">Cliente</SelectItem>
                      <SelectItem value="fornecedor">Fornecedor</SelectItem>
                      <SelectItem value="prestador">Prestador de Serviço</SelectItem>
                      <SelectItem value="autoridade">Autoridade</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone</Label>
                  <Input
                    id="telefone"
                    placeholder="(00) 00000-0000"
                    value={novoVisitante.telefone}
                    onChange={(e) => setNovoVisitante({ ...novoVisitante, telefone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail (opcional)</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="email@exemplo.com"
                    value={novoVisitante.email}
                    onChange={(e) => setNovoVisitante({ ...novoVisitante, email: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab("registro")}>
                Voltar
              </Button>
              <Button onClick={adicionarVisitante}>
                <UserPlus className="mr-2 h-4 w-4" />
                Cadastrar Visitante
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Visitantes Cadastrados</CardTitle>
              <CardDescription>Lista de todos os visitantes cadastrados no sistema</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Buscar visitante..." className="pl-8" />
                </div>

                <div className="border rounded-md divide-y">
                  {visitantesCadastrados.map((visitante) => (
                    <div key={visitante.id} className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium">{visitante.nome}</h3>
                          <p className="text-sm text-muted-foreground">{visitante.empresa}</p>
                          <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-x-4 text-sm">
                            <p>
                              <span className="font-medium">Documento:</span> {visitante.documento}
                            </p>
                            <p>
                              <span className="font-medium">Telefone:</span> {visitante.telefone}
                            </p>
                            {visitante.email && (
                              <p>
                                <span className="font-medium">E-mail:</span> {visitante.email}
                              </p>
                            )}
                            <p>
                              <span className="font-medium">Tipo:</span> {getTipoVisitanteText(visitante.tipo)}
                            </p>
                          </div>
                        </div>
                        <Badge variant="outline">{getTipoVisitanteText(visitante.tipo)}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Histórico de Visitas */}
        <TabsContent value="historico" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Visitas</CardTitle>
              <CardDescription>Consulte todas as visitas registradas</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar visita..."
                    className="pl-8"
                    value={filtroVisitas.termo}
                    onChange={(e) => setFiltroVisitas({ ...filtroVisitas, termo: e.target.value })}
                  />
                </div>

                <Select
                  value={filtroVisitas.status}
                  onValueChange={(value) => setFiltroVisitas({ ...filtroVisitas, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Filtrar por status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Todas</SelectItem>
                    <SelectItem value="agendada">Agendadas</SelectItem>
                    <SelectItem value="em_andamento">Em Andamento</SelectItem>
                    <SelectItem value="concluida">Concluídas</SelectItem>
                    <SelectItem value="cancelada">Canceladas</SelectItem>
                  </SelectContent>
                </Select>

                <Select
                  value={filtroVisitas.periodo}
                  onValueChange={(value) => setFiltroVisitas({ ...filtroVisitas, periodo: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Filtrar por período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hoje">Hoje</SelectItem>
                    <SelectItem value="semana">Esta Semana</SelectItem>
                    <SelectItem value="mes">Este Mês</SelectItem>
                    <SelectItem value="todas">Todas</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-4">
                {visitasFiltradas.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    Nenhuma visita encontrada com os filtros selecionados.
                  </p>
                ) : (
                  visitasFiltradas.map((visita) => (
                    <div key={visita.id} className="border rounded-md p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium">{visita.visitantes.map((v) => v.nome).join(", ")}</h3>
                          <p className="text-sm text-muted-foreground">
                            {visita.visitantes.map((v) => v.empresa).join(", ")}
                          </p>
                          <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1 text-sm">
                            <p>
                              <span className="font-medium">Motivo:</span> {visita.motivo}
                            </p>
                            <p>
                              <span className="font-medium">Responsável:</span> {visita.responsavelInterno}
                            </p>
                            <p>
                              <span className="font-medium">Setor:</span> {visita.setorVisitado}
                            </p>
                            <p>
                              <span className="font-medium">Entrada:</span>{" "}
                              {format(new Date(visita.dataEntrada), "dd/MM/yyyy HH:mm")}
                            </p>
                            {visita.dataSaida && (
                              <p>
                                <span className="font-medium">Saída:</span>{" "}
                                {format(new Date(visita.dataSaida), "dd/MM/yyyy HH:mm")}
                              </p>
                            )}
                            {visita.observacoes && (
                              <p className="col-span-2">
                                <span className="font-medium">Observações:</span> {visita.observacoes}
                              </p>
                            )}
                          </div>

                          <div className="mt-2 flex flex-wrap gap-2">
                            {visita.documentosApresentados && (
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                <CheckCircle2 className="mr-1 h-3 w-3" />
                                Documentos OK
                              </Badge>
                            )}
                            {visita.integracaoRealizada && (
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                <CheckCircle2 className="mr-1 h-3 w-3" />
                                Integração OK
                              </Badge>
                            )}
                            {visita.episFornecidos && visita.episFornecidos.length > 0 && (
                              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                <ClipboardCheck className="mr-1 h-3 w-3" />
                                EPIs Fornecidos
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge className={getStatusColor(visita.status)}>{getStatusText(visita.status)}</Badge>
                          <Button variant="ghost" size="sm" className="flex items-center">
                            <FileText className="mr-1 h-4 w-4" />
                            Detalhes
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
