"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { Calendar } from "@/components/ui/calendar"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Camera, CalendarIcon, Save, Upload, X } from "lucide-react"

type AtividadeApoio = "lideranca" | "brigadista" | "cipeiro" | "operador_empilhadeira" | "nenhuma"

type Funcionario = {
  id: string
  nome: string
  funcao: string
  dataAdmissao: Date
  turno: "1" | "2" | "3" | "ADM"
  atividadesApoio: AtividadeApoio[]
  horarioEntrada: string
  horarioSaida: string
  horarioIntervalo: string
  foto?: string
  login: string
  senha: string
  cargo: string
  semanaAtual: "A" | "B" | "C"
  perfil: "administrador" | "operador" | "laboratorio"
  aceiteLGPD: boolean
  feriasAgendadas?: {
    dataInicio: Date
    dataFim: Date
    status: "solicitado" | "aprovado" | "negado"
  }[]
}

export default function CadastroPerfil() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("cadastro")
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [solicitacaoFerias, setSolicitacaoFerias] = useState<{
    dataInicio: Date | undefined
    dataFim: Date | undefined
  }>({
    dataInicio: undefined,
    dataFim: undefined,
  })
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [funcionario, setFuncionario] = useState<Funcionario>({
    id: "",
    nome: "",
    funcao: "",
    dataAdmissao: new Date(),
    turno: "1",
    atividadesApoio: [],
    horarioEntrada: "",
    horarioSaida: "",
    horarioIntervalo: "",
    foto: undefined,
    login: "",
    senha: "",
    cargo: "",
    semanaAtual: "A",
    perfil: "operador",
    aceiteLGPD: false,
    feriasAgendadas: [],
  })

  // Função para atualizar os horários com base no turno selecionado
  const atualizarHorariosPorTurno = (turno: string) => {
    switch (turno) {
      case "1":
        setFuncionario({
          ...funcionario,
          turno: "1",
          horarioEntrada: "06:00",
          horarioSaida: "14:45",
          horarioIntervalo: "10:00 - 11:00",
        })
        break
      case "2":
        setFuncionario({
          ...funcionario,
          turno: "2",
          horarioEntrada: "13:55",
          horarioSaida: "22:35",
          horarioIntervalo: "18:00 - 19:00",
        })
        break
      case "3":
        setFuncionario({
          ...funcionario,
          turno: "3",
          horarioEntrada: "22:13",
          horarioSaida: "06:00",
          horarioIntervalo: "02:00 - 03:00",
        })
        break
      case "ADM":
        setFuncionario({
          ...funcionario,
          turno: "ADM",
          horarioEntrada: "08:00",
          horarioSaida: "17:00",
          horarioIntervalo: "12:00 - 13:00",
        })
        break
      default:
        break
    }
  }

  // Função para lidar com o upload de foto
  const handleFotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setFuncionario({
          ...funcionario,
          foto: reader.result as string,
        })
      }
      reader.readAsDataURL(file)
    }
  }

  // Função para lidar com a alteração de atividades de apoio
  const handleAtividadeApoioChange = (atividade: AtividadeApoio, checked: boolean) => {
    if (checked) {
      setFuncionario({
        ...funcionario,
        atividadesApoio: [...funcionario.atividadesApoio, atividade],
      })
    } else {
      setFuncionario({
        ...funcionario,
        atividadesApoio: funcionario.atividadesApoio.filter((a) => a !== atividade),
      })
    }
  }

  // Função para salvar o cadastro
  const salvarCadastro = () => {
    // Validação básica
    if (!funcionario.nome || !funcionario.funcao || !funcionario.login || !funcionario.senha) {
      toast({
        title: "Erro ao salvar",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    if (!funcionario.aceiteLGPD) {
      toast({
        title: "Erro ao salvar",
        description: "É necessário aceitar os termos de LGPD.",
        variant: "destructive",
      })
      return
    }

    // Aqui você implementaria a lógica para salvar no banco de dados
    // Por enquanto, apenas mostramos uma mensagem de sucesso
    toast({
      title: "Cadastro salvo com sucesso!",
      description: `O perfil de ${funcionario.nome} foi cadastrado.`,
    })
  }

  // Função para solicitar férias
  const solicitarFerias = () => {
    if (!solicitacaoFerias.dataInicio || !solicitacaoFerias.dataFim) {
      toast({
        title: "Erro na solicitação",
        description: "Selecione as datas de início e fim das férias.",
        variant: "destructive",
      })
      return
    }

    const novasSolicitacoes = [
      ...(funcionario.feriasAgendadas || []),
      {
        dataInicio: solicitacaoFerias.dataInicio,
        dataFim: solicitacaoFerias.dataFim,
        status: "solicitado" as const,
      },
    ]

    setFuncionario({
      ...funcionario,
      feriasAgendadas: novasSolicitacoes,
    })

    setSolicitacaoFerias({
      dataInicio: undefined,
      dataFim: undefined,
    })

    toast({
      title: "Solicitação enviada",
      description: "Sua solicitação de férias foi enviada para aprovação.",
    })
  }

  // Função para verificar se uma data é folga
  const isFolga = (date: Date) => {
    const dia = date.getDay() // 0 = domingo, 6 = sábado

    // Lógica para determinar se é folga com base na semana atual
    if (funcionario.semanaAtual === "A") {
      return dia === 0 // Domingo é folga na semana A
    } else if (funcionario.semanaAtual === "B") {
      return dia === 6 // Sábado é folga na semana B
    } else if (funcionario.semanaAtual === "C") {
      return dia === 0 || dia === 6 // Sábado e domingo são folgas na semana C
    }

    return false
  }

  // Função para verificar se uma data é férias
  const isFerias = (date: Date) => {
    if (!funcionario.feriasAgendadas || funcionario.feriasAgendadas.length === 0) return false

    return funcionario.feriasAgendadas.some((ferias) => {
      const inicio = new Date(ferias.dataInicio)
      const fim = new Date(ferias.dataFim)
      return date >= inicio && date <= fim
    })
  }

  // Função para obter o status das férias em uma data
  const getFeriasStatus = (date: Date) => {
    if (!funcionario.feriasAgendadas || funcionario.feriasAgendadas.length === 0) return null

    const ferias = funcionario.feriasAgendadas.find((ferias) => {
      const inicio = new Date(ferias.dataInicio)
      const fim = new Date(ferias.dataFim)
      return date >= inicio && date <= fim
    })

    return ferias?.status || null
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Cadastro de Perfil</h1>

      <Tabs defaultValue="cadastro" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="cadastro">Dados Pessoais</TabsTrigger>
          <TabsTrigger value="escala">Escala e Turnos</TabsTrigger>
          <TabsTrigger value="ferias">Folgas e Férias</TabsTrigger>
        </TabsList>

        <TabsContent value="cadastro" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Dados Pessoais e Funcionais</CardTitle>
              <CardDescription>Preencha os dados do funcionário para cadastro no sistema</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-1 space-y-4">
                  <div>
                    <Label htmlFor="nome">Nome Completo*</Label>
                    <Input
                      id="nome"
                      value={funcionario.nome}
                      onChange={(e) => setFuncionario({ ...funcionario, nome: e.target.value })}
                      placeholder="Nome completo do funcionário"
                    />
                  </div>

                  <div>
                    <Label htmlFor="funcao">Função*</Label>
                    <Input
                      id="funcao"
                      value={funcionario.funcao}
                      onChange={(e) => setFuncionario({ ...funcionario, funcao: e.target.value })}
                      placeholder="Função do funcionário"
                    />
                  </div>

                  <div>
                    <Label htmlFor="cargo">Cargo*</Label>
                    <Input
                      id="cargo"
                      value={funcionario.cargo}
                      onChange={(e) => setFuncionario({ ...funcionario, cargo: e.target.value })}
                      placeholder="Cargo do funcionário"
                    />
                  </div>

                  <div>
                    <Label htmlFor="data-admissao">Data de Admissão*</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {funcionario.dataAdmissao ? (
                            format(funcionario.dataAdmissao, "PPP", { locale: ptBR })
                          ) : (
                            <span>Selecione uma data</span>
                          )}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={funcionario.dataAdmissao}
                          onSelect={(date) => date && setFuncionario({ ...funcionario, dataAdmissao: date })}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div>
                    <Label>Atividades de Apoio</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="lideranca"
                          checked={funcionario.atividadesApoio.includes("lideranca")}
                          onCheckedChange={(checked) => handleAtividadeApoioChange("lideranca", checked as boolean)}
                        />
                        <label
                          htmlFor="lideranca"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Liderança de Área
                        </label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="brigadista"
                          checked={funcionario.atividadesApoio.includes("brigadista")}
                          onCheckedChange={(checked) => handleAtividadeApoioChange("brigadista", checked as boolean)}
                        />
                        <label
                          htmlFor="brigadista"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Brigadista
                        </label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="cipeiro"
                          checked={funcionario.atividadesApoio.includes("cipeiro")}
                          onCheckedChange={(checked) => handleAtividadeApoioChange("cipeiro", checked as boolean)}
                        />
                        <label
                          htmlFor="cipeiro"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          CIPEIRO
                        </label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="operador_empilhadeira"
                          checked={funcionario.atividadesApoio.includes("operador_empilhadeira")}
                          onCheckedChange={(checked) =>
                            handleAtividadeApoioChange("operador_empilhadeira", checked as boolean)
                          }
                        />
                        <label
                          htmlFor="operador_empilhadeira"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Operador de Empilhadeira
                        </label>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex-1 space-y-4">
                  <div className="flex flex-col items-center justify-center space-y-4">
                    <div className="relative w-40 h-40 border-2 border-dashed rounded-lg flex items-center justify-center overflow-hidden">
                      {funcionario.foto ? (
                        <>
                          <img
                            src={funcionario.foto || "/placeholder.svg"}
                            alt="Foto do funcionário"
                            className="w-full h-full object-cover"
                          />
                          <button
                            className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1"
                            onClick={() => setFuncionario({ ...funcionario, foto: undefined })}
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </>
                      ) : (
                        <div className="flex flex-col items-center justify-center text-muted-foreground">
                          <Camera className="h-10 w-10 mb-2" />
                          <span className="text-sm">Foto do Funcionário</span>
                        </div>
                      )}
                    </div>
                    <input
                      type="file"
                      ref={fileInputRef}
                      accept="image/*"
                      className="hidden"
                      onChange={handleFotoUpload}
                    />
                    <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                      <Upload className="h-4 w-4 mr-2" />
                      Carregar Foto
                    </Button>
                  </div>

                  <div>
                    <Label htmlFor="perfil">Perfil de Acesso*</Label>
                    <Select
                      value={funcionario.perfil}
                      onValueChange={(value: "administrador" | "operador" | "laboratorio") =>
                        setFuncionario({ ...funcionario, perfil: value })
                      }
                    >
                      <SelectTrigger id="perfil">
                        <SelectValue placeholder="Selecione o perfil" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="administrador">Administrador</SelectItem>
                        <SelectItem value="operador">Operador</SelectItem>
                        <SelectItem value="laboratorio">Laboratório</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="login">Login*</Label>
                    <Input
                      id="login"
                      value={funcionario.login}
                      onChange={(e) => setFuncionario({ ...funcionario, login: e.target.value })}
                      placeholder="Login para acesso ao sistema"
                    />
                  </div>

                  <div>
                    <Label htmlFor="senha">Senha*</Label>
                    <Input
                      id="senha"
                      type="password"
                      value={funcionario.senha}
                      onChange={(e) => setFuncionario({ ...funcionario, senha: e.target.value })}
                      placeholder="Senha para acesso ao sistema"
                    />
                  </div>
                </div>
              </div>

              <div className="border p-4 rounded-md bg-muted/30">
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="aceite-lgpd"
                    checked={funcionario.aceiteLGPD}
                    onCheckedChange={(checked) => setFuncionario({ ...funcionario, aceiteLGPD: checked as boolean })}
                  />
                  <div>
                    <label
                      htmlFor="aceite-lgpd"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Aceito os termos de uso e política de privacidade
                    </label>
                    <p className="text-xs text-muted-foreground mt-1">
                      Ao marcar esta opção, você concorda com o tratamento dos seus dados pessoais conforme a Lei Geral
                      de Proteção de Dados (LGPD) para fins de gestão de recursos humanos, controle de acesso e
                      segurança. Seus dados serão armazenados de forma segura e não serão compartilhados com terceiros
                      sem o seu consentimento prévio.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab("escala")}>
                Próximo
              </Button>
              <Button onClick={salvarCadastro}>
                <Save className="h-4 w-4 mr-2" />
                Salvar Cadastro
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="escala" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Escala e Turnos</CardTitle>
              <CardDescription>Configure a escala de trabalho e turnos do funcionário</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="turno">Turno*</Label>
                    <Select
                      value={funcionario.turno}
                      onValueChange={(value: "1" | "2" | "3" | "ADM") => atualizarHorariosPorTurno(value)}
                    >
                      <SelectTrigger id="turno">
                        <SelectValue placeholder="Selecione o turno" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Turno 1 (06:00 às 14:45)</SelectItem>
                        <SelectItem value="2">Turno 2 (13:55 às 22:35)</SelectItem>
                        <SelectItem value="3">Turno 3 (22:13 às 06:00)</SelectItem>
                        <SelectItem value="ADM">Administrativo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="semana-atual">Semana Atual*</Label>
                    <Select
                      value={funcionario.semanaAtual}
                      onValueChange={(value: "A" | "B" | "C") => setFuncionario({ ...funcionario, semanaAtual: value })}
                    >
                      <SelectTrigger id="semana-atual">
                        <SelectValue placeholder="Selecione a semana" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A">Semana A (Folga no Domingo)</SelectItem>
                        <SelectItem value="B">Semana B (Folga no Sábado)</SelectItem>
                        <SelectItem value="C">Semana C (Folga no Sábado e Domingo)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="horario-entrada">Horário de Entrada</Label>
                    <Input
                      id="horario-entrada"
                      type="time"
                      value={funcionario.horarioEntrada}
                      onChange={(e) => setFuncionario({ ...funcionario, horarioEntrada: e.target.value })}
                    />
                  </div>

                  <div>
                    <Label htmlFor="horario-saida">Horário de Saída</Label>
                    <Input
                      id="horario-saida"
                      type="time"
                      value={funcionario.horarioSaida}
                      onChange={(e) => setFuncionario({ ...funcionario, horarioSaida: e.target.value })}
                    />
                  </div>

                  <div>
                    <Label htmlFor="horario-intervalo">Horário de Intervalo</Label>
                    <Input
                      id="horario-intervalo"
                      value={funcionario.horarioIntervalo}
                      onChange={(e) => setFuncionario({ ...funcionario, horarioIntervalo: e.target.value })}
                      placeholder="Ex: 12:00 - 13:00"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Escala de Trabalho</h3>

                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">Semana A</h4>
                    <div className="grid grid-cols-7 gap-1 text-center text-sm">
                      <div className="p-2 border rounded">Seg</div>
                      <div className="p-2 border rounded">Ter</div>
                      <div className="p-2 border rounded">Qua</div>
                      <div className="p-2 border rounded">Qui</div>
                      <div className="p-2 border rounded">Sex</div>
                      <div className="p-2 border rounded">Sáb</div>
                      <div className="p-2 border rounded bg-red-100 dark:bg-red-900/20">Dom (FOLGA)</div>
                    </div>
                  </div>

                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">Semana B</h4>
                    <div className="grid grid-cols-7 gap-1 text-center text-sm">
                      <div className="p-2 border rounded">Seg</div>
                      <div className="p-2 border rounded">Ter</div>
                      <div className="p-2 border rounded">Qua</div>
                      <div className="p-2 border rounded">Qui</div>
                      <div className="p-2 border rounded">Sex</div>
                      <div className="p-2 border rounded bg-red-100 dark:bg-red-900/20">Sáb (FOLGA)</div>
                      <div className="p-2 border rounded">Dom</div>
                    </div>
                  </div>

                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">Semana C</h4>
                    <div className="grid grid-cols-7 gap-1 text-center text-sm">
                      <div className="p-2 border rounded">Seg</div>
                      <div className="p-2 border rounded">Ter</div>
                      <div className="p-2 border rounded">Qua</div>
                      <div className="p-2 border rounded">Qui</div>
                      <div className="p-2 border rounded">Sex</div>
                      <div className="p-2 border rounded bg-red-100 dark:bg-red-900/20">Sáb (FOLGA)</div>
                      <div className="p-2 border rounded bg-red-100 dark:bg-red-900/20">Dom (FOLGA)</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab("cadastro")}>
                Voltar
              </Button>
              <Button variant="outline" onClick={() => setActiveTab("ferias")}>
                Próximo
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="ferias" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Folgas e Férias</CardTitle>
              <CardDescription>Visualize folgas e solicite férias</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Calendário de Folgas</h3>
                  <div className="border rounded-md p-4">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      className="rounded-md border"
                      modifiers={{
                        folga: (date) => isFolga(date),
                        ferias: (date) => isFerias(date),
                        feriasSolicitadas: (date) => isFerias(date) && getFeriasStatus(date) === "solicitado",
                        feriasAprovadas: (date) => isFerias(date) && getFeriasStatus(date) === "aprovado",
                      }}
                      modifiersClassNames={{
                        folga: "bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300",
                        ferias: "font-bold",
                        feriasSolicitadas: "bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-300",
                        feriasAprovadas: "bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300",
                      }}
                    />
                    <div className="mt-4 space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded bg-red-100 dark:bg-red-900/20"></div>
                        <span className="text-sm">Folga</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded bg-yellow-100 dark:bg-yellow-900/20"></div>
                        <span className="text-sm">Férias Solicitadas</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded bg-green-100 dark:bg-green-900/20"></div>
                        <span className="text-sm">Férias Aprovadas</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Solicitação de Férias</h3>
                  <div className="border rounded-md p-4">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="data-inicio-ferias">Data de Início</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {solicitacaoFerias.dataInicio ? (
                                format(solicitacaoFerias.dataInicio, "PPP", { locale: ptBR })
                              ) : (
                                <span>Selecione uma data</span>
                              )}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={solicitacaoFerias.dataInicio}
                              onSelect={(date) =>
                                date && setSolicitacaoFerias({ ...solicitacaoFerias, dataInicio: date })
                              }
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>

                      <div>
                        <Label htmlFor="data-fim-ferias">Data de Fim</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {solicitacaoFerias.dataFim ? (
                                format(solicitacaoFerias.dataFim, "PPP", { locale: ptBR })
                              ) : (
                                <span>Selecione uma data</span>
                              )}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={solicitacaoFerias.dataFim}
                              onSelect={(date) => date && setSolicitacaoFerias({ ...solicitacaoFerias, dataFim: date })}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>

                      <Button onClick={solicitarFerias} className="w-full">
                        Solicitar Férias
                      </Button>
                    </div>
                  </div>

                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">Solicitações Pendentes</h4>
                    {funcionario.feriasAgendadas && funcionario.feriasAgendadas.length > 0 ? (
                      <div className="space-y-2">
                        {funcionario.feriasAgendadas.map((ferias, index) => (
                          <div key={index} className="border rounded-md p-3">
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="font-medium">
                                  {format(new Date(ferias.dataInicio), "dd/MM/yyyy")} até{" "}
                                  {format(new Date(ferias.dataFim), "dd/MM/yyyy")}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {ferias.status === "solicitado"
                                    ? "Aguardando aprovação"
                                    : ferias.status === "aprovado"
                                      ? "Aprovado"
                                      : "Negado"}
                                </p>
                              </div>
                              <div
                                className={`px-2 py-1 rounded-full text-xs ${
                                  ferias.status === "solicitado"
                                    ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
                                    : ferias.status === "aprovado"
                                      ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
                                      : "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
                                }`}
                              >
                                {ferias.status === "solicitado"
                                  ? "Solicitado"
                                  : ferias.status === "aprovado"
                                    ? "Aprovado"
                                    : "Negado"}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">Nenhuma solicitação de férias pendente.</p>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab("escala")}>
                Voltar
              </Button>
              <Button onClick={salvarCadastro}>
                <Save className="h-4 w-4 mr-2" />
                Salvar Cadastro
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
