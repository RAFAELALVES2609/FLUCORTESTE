"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { CalendarIcon, Plus } from "lucide-react"

type AtividadeParada = {
  id: string
  descricao: string
  responsavel: string
  turno: "A" | "B" | "C" | "ADM"
  dataHoraPrevista: string // Changed from Date to string
  dataHoraInicio?: string // Changed from Date to string
  dataHoraFim?: string // Changed from Date to string
  status: "pendente" | "em_andamento" | "concluida" | "cancelada"
  tipo: "pre_parada" | "durante_parada" | "pos_parada"
  observacoes?: string
}

type ParadaProgramada = {
  id: string
  processo: string
  descricao: string
  dataProgramada: string // Changed from Date to string
  dataInicio?: string // Changed from Date to string
  dataFim?: string // Changed from Date to string
  status: "programada" | "em_andamento" | "concluida" | "cancelada"
  turnoResponsavel: "A" | "B" | "C" | "ADM"
  responsavel: string
  terceirizado: boolean
  terceirizadoNome?: string
  terceirizadoLiberacaoSST: boolean
  tempoPrevisto: string
  tempoRealizado?: string
  comentarios?: string
  atividades: AtividadeParada[]
}

// Helper function to format dates safely
const formatDate = (dateStr: string, formatStr = "dd/MM/yyyy"): string => {
  try {
    return format(new Date(dateStr), formatStr, { locale: ptBR })
  } catch (error) {
    return "Data inválida"
  }
}

// Helper function to convert Date to ISO string
const dateToString = (date: Date): string => {
  return date.toISOString()
}

export default function ParadaProgramada() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("programacao")
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [dialogNovaParadaAberto, setDialogNovaParadaAberto] = useState(false)
  const [dialogNovaAtividadeAberto, setDialogNovaAtividadeAberto] = useState(false)
  const [paradaSelecionada, setParadaSelecionada] = useState<ParadaProgramada | null>(null)

  const [novaParada, setNovaParada] = useState<
    Omit<Omit<ParadaProgramada, "id" | "status" | "atividades">, "dataProgramada"> & { dataProgramada: Date }
  >({
    processo: "",
    descricao: "",
    dataProgramada: new Date(),
    turnoResponsavel: "A",
    responsavel: "",
    terceirizado: false,
    terceirizadoLiberacaoSST: false,
    tempoPrevisto: "",
    comentarios: "",
  })

  const [novaAtividade, setNovaAtividade] = useState<
    Omit<Omit<AtividadeParada, "id" | "status">, "dataHoraPrevista"> & { dataHoraPrevista: Date }
  >({
    descricao: "",
    responsavel: "",
    turno: "A",
    dataHoraPrevista: new Date(),
    tipo: "pre_parada",
    observacoes: "",
  })

  // Estado para paradas programadas - convert Date objects to strings
  const [paradasProgramadas, setParadasProgramadas] = useState<ParadaProgramada[]>([
    {
      id: "1",
      processo: "Evaporador E-101",
      descricao: "Limpeza química e inspeção de tubulação",
      dataProgramada: dateToString(new Date(new Date().setDate(new Date().getDate() + 5))),
      status: "programada",
      turnoResponsavel: "A",
      responsavel: "João Silva",
      terceirizado: true,
      terceirizadoNome: "TecnoLimp Serviços Industriais",
      terceirizadoLiberacaoSST: true,
      tempoPrevisto: "8 horas",
      comentarios: "Necessário preparar solução de limpeza com antecedência",
      atividades: [
        {
          id: "1-1",
          descricao: "Preparação de solução de limpeza",
          responsavel: "Carlos Santos",
          turno: "A",
          dataHoraPrevista: dateToString(new Date(new Date().setDate(new Date().getDate() + 4))),
          status: "pendente",
          tipo: "pre_parada",
          observacoes: "Utilizar EPI adequado para manuseio de produtos químicos",
        },
        {
          id: "1-2",
          descricao: "Isolamento da área e bloqueio de válvulas",
          responsavel: "Pedro Almeida",
          turno: "A",
          dataHoraPrevista: dateToString(new Date(new Date().setDate(new Date().getDate() + 5))),
          status: "pendente",
          tipo: "durante_parada",
        },
        {
          id: "1-3",
          descricao: "Teste de estanqueidade após limpeza",
          responsavel: "Ana Souza",
          turno: "B",
          dataHoraPrevista: dateToString(new Date(new Date().setDate(new Date().getDate() + 5))),
          status: "pendente",
          tipo: "pos_parada",
        },
      ],
    },
    {
      id: "2",
      processo: "Filtro Prensa FP-203",
      descricao: "Substituição de placas e manutenção preventiva",
      dataProgramada: dateToString(new Date(new Date().setDate(new Date().getDate() + 2))),
      status: "programada",
      turnoResponsavel: "B",
      responsavel: "Maria Oliveira",
      terceirizado: false,
      terceirizadoLiberacaoSST: false,
      tempoPrevisto: "4 horas",
      atividades: [
        {
          id: "2-1",
          descricao: "Verificação do estoque de placas de reposição",
          responsavel: "José Pereira",
          turno: "ADM",
          dataHoraPrevista: dateToString(new Date(new Date().setDate(new Date().getDate() + 1))),
          status: "pendente",
          tipo: "pre_parada",
        },
        {
          id: "2-2",
          descricao: "Desmontagem e limpeza do filtro",
          responsavel: "Carlos Santos",
          turno: "B",
          dataHoraPrevista: dateToString(new Date(new Date().setDate(new Date().getDate() + 2))),
          status: "pendente",
          tipo: "durante_parada",
        },
      ],
    },
  ])

  // Função para adicionar nova parada programada
  const adicionarParada = () => {
    if (!novaParada.processo || !novaParada.descricao || !novaParada.responsavel || !novaParada.tempoPrevisto) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (paradasProgramadas.length + 1).toString()
    const paradaCompleta: ParadaProgramada = {
      id: novoId,
      ...novaParada,
      dataProgramada: dateToString(novaParada.dataProgramada),
      status: "programada",
      atividades: [],
    }

    setParadasProgramadas([...paradasProgramadas, paradaCompleta])
    setNovaParada({
      processo: "",
      descricao: "",
      dataProgramada: new Date(),
      turnoResponsavel: "A",
      responsavel: "",
      terceirizado: false,
      terceirizadoLiberacaoSST: false,
      tempoPrevisto: "",
      comentarios: "",
    })
    setDialogNovaParadaAberto(false)

    toast({
      title: "Parada programada registrada",
      description: "A nova parada programada foi registrada com sucesso.",
    })
  }

  // Função para adicionar nova atividade
  const adicionarAtividade = () => {
    if (!paradaSelecionada || !novaAtividade.descricao || !novaAtividade.responsavel) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = `${paradaSelecionada.id}-${paradaSelecionada.atividades.length + 1}`
    const atividadeCompleta: AtividadeParada = {
      id: novoId,
      ...novaAtividade,
      dataHoraPrevista: dateToString(novaAtividade.dataHoraPrevista),
      status: "pendente",
    }

    const paradasAtualizadas = paradasProgramadas.map((parada) =>
      parada.id === paradaSelecionada.id
        ? { ...parada, atividades: [...parada.atividades, atividadeCompleta] }
        : parada,
    )

    setParadasProgramadas(paradasAtualizadas)
    setParadaSelecionada({
      ...paradaSelecionada,
      atividades: [...paradaSelecionada.atividades, atividadeCompleta],
    })

    setNovaAtividade({
      descricao: "",
      responsavel: "",
      turno: "A",
      dataHoraPrevista: new Date(),
      tipo: "pre_parada",
      observacoes: "",
    })
    setDialogNovaAtividadeAberto(false)

    toast({
      title: "Atividade adicionada",
      description: "A nova atividade foi adicionada com sucesso.",
    })
  }

  // Função para atualizar status da parada
  const atualizarStatusParada = (id: string, novoStatus: "programada" | "em_andamento" | "concluida" | "cancelada") => {
    const paradasAtualizadas = paradasProgramadas.map((parada) => {
      if (parada.id === id) {
        const paradaAtualizada = { ...parada, status: novoStatus }

        // Atualizar datas de início e fim conforme o status
        if (novoStatus === "em_andamento" && !paradaAtualizada.dataInicio) {
          paradaAtualizada.dataInicio = dateToString(new Date())
        } else if (novoStatus === "concluida" && !paradaAtualizada.dataFim) {
          paradaAtualizada.dataFim = dateToString(new Date())

          // Calcular tempo realizado
          if (paradaAtualizada.dataInicio) {
            const inicio = new Date(paradaAtualizada.dataInicio).getTime()
            const fim = new Date(paradaAtualizada.dataFim).getTime()
            const diferencaHoras = Math.round(((fim - inicio) / (1000 * 60 * 60)) * 10) / 10
            paradaAtualizada.tempoRealizado = `${diferencaHoras} horas`
          }
        }

        return paradaAtualizada
      }
      return parada
    })

    setParadasProgramadas(paradasAtualizadas)

    if (paradaSelecionada && paradaSelecionada.id === id) {
      const paradaAtualizada = paradasAtualizadas.find((p) => p.id === id)
      if (paradaAtualizada) {
        setParadaSelecionada(paradaAtualizada)
      }
    }

    toast({
      title: "Status atualizado",
      description: "O status da parada programada foi atualizado com sucesso.",
    })
  }

  // Função para atualizar status da atividade
  const atualizarStatusAtividade = (
    paradaId: string,
    atividadeId: string,
    novoStatus: "pendente" | "em_andamento" | "concluida" | "cancelada",
  ) => {
    const paradasAtualizadas = paradasProgramadas.map((parada) => {
      if (parada.id === paradaId) {
        const atividadesAtualizadas = parada.atividades.map((atividade) => {
          if (atividade.id === atividadeId) {
            const atividadeAtualizada = { ...atividade, status: novoStatus }

            // Atualizar datas de início e fim conforme o status
            if (novoStatus === "em_andamento" && !atividadeAtualizada.dataHoraInicio) {
              atividadeAtualizada.dataHoraInicio = dateToString(new Date())
            } else if (novoStatus === "concluida" && !atividadeAtualizada.dataHoraFim) {
              atividadeAtualizada.dataHoraFim = dateToString(new Date())
            }

            return atividadeAtualizada
          }
          return atividade
        })

        return { ...parada, atividades: atividadesAtualizadas }
      }
      return parada
    })

    setParadasProgramadas(paradasAtualizadas)

    if (paradaSelecionada && paradaSelecionada.id === paradaId) {
      const paradaAtualizada = paradasAtualizadas.find((p) => p.id === paradaId)
      if (paradaAtualizada) {
        setParadaSelecionada(paradaAtualizada)
      }
    }

    toast({
      title: "Status atualizado",
      description: "O status da atividade foi atualizado com sucesso.",
    })
  }

  // Função para obter a cor do status
  const getStatusColor = (status: string) => {
    switch (status) {
      case "programada":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
      case "em_andamento":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
      case "concluida":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "cancelada":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      case "pendente":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  // Função para obter o texto do status
  const getStatusText = (status: string) => {
    switch (status) {
      case "programada":
        return "Programada"
      case "em_andamento":
        return "Em Andamento"
      case "concluida":
        return "Concluída"
      case "cancelada":
        return "Cancelada"
      case "pendente":
        return "Pendente"
      default:
        return "Não definido"
    }
  }

  // Função para obter o texto do tipo de atividade
  const getTipoAtividadeText = (tipo: string) => {
    switch (tipo) {
      case "pre_parada":
        return "Pré-Parada"
      case "durante_parada":
        return "Durante Parada"
      case "pos_parada":
        return "Pós-Parada"
      default:
        return "Não definido"
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Parada Programada de Processo (PPP)</h1>

      <Tabs defaultValue="programacao" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="programacao">Programação</TabsTrigger>
          <TabsTrigger value="historico">Histórico</TabsTrigger>
        </TabsList>

        <TabsContent value="programacao" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Paradas Programadas</CardTitle>
                <CardDescription>Programação e acompanhamento de paradas de processo</CardDescription>
              </div>
              <Dialog open={dialogNovaParadaAberto} onOpenChange={setDialogNovaParadaAberto}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Nova Parada
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Programar Nova Parada</DialogTitle>
                    <DialogDescription>
                      Preencha as informações para programar uma nova parada de processo.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div>
                      <Label htmlFor="processo">Processo/Equipamento*</Label>
                      <Input
                        id="processo"
                        value={novaParada.processo}
                        onChange={(e) => setNovaParada({ ...novaParada, processo: e.target.value })}
                        placeholder="Ex: Evaporador E-101"
                      />
                    </div>
                    <div>
                      <Label htmlFor="descricao-parada">Descrição*</Label>
                      <Textarea
                        id="descricao-parada"
                        value={novaParada.descricao}
                        onChange={(e) => setNovaParada({ ...novaParada, descricao: e.target.value })}
                        placeholder="Descreva o objetivo da parada programada"
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label htmlFor="data-programada">Data Programada*</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {format(novaParada.dataProgramada, "PPP", { locale: ptBR })}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={novaParada.dataProgramada}
                            onSelect={(date) => {
                              if (date) {
                                setNovaParada({ ...novaParada, dataProgramada: date })
                              }
                            }}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="turno-responsavel">Turno Responsável*</Label>
                        <Select
                          value={novaParada.turnoResponsavel}
                          onValueChange={(value: "A" | "B" | "C" | "ADM") =>
                            setNovaParada({ ...novaParada, turnoResponsavel: value })
                          }
                        >
                          <SelectTrigger id="turno-responsavel">
                            <SelectValue placeholder="Selecione o turno" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="A">Turno A</SelectItem>
                            <SelectItem value="B">Turno B</SelectItem>
                            <SelectItem value="C">Turno C</SelectItem>
                            <SelectItem value="ADM">ADM</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="tempo-previsto">Tempo Previsto*</Label>
                        <Input
                          id="tempo-previsto"
                          value={novaParada.tempoPrevisto}
                          onChange={(e) => setNovaParada({ ...novaParada, tempoPrevisto: e.target.value })}
                          placeholder="Ex: 8 horas"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="responsavel-parada">Responsável*</Label>
                      <Input
                        id="responsavel-parada"
                        value={novaParada.responsavel}
                        onChange={(e) => setNovaParada({ ...novaParada, responsavel: e.target.value })}
                        placeholder="Nome do responsável"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="terceirizado"
                        checked={novaParada.terceirizado}
                        onCheckedChange={(checked) =>
                          setNovaParada({ ...novaParada, terceirizado: checked as boolean })
                        }
                      />
                      <label
                        htmlFor="terceirizado"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Necessário apoio de terceiro
                      </label>
                    </div>
                    {novaParada.terceirizado && (
                      <>
                        <div>
                          <Label htmlFor="terceirizado-nome">Nome do Terceiro</Label>
                          <Input
                            id="terceirizado-nome"
                            value={novaParada.terceirizadoNome || ""}
                            onChange={(e) => setNovaParada({ ...novaParada, terceirizadoNome: e.target.value })}
                            placeholder="Nome da empresa terceirizada"
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="liberacao-sst"
                            checked={novaParada.terceirizadoLiberacaoSST}
                            onCheckedChange={(checked) =>
                              setNovaParada({ ...novaParada, terceirizadoLiberacaoSST: checked as boolean })
                            }
                          />
                          <label
                            htmlFor="liberacao-sst"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            Liberação da SST
                          </label>
                        </div>
                      </>
                    )}
                    <div>
                      <Label htmlFor="comentarios">Comentários do Líder/Encarregado</Label>
                      <Textarea
                        id="comentarios"
                        value={novaParada.comentarios || ""}
                        onChange={(e) => setNovaParada({ ...novaParada, comentarios: e.target.value })}
                        placeholder="Sugestões de melhoria e dificuldades encontradas na atividade"
                        rows={3}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setDialogNovaParadaAberto(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={adicionarParada}>Programar Parada</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {paradasProgramadas.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">Nenhuma parada programada registrada.</div>
                ) : (
                  <div className="space-y-4">
                    {paradasProgramadas
                      .filter((parada) => parada.status !== "concluida" && parada.status !== "cancelada")
                      .map((parada) => (
                        <Card key={parada.id} className="overflow-hidden">
                          <div
                            className={`h-2 ${
                              parada.status === "programada"
                                ? "bg-blue-500"
                                : parada.status === "em_andamento"
                                  ? "bg-yellow-500"
                                  : parada.status === "concluida"
                                    ? "bg-green-500"
                                    : "bg-red-500"
                            }`}
                          />
                          <CardContent className="p-6">
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="text-lg font-medium">{parada.processo}</h3>
                                <p className="text-sm text-muted-foreground">{parada.descricao}</p>
                                <div className="mt-2 space-y-1">
                                  <p className="text-sm">
                                    <span className="font-medium">Data Programada:</span>{" "}
                                    {formatDate(parada.dataProgramada)}
                                  </p>
                                  <p className="text-sm">
                                    <span className="font-medium">Turno Responsável:</span> Turno{" "}
                                    {parada.turnoResponsavel}
                                  </p>
                                  <p className="text-sm">
                                    <span className="font-medium">Responsável:</span> {parada.responsavel}
                                  </p>
                                  <p className="text-sm">
                                    <span className="font-medium">Tempo Previsto:</span> {parada.tempoPrevisto}
                                  </p>
                                  {parada.terceirizado && (
                                    <>
                                      <p className="text-sm">
                                        <span className="font-medium">Terceirizado:</span>{" "}
                                        {parada.terceirizadoNome || "Não informado"}
                                      </p>
                                      <p className="text-sm">
                                        <span className="font-medium">Liberação SST:</span>{" "}
                                        {parada.terceirizadoLiberacaoSST ? "Sim" : "Não"}
                                      </p>
                                    </>
                                  )}
                                  {parada.dataInicio && (
                                    <p className="text-sm">
                                      <span className="font-medium">Início:</span>{" "}
                                      {formatDate(parada.dataInicio, "dd/MM/yyyy HH:mm")}
                                    </p>
                                  )}
                                  {parada.dataFim && (
                                    <p className="text-sm">
                                      <span className="font-medium">Término:</span>{" "}
                                      {formatDate(parada.dataFim, "dd/MM/yyyy HH:mm")}
                                    </p>
                                  )}
                                  {parada.tempoRealizado && (
                                    <p className="text-sm">
                                      <span className="font-medium">Tempo Realizado:</span> {parada.tempoRealizado}
                                    </p>
                                  )}
                                  {parada.comentarios && (
                                    <div className="mt-2 p-2 bg-muted rounded-md">
                                      <p className="text-sm font-medium">Comentários do Líder/Encarregado:</p>
                                      <p className="text-sm">{parada.comentarios}</p>
                                    </div>
                                  )}
                                </div>
                              </div>
                              <div className="flex flex-col items-end gap-2">
                                <div className={`px-3 py-1 rounded-full text-xs ${getStatusColor(parada.status)}`}>
                                  {getStatusText(parada.status)}
                                </div>
                                <div className="flex gap-2 mt-2">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setParadaSelecionada(parada)
                                      setDialogNovaAtividadeAberto(true)
                                    }}
                                  >
                                    <Plus className="h-4 w-4 mr-1" />
                                    Atividade
                                  </Button>
                                  <Select
                                    value={parada.status}
                                    onValueChange={(value: "programada" | "em_andamento" | "concluida" | "cancelada") =>
                                      atualizarStatusParada(parada.id, value)
                                    }
                                  >
                                    <SelectTrigger className="h-8 w-[130px]">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="programada">Programada</SelectItem>
                                      <SelectItem value="em_andamento">Em Andamento</SelectItem>
                                      <SelectItem value="concluida">Concluída</SelectItem>
                                      <SelectItem value="cancelada">Cancelada</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                            </div>

                            {parada.atividades.length > 0 && (
                              <div className="mt-4 border-t pt-4">
                                <h4 className="text-sm font-medium mb-2">Atividades</h4>

                                {/* Atividades Pré-Parada */}
                                {parada.atividades.filter((a) => a.tipo === "pre_parada").length > 0 && (
                                  <div className="mb-3">
                                    <h5 className="text-xs font-medium uppercase text-blue-600 dark:text-blue-400 mb-1">
                                      Antes da Parada
                                    </h5>
                                    <div className="space-y-2">
                                      {parada.atividades
                                        .filter((a) => a.tipo === "pre_parada")
                                        .map((atividade) => (
                                          <div
                                            key={atividade.id}
                                            className={`border rounded-md p-3 ${
                                              atividade.status === "concluida"
                                                ? "bg-green-50 dark:bg-green-900/10 border-green-200"
                                                : atividade.status === "em_andamento"
                                                  ? "bg-yellow-50 dark:bg-yellow-900/10 border-yellow-200"
                                                  : atividade.status === "cancelada"
                                                    ? "bg-red-50 dark:bg-red-900/10 border-red-200"
                                                    : ""
                                            }`}
                                          >
                                            <div className="flex justify-between items-start">
                                              <div>
                                                <div className="flex items-center gap-2">
                                                  <span
                                                    className={`px-2 py-1 rounded-full text-xs ${getStatusColor(atividade.status)}`}
                                                  >
                                                    {getStatusText(atividade.status)}
                                                  </span>
                                                </div>
                                                <p className="font-medium mt-1">{atividade.descricao}</p>
                                                <div className="text-sm text-muted-foreground mt-1">
                                                  <span>
                                                    Responsável: {atividade.responsavel} (Turno {atividade.turno})
                                                  </span>
                                                  <span className="mx-2">•</span>
                                                  <span>
                                                    Previsto: {formatDate(atividade.dataHoraPrevista, "dd/MM HH:mm")}
                                                  </span>
                                                </div>
                                                {atividade.observacoes && (
                                                  <p className="text-sm mt-1">{atividade.observacoes}</p>
                                                )}
                                                {atividade.dataHoraInicio && (
                                                  <p className="text-xs mt-1">
                                                    <span className="font-medium">Início:</span>{" "}
                                                    {formatDate(atividade.dataHoraInicio, "dd/MM/yyyy HH:mm")}
                                                  </p>
                                                )}
                                                {atividade.dataHoraFim && (
                                                  <p className="text-xs mt-1">
                                                    <span className="font-medium">Término:</span>{" "}
                                                    {formatDate(atividade.dataHoraFim, "dd/MM/yyyy HH:mm")}
                                                  </p>
                                                )}
                                              </div>
                                              <Select
                                                value={atividade.status}
                                                onValueChange={(
                                                  value: "pendente" | "em_andamento" | "concluida" | "cancelada",
                                                ) => atualizarStatusAtividade(parada.id, atividade.id, value)}
                                              >
                                                <SelectTrigger className="h-8 w-[130px]">
                                                  <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                  <SelectItem value="pendente">Pendente</SelectItem>
                                                  <SelectItem value="em_andamento">Em Andamento</SelectItem>
                                                  <SelectItem value="concluida">Concluída</SelectItem>
                                                  <SelectItem value="cancelada">Cancelada</SelectItem>
                                                </SelectContent>
                                              </Select>
                                            </div>
                                          </div>
                                        ))}
                                    </div>
                                  </div>
                                )}

                                {/* Atividades Durante Parada */}
                                {parada.atividades.filter((a) => a.tipo === "durante_parada").length > 0 && (
                                  <div className="mb-3">
                                    <h5 className="text-xs font-medium uppercase text-purple-600 dark:text-purple-400 mb-1">
                                      Durante a Parada
                                    </h5>
                                    <div className="space-y-2">
                                      {parada.atividades
                                        .filter((a) => a.tipo === "durante_parada")
                                        .map((atividade) => (
                                          <div
                                            key={atividade.id}
                                            className={`border rounded-md p-3 ${
                                              atividade.status === "concluida"
                                                ? "bg-green-50 dark:bg-green-900/10 border-green-200"
                                                : atividade.status === "em_andamento"
                                                  ? "bg-yellow-50 dark:bg-yellow-900/10 border-yellow-200"
                                                  : atividade.status === "cancelada"
                                                    ? "bg-red-50 dark:bg-red-900/10 border-red-200"
                                                    : ""
                                            }`}
                                          >
                                            <div className="flex justify-between items-start">
                                              <div>
                                                <div className="flex items-center gap-2">
                                                  <span
                                                    className={`px-2 py-1 rounded-full text-xs ${getStatusColor(atividade.status)}`}
                                                  >
                                                    {getStatusText(atividade.status)}
                                                  </span>
                                                </div>
                                                <p className="font-medium mt-1">{atividade.descricao}</p>
                                                <div className="text-sm text-muted-foreground mt-1">
                                                  <span>
                                                    Responsável: {atividade.responsavel} (Turno {atividade.turno})
                                                  </span>
                                                  <span className="mx-2">•</span>
                                                  <span>
                                                    Previsto: {formatDate(atividade.dataHoraPrevista, "dd/MM HH:mm")}
                                                  </span>
                                                </div>
                                                {atividade.observacoes && (
                                                  <p className="text-sm mt-1">{atividade.observacoes}</p>
                                                )}
                                                {atividade.dataHoraInicio && (
                                                  <p className="text-xs mt-1">
                                                    <span className="font-medium">Início:</span>{" "}
                                                    {formatDate(atividade.dataHoraInicio, "dd/MM/yyyy HH:mm")}
                                                  </p>
                                                )}
                                                {atividade.dataHoraFim && (
                                                  <p className="text-xs mt-1">
                                                    <span className="font-medium">Término:</span>{" "}
                                                    {formatDate(atividade.dataHoraFim, "dd/MM/yyyy HH:mm")}
                                                  </p>
                                                )}
                                              </div>
                                              <Select
                                                value={atividade.status}
                                                onValueChange={(
                                                  value: "pendente" | "em_andamento" | "concluida" | "cancelada",
                                                ) => atualizarStatusAtividade(parada.id, atividade.id, value)}
                                              >
                                                <SelectTrigger className="h-8 w-[130px]">
                                                  <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                  <SelectItem value="pendente">Pendente</SelectItem>
                                                  <SelectItem value="em_andamento">Em Andamento</SelectItem>
                                                  <SelectItem value="concluida">Concluída</SelectItem>
                                                  <SelectItem value="cancelada">Cancelada</SelectItem>
                                                </SelectContent>
                                              </Select>
                                            </div>
                                          </div>
                                        ))}
                                    </div>
                                  </div>
                                )}

                                {/* Atividades Pós-Parada */}
                                {parada.atividades.filter((a) => a.tipo === "pos_parada").length > 0 && (
                                  <div>
                                    <h5 className="text-xs font-medium uppercase text-orange-600 dark:text-orange-400 mb-1">
                                      Após a Parada
                                    </h5>
                                    <div className="space-y-2">
                                      {parada.atividades
                                        .filter((a) => a.tipo === "pos_parada")
                                        .map((atividade) => (
                                          <div
                                            key={atividade.id}
                                            className={`border rounded-md p-3 ${
                                              atividade.status === "concluida"
                                                ? "bg-green-50 dark:bg-green-900/10 border-green-200"
                                                : atividade.status === "em_andamento"
                                                  ? "bg-yellow-50 dark:bg-yellow-900/10 border-yellow-200"
                                                  : atividade.status === "cancelada"
                                                    ? "bg-red-50 dark:bg-red-900/10 border-red-200"
                                                    : ""
                                            }`}
                                          >
                                            <div className="flex justify-between items-start">
                                              <div>
                                                <div className="flex items-center gap-2">
                                                  <span
                                                    className={`px-2 py-1 rounded-full text-xs ${getStatusColor(atividade.status)}`}
                                                  >
                                                    {getStatusText(atividade.status)}
                                                  </span>
                                                </div>
                                                <p className="font-medium mt-1">{atividade.descricao}</p>
                                                <div className="text-sm text-muted-foreground mt-1">
                                                  <span>
                                                    Responsável: {atividade.responsavel} (Turno {atividade.turno})
                                                  </span>
                                                  <span className="mx-2">•</span>
                                                  <span>
                                                    Previsto: {formatDate(atividade.dataHoraPrevista, "dd/MM HH:mm")}
                                                  </span>
                                                </div>
                                                {atividade.observacoes && (
                                                  <p className="text-sm mt-1">{atividade.observacoes}</p>
                                                )}
                                                {atividade.dataHoraInicio && (
                                                  <p className="text-xs mt-1">
                                                    <span className="font-medium">Início:</span>{" "}
                                                    {formatDate(atividade.dataHoraInicio, "dd/MM/yyyy HH:mm")}
                                                  </p>
                                                )}
                                                {atividade.dataHoraFim && (
                                                  <p className="text-xs mt-1">
                                                    <span className="font-medium">Término:</span>{" "}
                                                    {formatDate(atividade.dataHoraFim, "dd/MM/yyyy HH:mm")}
                                                  </p>
                                                )}
                                              </div>
                                              <Select
                                                value={atividade.status}
                                                onValueChange={(
                                                  value: "pendente" | "em_andamento" | "concluida" | "cancelada",
                                                ) => atualizarStatusAtividade(parada.id, atividade.id, value)}
                                              >
                                                <SelectTrigger className="h-8 w-[130px]">
                                                  <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                  <SelectItem value="pendente">Pendente</SelectItem>
                                                  <SelectItem value="em_andamento">Em Andamento</SelectItem>
                                                  <SelectItem value="concluida">Concluída</SelectItem>
                                                  <SelectItem value="cancelada">Cancelada</SelectItem>
                                                </SelectContent>
                                              </Select>
                                            </div>
                                          </div>
                                        ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="historico" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Paradas</CardTitle>
              <CardDescription>Paradas concluídas ou canceladas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {paradasProgramadas.filter((parada) => parada.status === "concluida" || parada.status === "cancelada")
                  .length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">Nenhuma parada concluída ou cancelada.</div>
                ) : (
                  <div className="space-y-4">
                    {paradasProgramadas
                      .filter((parada) => parada.status === "concluida" || parada.status === "cancelada")
                      .map((parada) => (
                        <Card key={parada.id} className="overflow-hidden">
                          <div className={`h-2 ${parada.status === "concluida" ? "bg-green-500" : "bg-red-500"}`} />
                          <CardContent className="p-6">
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="text-lg font-medium">{parada.processo}</h3>
                                <p className="text-sm text-muted-foreground">{parada.descricao}</p>
                                <div className="mt-2 space-y-1">
                                  <p className="text-sm">
                                    <span className="font-medium">Data Programada:</span>{" "}
                                    {formatDate(parada.dataProgramada)}
                                  </p>
                                  {parada.dataInicio && (
                                    <p className="text-sm">
                                      <span className="font-medium">Início:</span>{" "}
                                      {formatDate(parada.dataInicio, "dd/MM/yyyy HH:mm")}
                                    </p>
                                  )}
                                  {parada.dataFim && (
                                    <p className="text-sm">
                                      <span className="font-medium">Término:</span>{" "}
                                      {formatDate(parada.dataFim, "dd/MM/yyyy HH:mm")}
                                    </p>
                                  )}
                                  <p className="text-sm">
                                    <span className="font-medium">Tempo Previsto:</span> {parada.tempoPrevisto}
                                  </p>
                                  {parada.tempoRealizado && (
                                    <p className="text-sm">
                                      <span className="font-medium">Tempo Realizado:</span> {parada.tempoRealizado}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div className={`px-3 py-1 rounded-full text-xs ${getStatusColor(parada.status)}`}>
                                {getStatusText(parada.status)}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialog para adicionar nova atividade */}
      <Dialog open={dialogNovaAtividadeAberto} onOpenChange={setDialogNovaAtividadeAberto}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar Nova Atividade</DialogTitle>
            <DialogDescription>Adicione uma nova atividade para a parada programada.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <Label htmlFor="tipo-atividade">Tipo de Atividade*</Label>
              <Select
                value={novaAtividade.tipo}
                onValueChange={(value: "pre_parada" | "durante_parada" | "pos_parada") =>
                  setNovaAtividade({ ...novaAtividade, tipo: value })
                }
              >
                <SelectTrigger id="tipo-atividade">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pre_parada">Pré-Parada</SelectItem>
                  <SelectItem value="durante_parada">Durante Parada</SelectItem>
                  <SelectItem value="pos_parada">Pós-Parada</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="descricao-atividade">Descrição*</Label>
              <Textarea
                id="descricao-atividade"
                value={novaAtividade.descricao}
                onChange={(e) => setNovaAtividade({ ...novaAtividade, descricao: e.target.value })}
                placeholder="Descreva a atividade a ser realizada"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="responsavel-atividade">Responsável*</Label>
                <Input
                  id="responsavel-atividade"
                  value={novaAtividade.responsavel}
                  onChange={(e) => setNovaAtividade({ ...novaAtividade, responsavel: e.target.value })}
                  placeholder="Nome do responsável"
                />
              </div>
              <div>
                <Label htmlFor="turno-atividade">Turno*</Label>
                <Select
                  value={novaAtividade.turno}
                  onValueChange={(value: "A" | "B" | "C" | "ADM") =>
                    setNovaAtividade({ ...novaAtividade, turno: value })
                  }
                >
                  <SelectTrigger id="turno-atividade">
                    <SelectValue placeholder="Selecione o turno" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">Turno A</SelectItem>
                    <SelectItem value="B">Turno B</SelectItem>
                    <SelectItem value="C">Turno C</SelectItem>
                    <SelectItem value="ADM">ADM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="data-hora-prevista">Data/Hora Prevista*</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(novaAtividade.dataHoraPrevista, "PPP HH:mm", { locale: ptBR })}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={novaAtividade.dataHoraPrevista}
                    onSelect={(date) => {
                      if (date) {
                        setNovaAtividade({ ...novaAtividade, dataHoraPrevista: date })
                      }
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div>
              <Label htmlFor="observacoes-atividade">Observações</Label>
              <Textarea
                id="observacoes-atividade"
                value={novaAtividade.observacoes || ""}
                onChange={(e) => setNovaAtividade({ ...novaAtividade, observacoes: e.target.value })}
                placeholder="Observações adicionais sobre a atividade"
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogNovaAtividadeAberto(false)}>
              Cancelar
            </Button>
            <Button onClick={adicionarAtividade}>Adicionar Atividade</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
