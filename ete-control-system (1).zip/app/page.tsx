import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Activity, Beaker, Database, Droplet, FileText, Gauge, LayoutDashboard } from "lucide-react"

export default function Home() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">CONTROLE OPERAÇÕES FLUCOR</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Link href="/painel-principal">
          <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Painel Principal
              </CardTitle>
              <CardDescription>Ordens de processos e atividades do dia</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Visualize e gerencie as ordens de processos, atividades operacionais e ocorrências.</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/controle-tanques">
          <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Controle Físico dos Tanques
              </CardTitle>
              <CardDescription>Monitoramento de volumes por turno</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Controle os volumes dos tanques por turno e visualize as movimentações diárias.</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/controle-estoque">
          <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Beaker className="h-5 w-5" />
                Controle de Estoque
              </CardTitle>
              <CardDescription>Gestão de insumos químicos</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Monitore o estoque de insumos químicos e gere relatórios para compras.</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/leituras-equipamentos">
          <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gauge className="h-5 w-5" />
                Leituras de Equipamentos
              </CardTitle>
              <CardDescription>Medições de hidrômetro e vazão</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Registre as leituras do hidrômetro e acompanhe a vazão média diária.</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/cadastro-tanques">
          <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Droplet className="h-5 w-5" />
                Cadastro de Tanques
              </CardTitle>
              <CardDescription>Gerenciamento de tanques por processo</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Cadastre novos tanques e gerencie os existentes por processo.</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/dashboard-visual">
          <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LayoutDashboard className="h-5 w-5" />
                Dashboard Visual
              </CardTitle>
              <CardDescription>Visualização gráfica da planta</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Visualize a planta com ícones de tanques, status operacional e próximas atividades.</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/relatorios">
          <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Relatórios
              </CardTitle>
              <CardDescription>Relatórios diários e históricos</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Gere relatórios de movimentações, estoque e leituras para análise e controle.</p>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  )
}
