"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import { Calendar } from "@/components/ui/calendar"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Beaker, CalendarIcon, Download, FileText, Plus, X } from "lucide-react"

type AmostraColetada = {
  id: string
  local: string
  tipo: string
  dataColeta: Date
  responsavel: string
  parametros: string[]
  observacoes: string
  status: "pendente" | "em_analise" | "concluida"
  resultados?: Record<string, string>
}

type AnaliseQualidade = {
  id: string
  amostraId: string
  parametro: string
  resultado: string
  unidade: string
  limiteMinimo?: string
  limiteMaximo?: string
  dataAnalise: Date
  responsavel: string
  conformidade: "conforme" | "nao_conforme" | "nao_aplicavel"
}

export default function Laboratorio() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("coletas")
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [dialogNovaAmostraAberto, setDialogNovaAmostraAberto] = useState(false)
  const [dialogNovaAnaliseAberto, setDialogNovaAnaliseAberto] = useState(false)
  const [amostraSelecionada, setAmostraSelecionada] = useState<AmostraColetada | null>(null)

  const [novaAmostra, setNovaAmostra] = useState<Omit<AmostraColetada, "id" | "status" | "resultados">>({
    local: "",
    tipo: "",
    dataColeta: new Date(),
    responsavel: "",
    parametros: [],
    observacoes: "",
  })

  const [novaAnalise, setNovaAnalise] = useState<Omit<AnaliseQualidade, "id">>({
    amostraId: "",
    parametro: "",
    resultado: "",
    unidade: "",
    limiteMinimo: "",
    limiteMaximo: "",
    dataAnalise: new Date(),
    responsavel: "",
    conformidade: "conforme",
  })

  // Estado para amostras coletadas
  const [amostrasColetadas, setAmostrasColetadas] = useState<AmostraColetada[]>([
    {
      id: "1",
      local: "Tanque de Equalização",
      tipo: "Efluente Bruto",
      dataColeta: new Date(new Date().setHours(new Date().getHours() - 3)),
      responsavel: "Ana Silva",
      parametros: ["pH", "DQO", "DBO", "Sólidos Suspensos"],
      observacoes: "Amostra coletada conforme procedimento padrão",
      status: "concluida",
      resultados: {
        pH: "6.8",
        DQO: "450 mg/L",
        DBO: "200 mg/L",
        "Sólidos Suspensos": "180 mg/L",
      },
    },
    {
      id: "2",
      local: "Saída do Tratamento Biológico",
      tipo: "Efluente Tratado",
      dataColeta: new Date(new Date().setHours(new Date().getHours() - 5)),
      responsavel: "Carlos Santos",
      parametros: ["pH", "DQO", "DBO", "Nitrogênio Total", "Fósforo Total"],
      observacoes: "Amostra para controle de processo",
      status: "em_analise",
    },
    {
      id: "3",
      local: "Tanque de Aeração",
      tipo: "Lodo Ativado",
      dataColeta: new Date(new Date().setHours(new Date().getHours() - 8)),
      responsavel: "Ana Silva",
      parametros: ["SST", "SSV", "IVL"],
      observacoes: "Verificação da concentração de biomassa",
      status: "pendente",
    },
  ])

  // Estado para análises de qualidade
  const [analisesQualidade, setAnalisesQualidade] = useState<AnaliseQualidade[]>([
    {
      id: "1",
      amostraId: "1",
      parametro: "pH",
      resultado: "6.8",
      unidade: "pH",
      limiteMinimo: "6.0",
      limiteMaximo: "9.0",
      dataAnalise: new Date(new Date().setHours(new Date().getHours() - 2)),
      responsavel: "Ana Silva",
      conformidade: "conforme",
    },
    {
      id: "2",
      amostraId: "1",
      parametro: "DQO",
      resultado: "450",
      unidade: "mg/L",
      limiteMaximo: "800",
      dataAnalise: new Date(new Date().setHours(new Date().getHours() - 2)),
      responsavel: "Ana Silva",
      conformidade: "conforme",
    },
    {
      id: "3",
      amostraId: "1",
      parametro: "DBO",
      resultado: "200",
      unidade: "mg/L",
      limiteMaximo: "400",
      dataAnalise: new Date(new Date().setHours(new Date().getHours() - 2)),
      responsavel: "Ana Silva",
      conformidade: "conforme",
    },
    {
      id: "4",
      amostraId: "1",
      parametro: "Sólidos Suspensos",
      resultado: "180",
      unidade: "mg/L",
      limiteMaximo: "300",
      dataAnalise: new Date(new Date().setHours(new Date().getHours() - 2)),
      responsavel: "Ana Silva",
      conformidade: "conforme",
    },
  ])

  // Lista de parâmetros disponíveis
  const parametrosDisponiveis = [
    "pH",
    "DQO",
    "DBO",
    "Sólidos Suspensos",
    "Sólidos Sedimentáveis",
    "Nitrogênio Total",
    "Nitrogênio Amoniacal",
    "Fósforo Total",
    "Óleos e Graxas",
    "Temperatura",
    "Condutividade",
    "Turbidez",
    "Cor",
    "Oxigênio Dissolvido",
    "SST",
    "SSV",
    "IVL",
  ]

  // Função para adicionar nova amostra
  const adicionarAmostra = () => {
    if (!novaAmostra.local || !novaAmostra.tipo || novaAmostra.parametros.length === 0) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (amostrasColetadas.length + 1).toString()
    const amostraCompleta: AmostraColetada = {
      id: novoId,
      ...novaAmostra,
      status: "pendente",
    }

    setAmostrasColetadas([...amostrasColetadas, amostraCompleta])
    setNovaAmostra({
      local: "",
      tipo: "",
      dataColeta: new Date(),
      responsavel: "",
      parametros: [],
      observacoes: "",
    })
    setDialogNovaAmostraAberto(false)

    toast({
      title: "Amostra registrada",
      description: "A nova amostra foi registrada com sucesso.",
    })
  }

  // Função para adicionar nova análise
  const adicionarAnalise = () => {
    if (!novaAnalise.amostraId || !novaAnalise.parametro || !novaAnalise.resultado || !novaAnalise.unidade) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (analisesQualidade.length + 1).toString()
    const analiseCompleta: AnaliseQualidade = {
      id: novoId,
      ...novaAnalise,
    }

    setAnalisesQualidade([...analisesQualidade, analiseCompleta])

    // Atualizar o status da amostra para em_analise ou concluida
    const amostra = amostrasColetadas.find((a) => a.id === novaAnalise.amostraId)
    if (amostra) {
      // Verificar se todos os parâmetros foram analisados
      const parametrosAnalisados = [
        ...analisesQualidade.filter((a) => a.amostraId === novaAnalise.amostraId).map((a) => a.parametro),
        novaAnalise.parametro,
      ]

      const todosParametrosAnalisados = amostra.parametros.every((p) => parametrosAnalisados.includes(p))

      const novoStatus = todosParametrosAnalisados ? "concluida" : "em_analise"

      // Atualizar resultados da amostra
      const novosResultados = {
        ...(amostra.resultados || {}),
        [novaAnalise.parametro]: `${novaAnalise.resultado} ${novaAnalise.unidade}`,
      }

      setAmostrasColetadas(
        amostrasColetadas.map((a) =>
          a.id === novaAnalise.amostraId ? { ...a, status: novoStatus, resultados: novosResultados } : a,
        ),
      )
    }

    setNovaAnalise({
      amostraId: "",
      parametro: "",
      resultado: "",
      unidade: "",
      limiteMinimo: "",
      limiteMaximo: "",
      dataAnalise: new Date(),
      responsavel: "",
      conformidade: "conforme",
    })
    setDialogNovaAnaliseAberto(false)

    toast({
      title: "Análise registrada",
      description: "A nova análise foi registrada com sucesso.",
    })
  }

  // Função para atualizar status da amostra
  const atualizarStatusAmostra = (id: string, novoStatus: "pendente" | "em_analise" | "concluida") => {
    setAmostrasColetadas(
      amostrasColetadas.map((amostra) => (amostra.id === id ? { ...amostra, status: novoStatus } : amostra)),
    )

    toast({
      title: "Status atualizado",
      description: "O status da amostra foi atualizado com sucesso.",
    })
  }

  // Função para gerar relatório
  const gerarRelatorio = () => {
    toast({
      title: "Relatório gerado",
      description: "O relatório de análises foi gerado e está disponível para download.",
    })
  }

  // Função para obter a cor do status
  const getStatusColor = (status: string) => {
    switch (status) {
      case "pendente":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
      case "em_analise":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
      case "concluida":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "conforme":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "nao_conforme":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      case "nao_aplicavel":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  // Função para obter o texto do status
  const getStatusText = (status: string) => {
    switch (status) {
      case "pendente":
        return "Pendente"
      case "em_analise":
        return "Em Análise"
      case "concluida":
        return "Concluída"
      case "conforme":
        return "Conforme"
      case "nao_conforme":
        return "Não Conforme"
      case "nao_aplicavel":
        return "Não Aplicável"
      default:
        return "Não definido"
    }
  }

  // Função para verificar se um parâmetro já foi analisado
  const isParametroAnalisado = (amostraId: string, parametro: string) => {
    return analisesQualidade.some((a) => a.amostraId === amostraId && a.parametro === parametro)
  }

  // Função para obter análises de uma amostra
  const getAnalisesDaAmostra = (amostraId: string) => {
    return analisesQualidade.filter((a) => a.amostraId === amostraId)
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Laboratório</h1>

      <Tabs defaultValue="coletas" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="coletas">Coletas de Amostras</TabsTrigger>
          <TabsTrigger value="analises">Análises de Qualidade</TabsTrigger>
          <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
        </TabsList>

        <TabsContent value="coletas" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Coletas de Amostras</CardTitle>
                <CardDescription>Registro e acompanhamento de amostras coletadas</CardDescription>
              </div>
              <Dialog open={dialogNovaAmostraAberto} onOpenChange={setDialogNovaAmostraAberto}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Nova Amostra
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Registrar Nova Amostra</DialogTitle>
                    <DialogDescription>Preencha as informações da amostra coletada.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="local-amostra">Local da Coleta*</Label>
                        <Input
                          id="local-amostra"
                          value={novaAmostra.local}
                          onChange={(e) => setNovaAmostra({ ...novaAmostra, local: e.target.value })}
                          placeholder="Ex: Tanque de Equalização"
                        />
                      </div>
                      <div>
                        <Label htmlFor="tipo-amostra">Tipo de Amostra*</Label>
                        <Select
                          value={novaAmostra.tipo}
                          onValueChange={(value) => setNovaAmostra({ ...novaAmostra, tipo: value })}
                        >
                          <SelectTrigger id="tipo-amostra">
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Efluente Bruto">Efluente Bruto</SelectItem>
                            <SelectItem value="Efluente Tratado">Efluente Tratado</SelectItem>
                            <SelectItem value="Lodo Ativado">Lodo Ativado</SelectItem>
                            <SelectItem value="Água de Reúso">Água de Reúso</SelectItem>
                            <SelectItem value="Água Potável">Água Potável</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="data-coleta">Data e Hora da Coleta*</Label>
                      <Input
                        id="data-coleta"
                        type="datetime-local"
                        value={format(novaAmostra.dataColeta, "yyyy-MM-dd'T'HH:mm")}
                        onChange={(e) => {
                          const date = e.target.value ? new Date(e.target.value) : new Date()
                          setNovaAmostra({ ...novaAmostra, dataColeta: date })
                        }}
                      />
                    </div>
                    <div>
                      <Label htmlFor="responsavel-coleta">Responsável pela Coleta*</Label>
                      <Input
                        id="responsavel-coleta"
                        value={novaAmostra.responsavel}
                        onChange={(e) => setNovaAmostra({ ...novaAmostra, responsavel: e.target.value })}
                        placeholder="Nome do responsável"
                      />
                    </div>
                    <div>
                      <Label htmlFor="parametros-amostra">Parâmetros a Analisar*</Label>
                      <Select
                        value={novaAmostra.parametros.length > 0 ? novaAmostra.parametros[0] : ""}
                        onValueChange={(value) => {
                          if (!novaAmostra.parametros.includes(value)) {
                            setNovaAmostra({
                              ...novaAmostra,
                              parametros: [...novaAmostra.parametros, value],
                            })
                          }
                        }}
                      >
                        <SelectTrigger id="parametros-amostra">
                          <SelectValue placeholder="Selecione os parâmetros" />
                        </SelectTrigger>
                        <SelectContent>
                          {parametrosDisponiveis.map((parametro) => (
                            <SelectItem
                              key={parametro}
                              value={parametro}
                              disabled={novaAmostra.parametros.includes(parametro)}
                            >
                              {parametro}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {novaAmostra.parametros.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {novaAmostra.parametros.map((parametro) => (
                            <div
                              key={parametro}
                              className="bg-muted px-2 py-1 rounded-md text-sm flex items-center gap-1"
                            >
                              {parametro}
                              <button
                                type="button"
                                className="text-muted-foreground hover:text-foreground"
                                onClick={() => {
                                  setNovaAmostra({
                                    ...novaAmostra,
                                    parametros: novaAmostra.parametros.filter((p) => p !== parametro),
                                  })
                                }}
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="observacoes-amostra">Observações</Label>
                      <Textarea
                        id="observacoes-amostra"
                        value={novaAmostra.observacoes}
                        onChange={(e) => setNovaAmostra({ ...novaAmostra, observacoes: e.target.value })}
                        placeholder="Observações sobre a coleta"
                        rows={3}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setDialogNovaAmostraAberto(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={adicionarAmostra}>Registrar Amostra</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {amostrasColetadas.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">Nenhuma amostra registrada.</div>
                ) : (
                  <div className="space-y-4">
                    {amostrasColetadas.map((amostra) => (
                      <Card key={amostra.id} className="overflow-hidden">
                        <div
                          className={`h-2 ${
                            amostra.status === "pendente"
                              ? "bg-yellow-500"
                              : amostra.status === "em_analise"
                                ? "bg-blue-500"
                                : "bg-green-500"
                          }`}
                        />
                        <CardContent className="p-6">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-lg font-medium">{amostra.local}</h3>
                              <p className="text-sm text-muted-foreground">{amostra.tipo}</p>
                              <div className="mt-2 space-y-1">
                                <p className="text-sm">
                                  <span className="font-medium">Data da Coleta:</span>{" "}
                                  {format(new Date(amostra.dataColeta), "dd/MM/yyyy HH:mm")}
                                </p>
                                <p className="text-sm">
                                  <span className="font-medium">Responsável:</span> {amostra.responsavel}
                                </p>
                                <div className="mt-2">
                                  <span className="text-sm font-medium">Parâmetros:</span>
                                  <div className="flex flex-wrap gap-2 mt-1">
                                    {amostra.parametros.map((parametro) => (
                                      <div
                                        key={parametro}
                                        className={`px-2 py-1 rounded-md text-xs ${
                                          isParametroAnalisado(amostra.id, parametro)
                                            ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
                                            : "bg-muted text-muted-foreground"
                                        }`}
                                      >
                                        {parametro}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                                {amostra.observacoes && (
                                  <p className="text-sm mt-2">
                                    <span className="font-medium">Observações:</span> {amostra.observacoes}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="flex flex-col items-end gap-2">
                              <div className={`px-3 py-1 rounded-full text-xs ${getStatusColor(amostra.status)}`}>
                                {getStatusText(amostra.status)}
                              </div>
                              <div className="flex gap-2 mt-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setAmostraSelecionada(amostra)
                                    setNovaAnalise({
                                      ...novaAnalise,
                                      amostraId: amostra.id,
                                    })
                                    setDialogNovaAnaliseAberto(true)
                                  }}
                                  disabled={amostra.status === "concluida"}
                                >
                                  <Beaker className="h-4 w-4 mr-1" />
                                  Registrar Análise
                                </Button>
                                <Select
                                  value={amostra.status}
                                  onValueChange={(value: "pendente" | "em_analise" | "concluida") =>
                                    atualizarStatusAmostra(amostra.id, value)
                                  }
                                >
                                  <SelectTrigger className="h-8 w-[130px]">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pendente">Pendente</SelectItem>
                                    <SelectItem value="em_analise">Em Análise</SelectItem>
                                    <SelectItem value="concluida">Concluída</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                          </div>

                          {amostra.status !== "pendente" && getAnalisesDaAmostra(amostra.id).length > 0 && (
                            <div className="mt-4 border-t pt-4">
                              <h4 className="text-sm font-medium mb-2">Resultados das Análises</h4>
                              <div className="overflow-x-auto">
                                <Table>
                                  <TableHeader>
                                    <TableRow>
                                      <TableHead>Parâmetro</TableHead>
                                      <TableHead>Resultado</TableHead>
                                      <TableHead>Limites</TableHead>
                                      <TableHead>Conformidade</TableHead>
                                      <TableHead>Data da Análise</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {getAnalisesDaAmostra(amostra.id).map((analise) => (
                                      <TableRow key={analise.id}>
                                        <TableCell>{analise.parametro}</TableCell>
                                        <TableCell>
                                          {analise.resultado} {analise.unidade}
                                        </TableCell>
                                        <TableCell>
                                          {analise.limiteMinimo && analise.limiteMaximo
                                            ? `${analise.limiteMinimo} - ${analise.limiteMaximo} ${analise.unidade}`
                                            : analise.limiteMinimo
                                              ? `Mín: ${analise.limiteMinimo} ${analise.unidade}`
                                              : analise.limiteMaximo
                                                ? `Máx: ${analise.limiteMaximo} ${analise.unidade}`
                                                : "N/A"}
                                        </TableCell>
                                        <TableCell>
                                          <span
                                            className={`px-2 py-1 rounded-full text-xs ${getStatusColor(analise.conformidade)}`}
                                          >
                                            {getStatusText(analise.conformidade)}
                                          </span>
                                        </TableCell>
                                        <TableCell>
                                          {format(new Date(analise.dataAnalise), "dd/MM/yyyy HH:mm")}
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analises" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Análises de Qualidade</CardTitle>
                <CardDescription>Registro e acompanhamento de análises laboratoriais</CardDescription>
              </div>
              <Dialog open={dialogNovaAnaliseAberto} onOpenChange={setDialogNovaAnaliseAberto}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Nova Análise
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Registrar Nova Análise</DialogTitle>
                    <DialogDescription>Preencha os resultados da análise laboratorial.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div>
                      <Label htmlFor="amostra-analise">Amostra*</Label>
                      <Select
                        value={novaAnalise.amostraId}
                        onValueChange={(value) => {
                          setNovaAnalise({ ...novaAnalise, amostraId: value })
                          setAmostraSelecionada(amostrasColetadas.find((a) => a.id === value) || null)
                        }}
                      >
                        <SelectTrigger id="amostra-analise">
                          <SelectValue placeholder="Selecione a amostra" />
                        </SelectTrigger>
                        <SelectContent>
                          {amostrasColetadas
                            .filter((a) => a.status !== "concluida")
                            .map((amostra) => (
                              <SelectItem key={amostra.id} value={amostra.id}>
                                {amostra.local} - {amostra.tipo} ({format(new Date(amostra.dataColeta), "dd/MM/yyyy")})
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {amostraSelecionada && (
                      <div>
                        <Label>Parâmetros Disponíveis</Label>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {amostraSelecionada.parametros.map((parametro) => (
                            <div
                              key={parametro}
                              className={`px-2 py-1 rounded-md text-xs cursor-pointer ${
                                isParametroAnalisado(amostraSelecionada.id, parametro)
                                  ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
                                  : novaAnalise.parametro === parametro
                                    ? "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
                                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                              }`}
                              onClick={() => {
                                if (!isParametroAnalisado(amostraSelecionada.id, parametro)) {
                                  setNovaAnalise({ ...novaAnalise, parametro })
                                }
                              }}
                            >
                              {parametro}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="resultado-analise">Resultado*</Label>
                        <Input
                          id="resultado-analise"
                          value={novaAnalise.resultado}
                          onChange={(e) => setNovaAnalise({ ...novaAnalise, resultado: e.target.value })}
                          placeholder="Ex: 7.2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="unidade-analise">Unidade*</Label>
                        <Input
                          id="unidade-analise"
                          value={novaAnalise.unidade}
                          onChange={(e) => setNovaAnalise({ ...novaAnalise, unidade: e.target.value })}
                          placeholder="Ex: mg/L"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="limite-minimo">Limite Mínimo</Label>
                        <Input
                          id="limite-minimo"
                          value={novaAnalise.limiteMinimo}
                          onChange={(e) => setNovaAnalise({ ...novaAnalise, limiteMinimo: e.target.value })}
                          placeholder="Ex: 6.0"
                        />
                      </div>
                      <div>
                        <Label htmlFor="limite-maximo">Limite Máximo</Label>
                        <Input
                          id="limite-maximo"
                          value={novaAnalise.limiteMaximo}
                          onChange={(e) => setNovaAnalise({ ...novaAnalise, limiteMaximo: e.target.value })}
                          placeholder="Ex: 9.0"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="data-analise">Data e Hora da Análise*</Label>
                      <Input
                        id="data-analise"
                        type="datetime-local"
                        value={format(novaAnalise.dataAnalise, "yyyy-MM-dd'T'HH:mm")}
                        onChange={(e) => {
                          const date = e.target.value ? new Date(e.target.value) : new Date()
                          setNovaAnalise({ ...novaAnalise, dataAnalise: date })
                        }}
                      />
                    </div>

                    <div>
                      <Label htmlFor="responsavel-analise">Responsável pela Análise*</Label>
                      <Input
                        id="responsavel-analise"
                        value={novaAnalise.responsavel}
                        onChange={(e) => setNovaAnalise({ ...novaAnalise, responsavel: e.target.value })}
                        placeholder="Nome do responsável"
                      />
                    </div>

                    <div>
                      <Label htmlFor="conformidade-analise">Conformidade*</Label>
                      <Select
                        value={novaAnalise.conformidade}
                        onValueChange={(value: "conforme" | "nao_conforme" | "nao_aplicavel") =>
                          setNovaAnalise({ ...novaAnalise, conformidade: value })
                        }
                      >
                        <SelectTrigger id="conformidade-analise">
                          <SelectValue placeholder="Selecione a conformidade" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="conforme">Conforme</SelectItem>
                          <SelectItem value="nao_conforme">Não Conforme</SelectItem>
                          <SelectItem value="nao_aplicavel">Não Aplicável</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setDialogNovaAnaliseAberto(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={adicionarAnalise}>Registrar Análise</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Amostra</TableHead>
                        <TableHead>Parâmetro</TableHead>
                        <TableHead>Resultado</TableHead>
                        <TableHead>Limites</TableHead>
                        <TableHead>Conformidade</TableHead>
                        <TableHead>Data da Análise</TableHead>
                        <TableHead>Responsável</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {analisesQualidade.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-4 text-muted-foreground">
                            Nenhuma análise registrada.
                          </TableCell>
                        </TableRow>
                      ) : (
                        analisesQualidade.map((analise) => {
                          const amostra = amostrasColetadas.find((a) => a.id === analise.amostraId)
                          return (
                            <TableRow key={analise.id}>
                              <TableCell>
                                {amostra ? (
                                  <div>
                                    <div className="font-medium">{amostra.local}</div>
                                    <div className="text-xs text-muted-foreground">{amostra.tipo}</div>
                                  </div>
                                ) : (
                                  "Amostra não encontrada"
                                )}
                              </TableCell>
                              <TableCell>{analise.parametro}</TableCell>
                              <TableCell>
                                {analise.resultado} {analise.unidade}
                              </TableCell>
                              <TableCell>
                                {analise.limiteMinimo && analise.limiteMaximo
                                  ? `${analise.limiteMinimo} - ${analise.limiteMaximo} ${analise.unidade}`
                                  : analise.limiteMinimo
                                    ? `Mín: ${analise.limiteMinimo} ${analise.unidade}`
                                    : analise.limiteMaximo
                                      ? `Máx: ${analise.limiteMaximo} ${analise.unidade}`
                                      : "N/A"}
                              </TableCell>
                              <TableCell>
                                <span
                                  className={`px-2 py-1 rounded-full text-xs ${getStatusColor(analise.conformidade)}`}
                                >
                                  {getStatusText(analise.conformidade)}
                                </span>
                              </TableCell>
                              <TableCell>{format(new Date(analise.dataAnalise), "dd/MM/yyyy HH:mm")}</TableCell>
                              <TableCell>{analise.responsavel}</TableCell>
                            </TableRow>
                          )
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="relatorios" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Relatórios</CardTitle>
              <CardDescription>Geração de relatórios de análises laboratoriais</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="data-inicio-relatorio">Data de Início</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {date ? format(date, "PPP", { locale: ptBR }) : <span>Selecione uma data</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div>
                    <Label htmlFor="tipo-relatorio">Tipo de Relatório</Label>
                    <Select defaultValue="analises">
                      <SelectTrigger id="tipo-relatorio">
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="analises">Análises Realizadas</SelectItem>
                        <SelectItem value="conformidade">Conformidade</SelectItem>
                        <SelectItem value="amostras">Amostras Coletadas</SelectItem>
                        <SelectItem value="parametros">Parâmetros Específicos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="formato-relatorio">Formato</Label>
                    <Select defaultValue="pdf">
                      <SelectTrigger id="formato-relatorio">
                        <SelectValue placeholder="Selecione o formato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pdf">PDF</SelectItem>
                        <SelectItem value="excel">Excel</SelectItem>
                        <SelectItem value="csv">CSV</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="border rounded-md p-4">
                  <h3 className="text-sm font-medium mb-3">Filtros Adicionais</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="local-relatorio">Local</Label>
                      <Select>
                        <SelectTrigger id="local-relatorio">
                          <SelectValue placeholder="Todos os locais" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todos">Todos os locais</SelectItem>
                          <SelectItem value="tanque-equalizacao">Tanque de Equalização</SelectItem>
                          <SelectItem value="saida-biologico">Saída do Tratamento Biológico</SelectItem>
                          <SelectItem value="tanque-aeracao">Tanque de Aeração</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="parametro-relatorio">Parâmetro</Label>
                      <Select>
                        <SelectTrigger id="parametro-relatorio">
                          <SelectValue placeholder="Todos os parâmetros" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todos">Todos os parâmetros</SelectItem>
                          {parametrosDisponiveis.map((parametro) => (
                            <SelectItem key={parametro} value={parametro.toLowerCase().replace(/\s+/g, "-")}>
                              {parametro}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <Button onClick={gerarRelatorio} className="w-full">
                  <FileText className="mr-2 h-4 w-4" />
                  Gerar Relatório
                </Button>

                <div className="border rounded-md p-4">
                  <h3 className="text-sm font-medium mb-3">Relatórios Recentes</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-2 border rounded-md hover:bg-muted/50">
                      <div>
                        <p className="font-medium">Análises de Qualidade - Maio 2023</p>
                        <p className="text-xs text-muted-foreground">Gerado em 01/06/2023</p>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    </div>
                    <div className="flex justify-between items-center p-2 border rounded-md hover:bg-muted/50">
                      <div>
                        <p className="font-medium">Conformidade de Parâmetros - Abril 2023</p>
                        <p className="text-xs text-muted-foreground">Gerado em 05/05/2023</p>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    </div>
                    <div className="flex justify-between items-center p-2 border rounded-md hover:bg-muted/50">
                      <div>
                        <p className="font-medium">Amostras Coletadas - Primeiro Trimestre 2023</p>
                        <p className="text-xs text-muted-foreground">Gerado em 10/04/2023</p>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
