"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import {
  CheckCircle2,
  Clock,
  Droplet,
  Edit,
  Plus,
  Trash2,
  Truck,
  User,
  Users,
  Beaker,
  PenToolIcon as Tool,
  UserCheck,
  ClipboardList,
  CheckSquare,
  AlertTriangle,
} from "lucide-react"
import { TankIcon } from "@/components/icons/tank-icon"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarUI } from "@/components/ui/calendar"

// Tipo para ordem de carregamento
type OrdemCarregamento = {
  id: string
  tanque: string
  destino: string
  transportadora: string
  status: "pendente" | "em_andamento" | "concluido" | "nao_realizado"
  motivoAlteracao?: string
  motivoNaoRealizacao?: string
  turno: "A" | "B" | "C" | "ADM"
  dataInicio?: Date
  dataFim?: Date
  operador?: string
}

// Tipo para atividade com status
type AtividadeItem = {
  id: string
  descricao: string
  status: "pendente" | "em_andamento" | "concluido" | "nao_realizado"
  responsavel: string
  turno: "A" | "B" | "C" | "ADM" | "TODOS"
  prazo: Date
  dataCriacao: Date
  dataAtualizacao?: Date
  motivoNaoRealizacao?: string
}

// Tipo para atividade
type Atividade = {
  turno: string
  operador: string
  itens: AtividadeItem[]
}

// Tipo para ocorrência
type Ocorrencia = {
  id: string
  tipo: string
  descricao: string
  status: "aberta" | "em_andamento" | "resolvida" | "nao_resolvida"
  dataCriacao: Date
  dataAtualizacao?: Date
  responsavel: string
  prioridade: "baixa" | "media" | "alta" | "critica"
  motivoNaoResolucao?: string
}

// Tipo para operador ativo
type OperadorAtivo = {
  id: string
  nome: string
  cargo: string
  turno: "A" | "B" | "C" | "ADM"
  horarioEntrada: string
  horarioSaida: string
  status: "ativo" | "folga" | "ferias" | "afastado"
}

// Tipo para visita
type Visita = {
  id: string
  visitantes: string[]
  empresas: string[]
  dataEntrada: Date
  dataSaida?: Date
  motivo: string
  responsavelInterno: string
  setorVisitado: string
  status: "agendada" | "em_andamento" | "concluida" | "cancelada"
}

// Tipo para manutenção
type Manutencao = {
  id: string
  equipamento: string
  tipo: "preventiva" | "corretiva" | "preditiva"
  descricao: string
  responsavel: string
  dataInicio: Date
  previsaoTermino: Date
  status: "pendente" | "em_andamento" | "concluida" | "cancelada"
}

// Tipo para coleta de amostra
type ColetaAmostra = {
  id: string
  local: string
  tipo: string
  dataAgendada: Date
  responsavel: string
  parametros: string[]
  status: "pendente" | "coletada" | "em_analise" | "concluida"
}

export default function PainelPrincipal() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("principal")
  const [evaporacao, setEvaporacao] = useState({
    tanqueProcessamento: "TQ 32",
    proximoTanque: "TQ 33",
    destinoConcentrado: "TQ TC",
  })

  // Estado para físico químico com turno, operador e itens
  const [fisicoQuimico, setFisicoQuimico] = useState<Atividade>({
    turno: "A",
    operador: "João Silva",
    itens: [
      {
        id: "1",
        descricao: "Transferência do TQ 41 para TQ 42",
        status: "em_andamento",
        responsavel: "João Silva",
        turno: "A",
        prazo: new Date(new Date().setHours(new Date().getHours() + 4)),
        dataCriacao: new Date(new Date().setHours(new Date().getHours() - 2)),
      },
      {
        id: "2",
        descricao: "Preparação de solução de PAC 18% para tratamento",
        status: "pendente",
        responsavel: "Maria Oliveira",
        turno: "B",
        prazo: new Date(new Date().setHours(new Date().getHours() + 8)),
        dataCriacao: new Date(new Date().setHours(new Date().getHours() - 1)),
      },
      {
        id: "3",
        descricao: "Verificação de pH no TQ 43",
        status: "nao_realizado",
        responsavel: "Carlos Santos",
        turno: "C",
        prazo: new Date(new Date().setHours(new Date().getHours() - 2)),
        dataCriacao: new Date(new Date().setHours(new Date().getHours() - 10)),
        motivoNaoRealizacao: "Equipamento de medição em manutenção",
      },
    ],
  })

  // Estado para atividades operacionais com turno, operador e itens
  const [atividadesOperacionais, setAtividadesOperacionais] = useState<Atividade>({
    turno: "TODOS",
    operador: "Equipe Manutenção",
    itens: [
      {
        id: "1",
        descricao: "Limpeza dos filtros do sistema terciário",
        status: "concluido",
        responsavel: "Carlos Santos",
        turno: "B",
        prazo: new Date(new Date().setHours(new Date().getHours() - 3)),
        dataCriacao: new Date(new Date().setHours(new Date().getHours() - 8)),
        dataAtualizacao: new Date(new Date().setHours(new Date().getHours() - 3)),
      },
      {
        id: "2",
        descricao: "Manutenção preventiva da bomba B-2",
        status: "pendente",
        responsavel: "Equipe Manutenção",
        turno: "TODOS",
        prazo: new Date(new Date().setHours(new Date().getHours() + 12)),
        dataCriacao: new Date(new Date().setHours(new Date().getHours() - 24)),
      },
      {
        id: "3",
        descricao: "Calibração de sensores de nível",
        status: "nao_realizado",
        responsavel: "Técnico Externo",
        turno: "ADM",
        prazo: new Date(new Date().setHours(new Date().getHours() - 5)),
        dataCriacao: new Date(new Date().setHours(new Date().getHours() - 48)),
        motivoNaoRealizacao: "Aguardando peças de reposição",
      },
    ],
  })

  // Estados para novas atividades
  const [novaAtividadeFQ, setNovaAtividadeFQ] = useState({
    descricao: "",
    responsavel: "",
    turno: "A",
    prazo: new Date(new Date().setHours(new Date().getHours() + 8)),
  })

  const [novaAtividadeOP, setNovaAtividadeOP] = useState({
    descricao: "",
    responsavel: "",
    turno: "A",
    prazo: new Date(new Date().setHours(new Date().getHours() + 8)),
  })

  // Estado para múltiplas ordens de carregamento
  const [ordensCarregamento, setOrdensCarregamento] = useState<OrdemCarregamento[]>([
    {
      id: "1",
      tanque: "TQ 64",
      destino: "Unidade de Tratamento Externa",
      transportadora: "TransEfluentes Ltda",
      status: "em_andamento",
      turno: "A",
      dataInicio: new Date(new Date().setHours(new Date().getHours() - 1)),
      operador: "João Silva",
    },
    {
      id: "2",
      tanque: "TQ TC",
      destino: "Unidade de Beneficiamento",
      transportadora: "LogiTrans S.A.",
      status: "pendente",
      turno: "B",
      operador: "Carlos Santos",
    },
    {
      id: "3",
      tanque: "TQ 53",
      destino: "Descarte Controlado",
      transportadora: "EcoTransporte Ltda.",
      status: "nao_realizado",
      turno: "C",
      motivoNaoRealizacao: "Caminhão não compareceu no horário agendado",
      operador: "Ana Souza",
    },
  ])

  // Estado para nova ordem de carregamento
  const [novaOrdem, setNovaOrdem] = useState<Omit<OrdemCarregamento, "id">>({
    tanque: "",
    destino: "",
    transportadora: "",
    status: "pendente",
    turno: "A",
  })

  // Estado para edição de ordem
  const [ordemEmEdicao, setOrdemEmEdicao] = useState<OrdemCarregamento | null>(null)
  const [motivoAlteracao, setMotivoAlteracao] = useState("")
  const [dialogEditarAberto, setDialogEditarAberto] = useState(false)
  const [dialogNaoRealizadoAberto, setDialogNaoRealizadoAberto] = useState(false)
  const [atividadeEmEdicao, setAtividadeEmEdicao] = useState<AtividadeItem | null>(null)
  const [tipoAtividadeEmEdicao, setTipoAtividadeEmEdicao] = useState<"fq" | "op" | null>(null)

  // Estado para ocorrências
  const [ocorrencias, setOcorrencias] = useState<Ocorrencia[]>([
    {
      id: "1",
      tipo: "vazamento",
      descricao: "Pequeno vazamento identificado na tubulação do TQ 34",
      status: "em_andamento",
      dataCriacao: new Date(new Date().setHours(new Date().getHours() - 3)),
      responsavel: "Equipe Manutenção",
      prioridade: "alta",
    },
    {
      id: "2",
      tipo: "manutencao",
      descricao: "Manutenção preventiva na bomba B-2",
      status: "aberta",
      dataCriacao: new Date(new Date().setHours(new Date().getHours() - 5)),
      responsavel: "Carlos Santos",
      prioridade: "media",
    },
    {
      id: "3",
      tipo: "falha",
      descricao: "Falha no sensor de nível do TQ 43",
      status: "resolvida",
      dataCriacao: new Date(new Date().setHours(new Date().getHours() - 12)),
      dataAtualizacao: new Date(new Date().setHours(new Date().getHours() - 8)),
      responsavel: "Técnico Externo",
      prioridade: "baixa",
    },
    {
      id: "4",
      tipo: "transbordamento",
      descricao: "Risco de transbordamento no TQ 52",
      status: "nao_resolvida",
      dataCriacao: new Date(new Date().setHours(new Date().getHours() - 10)),
      dataAtualizacao: new Date(new Date().setHours(new Date().getHours() - 6)),
      responsavel: "Maria Oliveira",
      prioridade: "critica",
      motivoNaoResolucao: "Aguardando peças para reparo da válvula de controle",
    },
  ])

  const [novaOcorrencia, setNovaOcorrencia] = useState({
    tipo: "",
    descricao: "",
    responsavel: "",
    prioridade: "media",
  })

  // Estado para operadores ativos
  const [operadoresAtivos, setOperadoresAtivos] = useState<OperadorAtivo[]>([
    {
      id: "1",
      nome: "João Silva",
      cargo: "Operador",
      turno: "A",
      horarioEntrada: "06:00",
      horarioSaida: "14:00",
      status: "ativo",
    },
    {
      id: "2",
      nome: "Maria Oliveira",
      cargo: "Supervisora",
      turno: "ADM",
      horarioEntrada: "08:00",
      horarioSaida: "17:00",
      status: "ativo",
    },
    {
      id: "3",
      nome: "Carlos Santos",
      cargo: "Técnico de Laboratório",
      turno: "B",
      horarioEntrada: "14:00",
      horarioSaida: "22:00",
      status: "folga",
    },
    {
      id: "4",
      nome: "Ana Souza",
      cargo: "Analista Administrativo",
      turno: "ADM",
      horarioEntrada: "08:00",
      horarioSaida: "17:00",
      status: "ativo",
    },
    {
      id: "5",
      nome: "Pedro Almeida",
      cargo: "Operador",
      turno: "C",
      horarioEntrada: "22:00",
      horarioSaida: "06:00",
      status: "ativo",
    },
  ])

  // Estado para visitas
  const [visitas, setVisitas] = useState<Visita[]>([
    {
      id: "1",
      visitantes: ["João Silva", "Maria Oliveira"],
      empresas: ["Empresa ABC", "Consultoria XYZ"],
      dataEntrada: new Date(new Date().setHours(new Date().getHours() - 1)),
      motivo: "Reunião de alinhamento sobre fornecimento de produtos químicos",
      responsavelInterno: "Roberto Almeida",
      setorVisitado: "Compras",
      status: "em_andamento",
    },
    {
      id: "2",
      visitantes: ["Carlos Santos"],
      empresas: ["Cliente Final Ltda"],
      dataEntrada: new Date(new Date().setHours(new Date().getHours() + 2)),
      motivo: "Visita técnica para avaliação de produto",
      responsavelInterno: "Carla Mendes",
      setorVisitado: "Produção",
      status: "agendada",
    },
  ])

  // Estado para manutenções
  const [manutencoes, setManutencoes] = useState<Manutencao[]>([
    {
      id: "1",
      equipamento: "Bomba B-2",
      tipo: "preventiva",
      descricao: "Troca de rolamentos e verificação de alinhamento",
      responsavel: "Equipe Manutenção",
      dataInicio: new Date(new Date().setHours(new Date().getHours() - 4)),
      previsaoTermino: new Date(new Date().setHours(new Date().getHours() + 2)),
      status: "em_andamento",
    },
    {
      id: "2",
      equipamento: "Válvula V-12",
      tipo: "corretiva",
      descricao: "Substituição de vedação com vazamento",
      responsavel: "Carlos Santos",
      dataInicio: new Date(new Date().setHours(new Date().getHours() - 1)),
      previsaoTermino: new Date(new Date().setHours(new Date().getHours() + 1)),
      status: "em_andamento",
    },
    {
      id: "3",
      equipamento: "Sensor de Nível TQ-43",
      tipo: "corretiva",
      descricao: "Calibração e verificação de funcionamento",
      responsavel: "Técnico Externo",
      dataInicio: new Date(new Date().setHours(new Date().getHours() + 3)),
      previsaoTermino: new Date(new Date().setHours(new Date().getHours() + 5)),
      status: "pendente",
    },
  ])

  // Estado para coletas de amostras
  const [coletasAmostras, setColetasAmostras] = useState<ColetaAmostra[]>([
    {
      id: "1",
      local: "Tanque de Equalização",
      tipo: "Efluente Bruto",
      dataAgendada: new Date(new Date().setHours(new Date().getHours() + 1)),
      responsavel: "Ana Silva",
      parametros: ["pH", "DQO", "DBO", "Sólidos Suspensos"],
      status: "pendente",
    },
    {
      id: "2",
      local: "Saída do Tratamento Biológico",
      tipo: "Efluente Tratado",
      dataAgendada: new Date(new Date().setMinutes(new Date().getMinutes() + 30)),
      responsavel: "Carlos Santos",
      parametros: ["pH", "DQO", "DBO", "Nitrogênio Total", "Fósforo Total"],
      status: "pendente",
    },
    {
      id: "3",
      local: "Tanque de Aeração",
      tipo: "Lodo Ativado",
      dataAgendada: new Date(new Date().setHours(new Date().getHours() - 1)),
      responsavel: "Ana Silva",
      parametros: ["SST", "SSV", "IVL"],
      status: "coletada",
    },
  ])

  // Função para verificar se uma atividade está atrasada
  const isAtividade8HorasAtrasada = (atividade: AtividadeItem) => {
    const agora = new Date()
    const prazo = new Date(atividade.prazo)
    return agora > prazo && atividade.status !== "concluido" && atividade.status !== "nao_realizado"
  }

  // Função para verificar se uma ocorrência está atrasada
  const isOcorrencia8HorasAtrasada = (ocorrencia: Ocorrencia) => {
    const agora = new Date()
    const dataCriacao = new Date(ocorrencia.dataCriacao)
    const oitoHorasDepois = new Date(dataCriacao)
    oitoHorasDepois.setHours(dataCriacao.getHours() + 8)
    return agora > oitoHorasDepois && ocorrencia.status !== "resolvida" && ocorrencia.status !== "nao_resolvida"
  }

  // Função para obter operadores ativos no momento
  const getOperadoresAtivosAgora = () => {
    const horaAtual = new Date().getHours()
    let turnoAtual = ""

    if (horaAtual >= 6 && horaAtual < 14) {
      turnoAtual = "A"
    } else if (horaAtual >= 14 && horaAtual < 22) {
      turnoAtual = "B"
    } else {
      turnoAtual = "C"
    }

    return operadoresAtivos.filter((op) => (op.turno === turnoAtual || op.turno === "ADM") && op.status === "ativo")
  }

  const handleSaveOrdem = () => {
    if (!novaOrdem.tanque || !novaOrdem.destino || !novaOrdem.transportadora || !novaOrdem.turno) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos da ordem de carregamento.",
        variant: "destructive",
      })
      return
    }

    // Gerar ID único baseado no timestamp
    const novoId = Date.now().toString()

    // Adicionar nova ordem ao array
    setOrdensCarregamento([
      ...ordensCarregamento,
      {
        id: novoId,
        ...novaOrdem,
      },
    ])

    // Limpar o formulário
    setNovaOrdem({
      tanque: "",
      destino: "",
      transportadora: "",
      status: "pendente",
      turno: "A",
    })

    toast({
      title: "Ordem adicionada com sucesso!",
      description: "A nova ordem de carregamento foi adicionada.",
      variant: "default",
    })
  }

  const removerOrdem = (id: string) => {
    setOrdensCarregamento(ordensCarregamento.filter((ordem) => ordem.id !== id))

    toast({
      title: "Ordem removida",
      description: "A ordem de carregamento foi removida com sucesso.",
      variant: "default",
    })
  }

  const editarOrdem = (ordem: OrdemCarregamento) => {
    setOrdemEmEdicao(ordem)
    setDialogEditarAberto(true)
  }

  const salvarEdicaoOrdem = () => {
    if (!ordemEmEdicao) return

    if (ordemEmEdicao.status === "nao_realizado" && !ordemEmEdicao.motivoNaoRealizacao) {
      toast({
        title: "Campo obrigatório",
        description: "Informe o motivo da não realização.",
        variant: "destructive",
      })
      return
    }

    if (ordemEmEdicao.status !== "nao_realizado" && !motivoAlteracao) {
      toast({
        title: "Campo obrigatório",
        description: "Informe o motivo da alteração de status.",
        variant: "destructive",
      })
      return
    }

    // Atualizar data de início e fim conforme o status
    const ordemAtualizada = { ...ordemEmEdicao }

    if (ordemAtualizada.status === "em_andamento" && !ordemAtualizada.dataInicio) {
      ordemAtualizada.dataInicio = new Date()
    } else if (ordemAtualizada.status === "concluido" && !ordemAtualizada.dataFim) {
      ordemAtualizada.dataFim = new Date()
    }

    if (ordemAtualizada.status !== "nao_realizado") {
      ordemAtualizada.motivoAlteracao = motivoAlteracao
    }

    setOrdensCarregamento(
      ordensCarregamento.map((ordem) => (ordem.id === ordemAtualizada.id ? ordemAtualizada : ordem)),
    )

    setDialogEditarAberto(false)
    setOrdemEmEdicao(null)
    setMotivoAlteracao("")

    toast({
      title: "Ordem atualizada",
      description: "O status da ordem foi atualizado com sucesso.",
      variant: "default",
    })
  }

  const handleSaveOcorrencia = () => {
    if (!novaOcorrencia.tipo || !novaOcorrencia.descricao || !novaOcorrencia.responsavel) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos da ocorrência.",
        variant: "destructive",
      })
      return
    }

    const novoId = Date.now().toString()
    const ocorrenciaCompleta: Ocorrencia = {
      id: novoId,
      tipo: novaOcorrencia.tipo,
      descricao: novaOcorrencia.descricao,
      status: "aberta",
      dataCriacao: new Date(),
      responsavel: novaOcorrencia.responsavel,
      prioridade: novaOcorrencia.prioridade as "baixa" | "media" | "alta" | "critica",
    }

    setOcorrencias([...ocorrencias, ocorrenciaCompleta])
    setNovaOcorrencia({
      tipo: "",
      descricao: "",
      responsavel: "",
      prioridade: "media",
    })

    toast({
      title: "Ocorrência registrada!",
      description: "A ocorrência foi registrada com sucesso.",
      variant: "default",
    })
  }

  // Função para adicionar nova atividade ao físico químico
  const adicionarAtividadeFQ = () => {
    if (!novaAtividadeFQ.descricao || !novaAtividadeFQ.turno) {
      toast({
        title: "Campos obrigatórios",
        description: "Informe a descrição e o turno da atividade.",
        variant: "destructive",
      })
      return
    }

    const novoId = Date.now().toString()
    const novaAtividade: AtividadeItem = {
      id: novoId,
      descricao: novaAtividadeFQ.descricao,
      status: "pendente",
      responsavel: novaAtividadeFQ.responsavel || fisicoQuimico.operador,
      turno: novaAtividadeFQ.turno as "A" | "B" | "C" | "ADM" | "TODOS",
      prazo: novaAtividadeFQ.prazo,
      dataCriacao: new Date(),
    }

    setFisicoQuimico({
      ...fisicoQuimico,
      itens: [...fisicoQuimico.itens, novaAtividade],
    })

    setNovaAtividadeFQ({
      descricao: "",
      responsavel: "",
      turno: "A",
      prazo: new Date(new Date().setHours(new Date().getHours() + 8)),
    })

    toast({
      title: "Atividade adicionada",
      description: "A atividade foi adicionada com sucesso.",
    })
  }

  // Função para adicionar nova atividade operacional
  const adicionarAtividadeOP = () => {
    if (!novaAtividadeOP.descricao || !novaAtividadeOP.turno) {
      toast({
        title: "Campos obrigatórios",
        description: "Informe a descrição e o turno da atividade.",
        variant: "destructive",
      })
      return
    }

    const novoId = Date.now().toString()
    const novaAtividade: AtividadeItem = {
      id: novoId,
      descricao: novaAtividadeOP.descricao,
      status: "pendente",
      responsavel: novaAtividadeOP.responsavel || atividadesOperacionais.operador,
      turno: novaAtividadeOP.turno as "A" | "B" | "C" | "ADM" | "TODOS",
      prazo: novaAtividadeOP.prazo,
      dataCriacao: new Date(),
    }

    setAtividadesOperacionais({
      ...atividadesOperacionais,
      itens: [...atividadesOperacionais.itens, novaAtividade],
    })

    setNovaAtividadeOP({
      descricao: "",
      responsavel: "",
      turno: "A",
      prazo: new Date(new Date().setHours(new Date().getHours() + 8)),
    })

    toast({
      title: "Atividade adicionada",
      description: "A atividade foi adicionada com sucesso.",
    })
  }

  // Função para atualizar status de atividade do físico químico
  const atualizarStatusAtividadeFQ = (
    id: string,
    novoStatus: "pendente" | "em_andamento" | "concluido" | "nao_realizado",
  ) => {
    if (novoStatus === "nao_realizado") {
      const atividade = fisicoQuimico.itens.find((item) => item.id === id)
      if (atividade) {
        setAtividadeEmEdicao(atividade)
        setTipoAtividadeEmEdicao("fq")
        setDialogNaoRealizadoAberto(true)
      }
      return
    }

    setFisicoQuimico({
      ...fisicoQuimico,
      itens: fisicoQuimico.itens.map((item) =>
        item.id === id
          ? {
              ...item,
              status: novoStatus,
              dataAtualizacao: new Date(),
            }
          : item,
      ),
    })

    toast({
      title: "Status atualizado",
      description: "O status da atividade foi atualizado com sucesso.",
    })
  }

  // Função para atualizar status de atividade operacional
  const atualizarStatusAtividadeOP = (
    id: string,
    novoStatus: "pendente" | "em_andamento" | "concluido" | "nao_realizado",
  ) => {
    if (novoStatus === "nao_realizado") {
      const atividade = atividadesOperacionais.itens.find((item) => item.id === id)
      if (atividade) {
        setAtividadeEmEdicao(atividade)
        setTipoAtividadeEmEdicao("op")
        setDialogNaoRealizadoAberto(true)
      }
      return
    }

    setAtividadesOperacionais({
      ...atividadesOperacionais,
      itens: atividadesOperacionais.itens.map((item) =>
        item.id === id
          ? {
              ...item,
              status: novoStatus,
              dataAtualizacao: new Date(),
            }
          : item,
      ),
    })

    toast({
      title: "Status atualizado",
      description: "O status da atividade foi atualizado com sucesso.",
    })
  }

  // Função para salvar motivo de não realização
  const salvarMotivoNaoRealizacao = () => {
    if (!atividadeEmEdicao || !atividadeEmEdicao.motivoNaoRealizacao) {
      toast({
        title: "Campo obrigatório",
        description: "Informe o motivo da não realização.",
        variant: "destructive",
      })
      return
    }

    if (tipoAtividadeEmEdicao === "fq") {
      setFisicoQuimico({
        ...fisicoQuimico,
        itens: fisicoQuimico.itens.map((item) =>
          item.id === atividadeEmEdicao.id
            ? {
                ...atividadeEmEdicao,
                status: "nao_realizado",
                dataAtualizacao: new Date(),
              }
            : item,
        ),
      })
    } else if (tipoAtividadeEmEdicao === "op") {
      setAtividadesOperacionais({
        ...atividadesOperacionais,
        itens: atividadesOperacionais.itens.map((item) =>
          item.id === atividadeEmEdicao.id
            ? {
                ...atividadeEmEdicao,
                status: "nao_realizado",
                dataAtualizacao: new Date(),
              }
            : item,
        ),
      })
    }

    setDialogNaoRealizadoAberto(false)
    setAtividadeEmEdicao(null)
    setTipoAtividadeEmEdicao(null)

    toast({
      title: "Status atualizado",
      description: "O status da atividade foi atualizado com sucesso.",
    })
  }

  // Função para remover atividade do físico químico
  const removerAtividadeFQ = (id: string) => {
    setFisicoQuimico({
      ...fisicoQuimico,
      itens: fisicoQuimico.itens.filter((item) => item.id !== id),
    })

    toast({
      title: "Atividade removida",
      description: "A atividade foi removida com sucesso.",
    })
  }

  // Função para remover atividade operacional
  const removerAtividadeOP = (id: string) => {
    setAtividadesOperacionais({
      ...atividadesOperacionais,
      itens: atividadesOperacionais.itens.filter((item) => item.id !== id),
    })

    toast({
      title: "Atividade removida",
      description: "A atividade foi removida com sucesso.",
    })
  }

  // Função para obter a cor do status
  const getStatusColor = (status?: string) => {
    switch (status) {
      case "pendente":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
      case "em_andamento":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
      case "concluido":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "nao_realizado":
      case "nao_resolvida":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      case "aberta":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300"
      case "resolvida":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "nao_resolvida":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  // Função para obter a cor da prioridade
  const getPrioridadeColor = (prioridade?: string) => {
    switch (prioridade) {
      case "baixa":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "media":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
      case "alta":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300"
      case "critica":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  // Função para obter o texto do status
  const getStatusText = (status?: string) => {
    switch (status) {
      case "pendente":
        return "Pendente"
      case "em_andamento":
        return "Em Andamento"
      case "concluido":
        return "Concluído"
      case "nao_realizado":
        return "Não Realizado"
      case "aberta":
        return "Aberta"
      case "resolvida":
        return "Resolvida"
      case "nao_resolvida":
        return "Não Resolvida"
      default:
        return "Não definido"
    }
  }

  // Função para obter o texto da prioridade
  const getPrioridadeText = (prioridade?: string) => {
    switch (prioridade) {
      case "baixa":
        return "Baixa"
      case "media":
        return "Média"
      case "alta":
        return "Alta"
      case "critica":
        return "Crítica"
      default:
        return "Não definida"
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Painel Principal</h1>
      <Tabs defaultValue="principal" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="principal">Painel Principal</TabsTrigger>
          <TabsTrigger value="cadastro">Cadastro de Ordens</TabsTrigger>
        </TabsList>

        <TabsContent value="principal" className="space-y-6">
          {/* Resumo Geral - Cards com contadores */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Visitas Hoje</p>
                  <h3 className="text-2xl font-bold">
                    {
                      visitas.filter((v) => {
                        const hoje = new Date()
                        hoje.setHours(0, 0, 0, 0)
                        const amanha = new Date(hoje)
                        amanha.setDate(amanha.getDate() + 1)
                        const dataVisita = new Date(v.dataEntrada)
                        return dataVisita >= hoje && dataVisita < amanha
                      }).length
                    }
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {visitas.filter((v) => v.status === "em_andamento").length} em andamento
                  </p>
                </div>
                <div className="bg-blue-100 dark:bg-blue-900/20 p-3 rounded-full">
                  <UserCheck className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Operadores Ativos</p>
                  <h3 className="text-2xl font-bold">{getOperadoresAtivosAgora().length}</h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    Turno {getOperadoresAtivosAgora().length > 0 ? getOperadoresAtivosAgora()[0].turno : "-"}
                  </p>
                </div>
                <div className="bg-green-100 dark:bg-green-900/20 p-3 rounded-full">
                  <Users className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Manutenções</p>
                  <h3 className="text-2xl font-bold">
                    {manutencoes.filter((m) => m.status === "em_andamento" || m.status === "pendente").length}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {manutencoes.filter((m) => m.status === "em_andamento").length} em andamento
                  </p>
                </div>
                <div className="bg-orange-100 dark:bg-orange-900/20 p-3 rounded-full">
                  <Tool className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Coletas Pendentes</p>
                  <h3 className="text-2xl font-bold">
                    {coletasAmostras.filter((c) => c.status === "pendente").length}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    Próxima em{" "}
                    {coletasAmostras.filter((c) => c.status === "pendente").length > 0
                      ? format(
                          new Date(
                            coletasAmostras
                              .filter((c) => c.status === "pendente")
                              .sort((a, b) => a.dataAgendada.getTime() - b.dataAgendada.getTime())[0].dataAgendada,
                          ),
                          "HH:mm",
                        )
                      : "-"}
                  </p>
                </div>
                <div className="bg-purple-100 dark:bg-purple-900/20 p-3 rounded-full">
                  <Beaker className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Operadores Ativos */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-green-500" />
                Operadores Ativos
              </CardTitle>
              <CardDescription>Equipe em operação no momento</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {getOperadoresAtivosAgora().map((operador) => (
                  <div key={operador.id} className="border rounded-md p-3 flex items-center gap-3">
                    <div className="bg-green-100 dark:bg-green-900/20 p-2 rounded-full">
                      <User className="h-5 w-5 text-green-500" />
                    </div>
                    <div>
                      <p className="font-medium">{operador.nome}</p>
                      <p className="text-sm text-muted-foreground">
                        {operador.cargo} - Turno {operador.turno}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {operador.horarioEntrada} - {operador.horarioSaida}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Visitas na Unidade */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="h-5 w-5 text-blue-500" />
                Visitas na Unidade
              </CardTitle>
              <CardDescription>Visitas em andamento e agendadas para hoje</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {visitas.filter((v) => v.status === "em_andamento" || v.status === "agendada").length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    Não há visitas em andamento ou agendadas para hoje.
                  </div>
                ) : (
                  visitas
                    .filter((v) => v.status === "em_andamento" || v.status === "agendada")
                    .map((visita) => (
                      <div key={visita.id} className="border rounded-md p-3 relative">
                        <div className="absolute top-3 right-3">
                          <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(visita.status)}`}>
                            {getStatusText(visita.status)}
                          </span>
                        </div>
                        <div className="pr-24">
                          <h3 className="font-medium">{visita.visitantes.join(", ")}</h3>
                          <p className="text-sm text-muted-foreground">{visita.empresas.join(", ")}</p>
                          <div className="mt-2 space-y-1 text-sm">
                            <p>
                              <span className="font-medium">Motivo:</span> {visita.motivo}
                            </p>
                            <p>
                              <span className="font-medium">Responsável:</span> {visita.responsavelInterno}
                            </p>
                            <p>
                              <span className="font-medium">Setor:</span> {visita.setorVisitado}
                            </p>
                            <p>
                              <span className="font-medium">Horário:</span>{" "}
                              {format(new Date(visita.dataEntrada), "HH:mm")}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Evaporação */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplet className="h-5 w-5 text-blue-500" />
                  Evaporação
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Tanque em Processamento:</span>
                      <span>{evaporacao.tanqueProcessamento || "Não definido"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Próximo Tanque a Processar:</span>
                      <span>{evaporacao.proximoTanque || "Não definido"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Destino do Concentrado:</span>
                      <span>{evaporacao.destinoConcentrado || "Não definido"}</span>
                    </div>
                  </div>
                  <TankIcon fillLevel={65} status="normal" size="lg" />
                </div>
              </CardContent>
            </Card>

            {/* Ordens de Carregamento */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Truck className="h-5 w-5 text-green-500" />
                  Ordens de Carregamento
                </CardTitle>
                <CardDescription>
                  {ordensCarregamento.length} {ordensCarregamento.length === 1 ? "ordem" : "ordens"} cadastradas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {ordensCarregamento.length === 0 ? (
                    <div className="text-center py-4 text-muted-foreground">
                      Nenhuma ordem de carregamento cadastrada
                    </div>
                  ) : (
                    ordensCarregamento
                      .filter((ordem) => ordem.status === "pendente" || ordem.status === "em_andamento")
                      .slice(0, 2)
                      .map((ordem) => (
                        <div key={ordem.id} className="border rounded-md p-3 relative">
                          <div className="absolute top-2 right-2">
                            <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(ordem.status)}`}>
                              {getStatusText(ordem.status)}
                            </span>
                          </div>
                          <div className="flex items-center justify-between mt-4">
                            <div className="space-y-1 pr-24">
                              <div className="flex items-center gap-2">
                                <span className="font-medium">Tanque:</span>
                                <span>{ordem.tanque}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">Destino:</span>
                                <span>{ordem.destino}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">Transportadora:</span>
                                <span>{ordem.transportadora}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">Turno:</span>
                                <span>Turno {ordem.turno}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                  )}
                  {ordensCarregamento.filter((ordem) => ordem.status === "pendente" || ordem.status === "em_andamento")
                    .length > 2 && (
                    <div className="text-center">
                      <Button variant="link" size="sm">
                        Ver todas as ordens
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Manutenções em Andamento */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Tool className="h-5 w-5 text-orange-500" />
                  Manutenções em Andamento
                </CardTitle>
                <CardDescription>Manutenções preventivas e corretivas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {manutencoes.filter((m) => m.status === "em_andamento").length === 0 ? (
                    <div className="text-center py-4 text-muted-foreground">
                      Não há manutenções em andamento no momento.
                    </div>
                  ) : (
                    manutencoes
                      .filter((m) => m.status === "em_andamento")
                      .map((manutencao) => (
                        <div key={manutencao.id} className="border rounded-md p-3 relative">
                          <div className="absolute top-2 right-2">
                            <span
                              className={`px-2 py-1 rounded-full text-xs ${
                                manutencao.tipo === "preventiva"
                                  ? "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
                                  : "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300"
                              }`}
                            >
                              {manutencao.tipo === "preventiva" ? "Preventiva" : "Corretiva"}
                            </span>
                          </div>
                          <div className="pr-24">
                            <h3 className="font-medium">{manutencao.equipamento}</h3>
                            <p className="text-sm">{manutencao.descricao}</p>
                            <div className="mt-2 space-y-1 text-sm">
                              <p>
                                <span className="font-medium">Responsável:</span> {manutencao.responsavel}
                              </p>
                              <p>
                                <span className="font-medium">Início:</span>{" "}
                                {format(new Date(manutencao.dataInicio), "HH:mm")}
                              </p>
                              <p>
                                <span className="font-medium">Previsão:</span>{" "}
                                {format(new Date(manutencao.previsaoTermino), "HH:mm")}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Coletas de Amostras Pendentes */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-purple-500" />
                  Coletas de Amostras Pendentes
                </CardTitle>
                <CardDescription>Amostras agendadas para coleta</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {coletasAmostras.filter((c) => c.status === "pendente").length === 0 ? (
                    <div className="text-center py-4 text-muted-foreground">
                      Não há coletas de amostras pendentes no momento.
                    </div>
                  ) : (
                    coletasAmostras
                      .filter((c) => c.status === "pendente")
                      .sort((a, b) => a.dataAgendada.getTime() - b.dataAgendada.getTime())
                      .map((coleta) => (
                        <div key={coleta.id} className="border rounded-md p-3 relative">
                          <div className="absolute top-2 right-2">
                            <span className="px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300">
                              {format(new Date(coleta.dataAgendada), "HH:mm")}
                            </span>
                          </div>
                          <div className="pr-20">
                            <h3 className="font-medium">{coleta.local}</h3>
                            <p className="text-sm text-muted-foreground">{coleta.tipo}</p>
                            <div className="mt-2 space-y-1 text-sm">
                              <p>
                                <span className="font-medium">Responsável:</span> {coleta.responsavel}
                              </p>
                              <p>
                                <span className="font-medium">Parâmetros:</span> {coleta.parametros.join(", ")}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Atividades Físico Químico */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ClipboardList className="h-5 w-5 text-blue-500" />
                  Físico Químico
                </CardTitle>
                <CardDescription>Atividades pendentes e em andamento</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Turno:</span>
                    <span className="px-2 py-0.5 bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300 rounded-full">
                      Turno {fisicoQuimico.turno}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Operador:</span>
                    <span>{fisicoQuimico.operador}</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <h4 className="text-sm font-medium">Atividades:</h4>
                    </div>
                    {fisicoQuimico.itens.length === 0 ? (
                      <div className="text-center py-2 text-sm text-muted-foreground">Nenhuma atividade cadastrada</div>
                    ) : (
                      <div className="space-y-2">
                        {fisicoQuimico.itens
                          .filter((item) => item.status === "pendente" || item.status === "em_andamento")
                          .map((item) => (
                            <div
                              key={item.id}
                              className={`border rounded-md p-2 text-sm relative ${
                                isAtividade8HorasAtrasada(item) ? "border-red-500 bg-red-50 dark:bg-red-900/10" : ""
                              }`}
                            >
                              <div className="absolute top-2 right-2">
                                <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(item.status)}`}>
                                  {getStatusText(item.status)}
                                </span>
                              </div>
                              <div className="pr-24">
                                <p>{item.descricao}</p>
                                <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                                  <span>
                                    Responsável: {item.responsavel} (Turno {item.turno})
                                  </span>
                                  <span>
                                    <Clock className="h-3 w-3 inline mr-1" />
                                    Prazo: {format(new Date(item.prazo), "dd/MM HH:mm")}
                                  </span>
                                </div>
                                {isAtividade8HorasAtrasada(item) && (
                                  <div className="mt-1 text-xs text-red-500">Atividade atrasada! Prazo excedido.</div>
                                )}
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Atividades Operacionais */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckSquare className="h-5 w-5 text-green-500" />
                  Atividades Operacionais
                </CardTitle>
                <CardDescription>Atividades pendentes e em andamento</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Turno:</span>
                    <span className="px-2 py-0.5 bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300 rounded-full">
                      {atividadesOperacionais.turno}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Operador:</span>
                    <span>{atividadesOperacionais.operador}</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <h4 className="text-sm font-medium">Atividades:</h4>
                    </div>
                    {atividadesOperacionais.itens.length === 0 ? (
                      <div className="text-center py-2 text-sm text-muted-foreground">Nenhuma atividade cadastrada</div>
                    ) : (
                      <div className="space-y-2">
                        {atividadesOperacionais.itens
                          .filter((item) => item.status === "pendente" || item.status === "em_andamento")
                          .map((item) => (
                            <div
                              key={item.id}
                              className={`border rounded-md p-2 text-sm relative ${
                                isAtividade8HorasAtrasada(item) ? "border-red-500 bg-red-50 dark:bg-red-900/10" : ""
                              }`}
                            >
                              <div className="absolute top-2 right-2">
                                <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(item.status)}`}>
                                  {getStatusText(item.status)}
                                </span>
                              </div>
                              <div className="pr-24">
                                <p>{item.descricao}</p>
                                <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                                  <span>
                                    Responsável: {item.responsavel} (Turno {item.turno})
                                  </span>
                                  <span>
                                    <Clock className="h-3 w-3 inline mr-1" />
                                    Prazo: {format(new Date(item.prazo), "dd/MM HH:mm")}
                                  </span>
                                </div>
                                {isAtividade8HorasAtrasada(item) && (
                                  <div className="mt-1 text-xs text-red-500">Atividade atrasada! Prazo excedido.</div>
                                )}
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Ocorrências Operacionais */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                Ocorrências Operacionais
              </CardTitle>
              <CardDescription>Ocorrências críticas e de alta prioridade</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {ocorrencias.filter((o) => o.prioridade === "alta" || o.prioridade === "critica").length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    Não há ocorrências críticas ou de alta prioridade no momento.
                  </div>
                ) : (
                  ocorrencias
                    .filter((o) => o.prioridade === "alta" || o.prioridade === "critica")
                    .filter((o) => o.status === "aberta" || o.status === "em_andamento")
                    .map((ocorrencia) => (
                      <div
                        key={ocorrencia.id}
                        className={`border rounded-md p-3 ${
                          isOcorrencia8HorasAtrasada(ocorrencia) ? "border-red-500 bg-red-50 dark:bg-red-900/10" : ""
                        }`}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium capitalize">{ocorrencia.tipo}</h4>
                              <span
                                className={`px-2 py-1 rounded-full text-xs ${getPrioridadeColor(ocorrencia.prioridade)}`}
                              >
                                {getPrioridadeText(ocorrencia.prioridade)}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">{ocorrencia.descricao}</p>
                            <p className="text-xs text-muted-foreground mt-1">Responsável: {ocorrencia.responsavel}</p>
                            {isOcorrencia8HorasAtrasada(ocorrencia) && (
                              <p className="text-xs text-red-500 mt-1">
                                Ocorrência atrasada! Mais de 8 horas sem resolução.
                              </p>
                            )}
                          </div>
                          <div className="flex flex-col items-end">
                            <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(ocorrencia.status)}`}>
                              {getStatusText(ocorrencia.status)}
                            </span>
                            <span className="text-xs text-muted-foreground mt-1">
                              {format(new Date(ocorrencia.dataCriacao), "dd/MM/yyyy HH:mm")}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cadastro" className="space-y-6">
          (
          <Card>
            <CardHeader>
              <CardTitle>Cadastro de Ordens e Atividades</CardTitle>
              <CardDescription>Preencha as informações para atualizar o painel principal</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-3">Evaporação</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="tanque-processamento">Tanque em Processamento</Label>
                    <Input
                      id="tanque-processamento"
                      placeholder="Nº TQ"
                      value={evaporacao.tanqueProcessamento}
                      onChange={(e) => setEvaporacao({ ...evaporacao, tanqueProcessamento: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="proximo-tanque">Próximo Tanque a Processar</Label>
                    <Input
                      id="proximo-tanque"
                      placeholder="Nº TQ"
                      value={evaporacao.proximoTanque}
                      onChange={(e) => setEvaporacao({ ...evaporacao, proximoTanque: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="destino-concentrado">Destino do Concentrado</Label>
                    <Input
                      id="destino-concentrado"
                      placeholder="Nº TQ (opcional)"
                      value={evaporacao.destinoConcentrado}
                      onChange={(e) => setEvaporacao({ ...evaporacao, destinoConcentrado: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-3">Físico Químico</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                  <div>
                    <Label htmlFor="fisico-quimico-turno">Turno</Label>
                    <Select
                      value={fisicoQuimico.turno}
                      onValueChange={(value) => setFisicoQuimico({ ...fisicoQuimico, turno: value })}
                    >
                      <SelectTrigger id="fisico-quimico-turno">
                        <SelectValue placeholder="Selecione o turno" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A">TURNO A</SelectItem>
                        <SelectItem value="B">TURNO B</SelectItem>
                        <SelectItem value="C">TURNO C</SelectItem>
                        <SelectItem value="TODOS">TODOS</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="fisico-quimico-operador">Operador</Label>
                    <Input
                      id="fisico-quimico-operador"
                      placeholder="Nome do operador"
                      value={fisicoQuimico.operador}
                      onChange={(e) => setFisicoQuimico({ ...fisicoQuimico, operador: e.target.value })}
                    />
                  </div>
                </div>

                <div className="border rounded-md p-4 mb-4">
                  <h4 className="text-sm font-medium mb-3">Atividades</h4>
                  <div className="space-y-3">
                    {fisicoQuimico.itens.map((item) => (
                      <div key={item.id} className="border rounded-md p-3 relative">
                        <div className="flex justify-between items-start">
                          <div className="space-y-1 pr-32">
                            <Input
                              value={item.descricao}
                              onChange={(e) => {
                                setFisicoQuimico({
                                  ...fisicoQuimico,
                                  itens: fisicoQuimico.itens.map((i) =>
                                    i.id === item.id ? { ...i, descricao: e.target.value } : i,
                                  ),
                                })
                              }}
                            />
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <Label htmlFor={`resp-${item.id}`} className="text-xs">
                                  Responsável:
                                </Label>
                                <Input
                                  id={`resp-${item.id}`}
                                  value={item.responsavel}
                                  onChange={(e) => {
                                    setFisicoQuimico({
                                      ...fisicoQuimico,
                                      itens: fisicoQuimico.itens.map((i) =>
                                        i.id === item.id ? { ...i, responsavel: e.target.value } : i,
                                      ),
                                    })
                                  }}
                                  className="h-7 text-xs"
                                />
                              </div>
                              <div>
                                <Label htmlFor={`turno-${item.id}`} className="text-xs">
                                  Turno:
                                </Label>
                                <Select
                                  value={item.turno}
                                  onValueChange={(value: "A" | "B" | "C" | "ADM" | "TODOS") => {
                                    setFisicoQuimico({
                                      ...fisicoQuimico,
                                      itens: fisicoQuimico.itens.map((i) =>
                                        i.id === item.id ? { ...i, turno: value } : i,
                                      ),
                                    })
                                  }}
                                >
                                  <SelectTrigger id={`turno-${item.id}`} className="h-7 text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="A">Turno A</SelectItem>
                                    <SelectItem value="B">Turno B</SelectItem>
                                    <SelectItem value="C">Turno C</SelectItem>
                                    <SelectItem value="ADM">ADM</SelectItem>
                                    <SelectItem value="TODOS">TODOS</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            <div>
                              <Label htmlFor={`prazo-${item.id}`} className="text-xs">
                                Prazo:
                              </Label>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant={"outline"}
                                    className="w-full h-7 text-xs justify-start text-left font-normal"
                                  >
                                    <Clock className="mr-2 h-3 w-3" />
                                    {format(new Date(item.prazo), "PPP HH:mm", { locale: ptBR })}
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                  <CalendarUI
                                    mode="single"
                                    selected={new Date(item.prazo)}
                                    onSelect={(date) => {
                                      if (date) {
                                        const newDate = new Date(date)
                                        newDate.setHours(new Date(item.prazo).getHours())
                                        newDate.setMinutes(new Date(item.prazo).getMinutes())

                                        setFisicoQuimico({
                                          ...fisicoQuimico,
                                          itens: fisicoQuimico.itens.map((i) =>
                                            i.id === item.id ? { ...i, prazo: newDate } : i,
                                          ),
                                        })
                                      }
                                    }}
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                            </div>
                          </div>
                          <div className="absolute top-3 right-3 flex items-center gap-2">
                            <Select
                              value={item.status}
                              onValueChange={(value: "pendente" | "em_andamento" | "concluido" | "nao_realizado") => {
                                if (value === "nao_realizado") {
                                  setAtividadeEmEdicao(item)
                                  setTipoAtividadeEmEdicao("fq")
                                  setDialogNaoRealizadoAberto(true)
                                  return
                                }

                                setFisicoQuimico({
                                  ...fisicoQuimico,
                                  itens: fisicoQuimico.itens.map((i) =>
                                    i.id === item.id ? { ...i, status: value, dataAtualizacao: new Date() } : i,
                                  ),
                                })
                              }}
                            >
                              <SelectTrigger className="w-36">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pendente">Pendente</SelectItem>
                                <SelectItem value="em_andamento">Em Andamento</SelectItem>
                                <SelectItem value="concluido">Concluído</SelectItem>
                                <SelectItem value="nao_realizado">Não Realizado</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button variant="ghost" size="icon" onClick={() => removerAtividadeFQ(item.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-2">
                      <Input
                        placeholder="Nova atividade..."
                        value={novaAtividadeFQ.descricao}
                        onChange={(e) => setNovaAtividadeFQ({ ...novaAtividadeFQ, descricao: e.target.value })}
                      />
                      <Input
                        placeholder="Responsável..."
                        value={novaAtividadeFQ.responsavel}
                        onChange={(e) => setNovaAtividadeFQ({ ...novaAtividadeFQ, responsavel: e.target.value })}
                      />
                      <Select
                        value={novaAtividadeFQ.turno}
                        onChange={(value) => setNovaAtividadeFQ({ ...novaAtividadeFQ, turno: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o turno" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="A">Turno A</SelectItem>
                          <SelectItem value="B">Turno B</SelectItem>
                          <SelectItem value="C">Turno C</SelectItem>
                          <SelectItem value="ADM">ADM</SelectItem>
                          <SelectItem value="TODOS">TODOS</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex justify-end">
                      <Button onClick={adicionarAtividadeFQ}>
                        <Plus className="h-4 w-4 mr-1" />
                        Adicionar
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-3">Atividades Operacionais</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                  <div>
                    <Label htmlFor="atividades-turno">Turno</Label>
                    <Select
                      value={atividadesOperacionais.turno}
                      onValueChange={(value) => setAtividadesOperacionais({ ...atividadesOperacionais, turno: value })}
                    >
                      <SelectTrigger id="atividades-turno">
                        <SelectValue placeholder="Selecione o turno" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A">TURNO A</SelectItem>
                        <SelectItem value="B">TURNO B</SelectItem>
                        <SelectItem value="C">TURNO C</SelectItem>
                        <SelectItem value="TODOS">TODOS</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="atividades-operador">Operador</Label>
                    <Input
                      id="atividades-operador"
                      placeholder="Nome do operador ou equipe"
                      value={atividadesOperacionais.operador}
                      onChange={(e) =>
                        setAtividadesOperacionais({ ...atividadesOperacionais, operador: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div className="border rounded-md p-4 mb-4">
                  <h4 className="text-sm font-medium mb-3">Atividades</h4>
                  <div className="space-y-3">
                    {atividadesOperacionais.itens.map((item) => (
                      <div key={item.id} className="border rounded-md p-3 relative">
                        <div className="flex justify-between items-start">
                          <div className="space-y-1 pr-32">
                            <Input
                              value={item.descricao}
                              onChange={(e) => {
                                setAtividadesOperacionais({
                                  ...atividadesOperacionais,
                                  itens: atividadesOperacionais.itens.map((i) =>
                                    i.id === item.id ? { ...i, descricao: e.target.value } : i,
                                  ),
                                })
                              }}
                            />
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <Label htmlFor={`resp-op-${item.id}`} className="text-xs">
                                  Responsável:
                                </Label>
                                <Input
                                  id={`resp-op-${item.id}`}
                                  value={item.responsavel}
                                  onChange={(e) => {
                                    setAtividadesOperacionais({
                                      ...atividadesOperacionais,
                                      itens: atividadesOperacionais.itens.map((i) =>
                                        i.id === item.id ? { ...i, responsavel: e.target.value } : i,
                                      ),
                                    })
                                  }}
                                  className="h-7 text-xs"
                                />
                              </div>
                              <div>
                                <Label htmlFor={`turno-op-${item.id}`} className="text-xs">
                                  Turno:
                                </Label>
                                <Select
                                  value={item.turno}
                                  onValueChange={(value: "A" | "B" | "C" | "ADM" | "TODOS") => {
                                    setAtividadesOperacionais({
                                      ...atividadesOperacionais,
                                      itens: atividadesOperacionais.itens.map((i) =>
                                        i.id === item.id ? { ...i, turno: value } : i,
                                      ),
                                    })
                                  }}
                                >
                                  <SelectTrigger id={`turno-op-${item.id}`} className="h-7 text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="A">Turno A</SelectItem>
                                    <SelectItem value="B">Turno B</SelectItem>
                                    <SelectItem value="C">Turno C</SelectItem>
                                    <SelectItem value="ADM">ADM</SelectItem>
                                    <SelectItem value="TODOS">TODOS</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            <div>
                              <Label htmlFor={`prazo-op-${item.id}`} className="text-xs">
                                Prazo:
                              </Label>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant={"outline"}
                                    className="w-full h-7 text-xs justify-start text-left font-normal"
                                  >
                                    <Clock className="mr-2 h-3 w-3" />
                                    {format(new Date(item.prazo), "PPP HH:mm", { locale: ptBR })}
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                  <CalendarUI
                                    mode="single"
                                    selected={new Date(item.prazo)}
                                    onSelect={(date) => {
                                      if (date) {
                                        const newDate = new Date(date)
                                        newDate.setHours(new Date(item.prazo).getHours())
                                        newDate.setMinutes(new Date(item.prazo).getMinutes())

                                        setAtividadesOperacionais({
                                          ...atividadesOperacionais,
                                          itens: atividadesOperacionais.itens.map((i) =>
                                            i.id === item.id ? { ...i, prazo: newDate } : i,
                                          ),
                                        })
                                      }
                                    }}
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                            </div>
                          </div>
                          <div className="absolute top-3 right-3 flex items-center gap-2">
                            <Select
                              value={item.status}
                              onValueChange={(value: "pendente" | "em_andamento" | "concluido" | "nao_realizado") => {
                                if (value === "nao_realizado") {
                                  setAtividadeEmEdicao(item)
                                  setTipoAtividadeEmEdicao("op")
                                  setDialogNaoRealizadoAberto(true)
                                  return
                                }

                                setAtividadesOperacionais({
                                  ...atividadesOperacionais,
                                  itens: atividadesOperacionais.itens.map((i) =>
                                    i.id === item.id ? { ...i, status: value, dataAtualizacao: new Date() } : i,
                                  ),
                                })
                              }}
                            >
                              <SelectTrigger className="w-36">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pendente">Pendente</SelectItem>
                                <SelectItem value="em_andamento">Em Andamento</SelectItem>
                                <SelectItem value="concluido">Concluído</SelectItem>
                                <SelectItem value="nao_realizado">Não Realizado</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button variant="ghost" size="icon" onClick={() => removerAtividadeOP(item.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-2">
                      <Input
                        placeholder="Nova atividade..."
                        value={novaAtividadeOP.descricao}
                        onChange={(e) => setNovaAtividadeOP({ ...novaAtividadeOP, descricao: e.target.value })}
                      />
                      <Input
                        placeholder="Responsável..."
                        value={novaAtividadeOP.responsavel}
                        onChange={(e) => setNovaAtividadeOP({ ...novaAtividadeOP, responsavel: e.target.value })}
                      />
                      <Select
                        value={novaAtividadeOP.turno}
                        onChange={(value) => setNovaAtividadeOP({ ...novaAtividadeOP, turno: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o turno" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="A">Turno A</SelectItem>
                          <SelectItem value="B">Turno B</SelectItem>
                          <SelectItem value="C">Turno C</SelectItem>
                          <SelectItem value="ADM">ADM</SelectItem>
                          <SelectItem value="TODOS">TODOS</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex justify-end">
                      <Button onClick={adicionarAtividadeOP}>
                        <Plus className="h-4 w-4 mr-1" />
                        Adicionar
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-medium">Ordens de Carregamento</h3>
                </div>

                {/* Lista de ordens existentes */}
                {ordensCarregamento.length > 0 && (
                  <div className="mb-6 space-y-3">
                    <h4 className="text-sm font-medium text-muted-foreground">Ordens Cadastradas</h4>
                    {ordensCarregamento.map((ordem) => (
                      <div key={ordem.id} className="border rounded-md p-3 relative">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="absolute top-2 right-2"
                          onClick={() => removerOrdem(ordem.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                        <div className="flex items-center justify-between mt-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium">Tanque:</span>
                              <span>{ordem.tanque}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">Destino:</span>
                              <span>{ordem.destino}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">Transportadora:</span>
                              <span>{ordem.transportadora}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">Turno:</span>
                              <span>Turno {ordem.turno}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">Status:</span>
                              <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(ordem.status)}`}>
                                {getStatusText(ordem.status)}
                              </span>
                            </div>
                            {ordem.motivoAlteracao && (
                              <div className="flex items-start gap-2">
                                <span className="font-medium">Motivo alteração:</span>
                                <span className="text-sm text-muted-foreground">{ordem.motivoAlteracao}</span>
                              </div>
                            )}
                            {ordem.motivoNaoRealizacao && (
                              <div className="flex items-start gap-2">
                                <span className="font-medium">Motivo não realização:</span>
                                <span className="text-sm text-red-500">{ordem.motivoNaoRealizacao}</span>
                              </div>
                            )}
                          </div>
                          <Button variant="outline" size="sm" onClick={() => editarOrdem(ordem)}>
                            <Edit className="h-3.5 w-3.5 mr-1" />
                            Editar Status
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Formulário para nova ordem */}
                <div className="border rounded-md p-4">
                  <h4 className="text-sm font-medium mb-3">Nova Ordem de Carregamento</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <Label htmlFor="tanque-carregamento">Tanque</Label>
                      <Input
                        id="tanque-carregamento"
                        placeholder="Nº TQ"
                        value={novaOrdem.tanque}
                        onChange={(e) => setNovaOrdem({ ...novaOrdem, tanque: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="destino-carregamento">Destino</Label>
                      <Input
                        id="destino-carregamento"
                        placeholder="Destino"
                        value={novaOrdem.destino}
                        onChange={(e) => setNovaOrdem({ ...novaOrdem, destino: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="transportadora">Transportadora</Label>
                      <Input
                        id="transportadora"
                        placeholder="Transportadora"
                        value={novaOrdem.transportadora}
                        onChange={(e) => setNovaOrdem({ ...novaOrdem, transportadora: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label htmlFor="turno-carregamento">Turno</Label>
                      <Select
                        value={novaOrdem.turno}
                        onChange={(value: "A" | "B" | "C" | "ADM") => setNovaOrdem({ ...novaOrdem, turno: value })}
                      >
                        <SelectTrigger id="turno-carregamento">
                          <SelectValue placeholder="Selecione o turno" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="A">Turno A</SelectItem>
                          <SelectItem value="B">Turno B</SelectItem>
                          <SelectItem value="C">Turno C</SelectItem>
                          <SelectItem value="ADM">ADM</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="status-carregamento">Status</Label>
                      <Select
                        value={novaOrdem.status}
                        onChange={(value: "pendente" | "em_andamento" | "concluido" | "nao_realizado") =>
                          setNovaOrdem({ ...novaOrdem, status: value })
                        }
                      >
                        <SelectTrigger id="status-carregamento">
                          <SelectValue placeholder="Selecione o status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pendente">Pendente</SelectItem>
                          <SelectItem value="em_andamento">Em Andamento</SelectItem>
                          <SelectItem value="concluido">Concluído</SelectItem>
                          <SelectItem value="nao_realizado">Não Realizado</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button onClick={handleSaveOrdem} className="w-full">
                    <Plus className="mr-2 h-4 w-4" />
                    Adicionar Ordem de Carregamento
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={() => setActiveTab("principal")} className="w-full">
                <CheckCircle2 className="mr-2 h-4 w-4" />
                Salvar e Voltar ao Painel
              </Button>
            </CardFooter>
          </Card>
          )
        </TabsContent>
      </Tabs>
      ;
      <Dialog open={dialogEditarAberto} onOpenChange={setDialogEditarAberto}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Status da Ordem</DialogTitle>
            <DialogDescription>
              Altere o status da ordem de carregamento e informe o motivo da alteração.
            </DialogDescription>
          </DialogHeader>
          {ordemEmEdicao && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-status">Status</Label>
                <Select
                  value={ordemEmEdicao.status}
                  onValueChange={(value: "pendente" | "em_andamento" | "concluido" | "nao_realizado") => {
                    setOrdemEmEdicao({ ...ordemEmEdicao, status: value })
                  }}
                >
                  <SelectTrigger id="edit-status">
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="em_andamento">Em Andamento</SelectItem>
                    <SelectItem value="concluido">Concluído</SelectItem>
                    <SelectItem value="nao_realizado">Não Realizado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {ordemEmEdicao.status === "nao_realizado" ? (
                <div className="space-y-2">
                  <Label htmlFor="motivo-nao-realizacao">Motivo da Não Realização</Label>
                  <Textarea
                    id="motivo-nao-realizacao"
                    placeholder="Informe o motivo da não realização..."
                    value={ordemEmEdicao.motivoNaoRealizacao || ""}
                    onChange={(e) => setOrdemEmEdicao({ ...ordemEmEdicao, motivoNaoRealizacao: e.target.value })}
                    rows={3}
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="motivo-alteracao">Motivo da Alteração</Label>
                  <Textarea
                    id="motivo-alteracao"
                    placeholder="Informe o motivo da alteração de status..."
                    value={motivoAlteracao}
                    onChange={(e) => setMotivoAlteracao(e.target.value)}
                    rows={3}
                  />
                </div>
              )}
              {ordemEmEdicao.status === "em_andamento" && (
                <div className="space-y-2">
                  <Label htmlFor="data-inicio">Data e Hora de Início</Label>
                  <Input
                    id="data-inicio"
                    type="datetime-local"
                    value={
                      ordemEmEdicao.dataInicio
                        ? format(new Date(ordemEmEdicao.dataInicio), "yyyy-MM-dd'T'HH:mm")
                        : format(new Date(), "yyyy-MM-dd'T'HH:mm")
                    }
                    onChange={(e) => {
                      const date = e.target.value ? new Date(e.target.value) : undefined
                      setOrdemEmEdicao({ ...ordemEmEdicao, dataInicio: date })
                    }}
                  />
                </div>
              )}
              {ordemEmEdicao.status === "concluido" && (
                <div className="space-y-2">
                  <Label htmlFor="data-fim">Data e Hora de Término</Label>
                  <Input
                    id="data-fim"
                    type="datetime-local"
                    value={
                      ordemEmEdicao.dataFim
                        ? format(new Date(ordemEmEdicao.dataFim), "yyyy-MM-dd'T'HH:mm")
                        : format(new Date(), "yyyy-MM-dd'T'HH:mm")
                    }
                    onChange={(e) => {
                      const date = e.target.value ? new Date(e.target.value) : undefined
                      setOrdemEmEdicao({ ...ordemEmEdicao, dataFim: date })
                    }}
                  />
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogEditarAberto(false)}>
              Cancelar
            </Button>
            <Button onClick={salvarEdicaoOrdem}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      ;
      <Dialog open={dialogNaoRealizadoAberto} onOpenChange={setDialogNaoRealizadoAberto}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Informar Motivo de Não Realização</DialogTitle>
            <DialogDescription>Informe o motivo pelo qual a atividade não foi realizada.</DialogDescription>
          </DialogHeader>
          {atividadeEmEdicao && (
            <div className="space-y-4 py-4">
              <div>
                <p className="font-medium">{atividadeEmEdicao.descricao}</p>
                <p className="text-sm text-muted-foreground">Responsável: {atividadeEmEdicao.responsavel}</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="motivo-nao-realizacao-atividade">Motivo</Label>
                <Textarea
                  id="motivo-nao-realizacao-atividade"
                  placeholder="Informe o motivo da não realização..."
                  value={atividadeEmEdicao.motivoNaoRealizacao || ""}
                  onChange={(e) => setAtividadeEmEdicao({ ...atividadeEmEdicao, motivoNaoRealizacao: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setDialogNaoRealizadoAberto(false)
                setAtividadeEmEdicao(null)
                setTipoAtividadeEmEdicao(null)
              }}
            >
              Cancelar
            </Button>
            <Button onClick={salvarMotivoNaoRealizacao}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
