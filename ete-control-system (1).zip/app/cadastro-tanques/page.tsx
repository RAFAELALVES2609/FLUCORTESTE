"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Edit, Plus, Save, Trash2 } from "lucide-react"

type Tanque = {
  id: string
  codigo: string
  nome: string
  capacidade: number
  processo: string
  status: string
}

export default function CadastroTanques() {
  const { toast } = useToast()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [processoFiltro, setProcessoFiltro] = useState("todos")
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [tanqueEmEdicao, setTanqueEmEdicao] = useState<Tanque | null>(null)

  const [novoTanque, setNovoTanque] = useState<Omit<Tanque, "id">>({
    codigo: "",
    nome: "",
    capacidade: 0,
    processo: "",
    status: "ativo",
  })

  const [tanques, setTanques] = useState<Tanque[]>([
    { id: "1", codigo: "TQ31", nome: "Tanque 31", capacidade: 5000, processo: "oleosos", status: "ativo" },
    { id: "2", codigo: "TQ32", nome: "Tanque 32", capacidade: 5000, processo: "oleosos", status: "ativo" },
    { id: "3", codigo: "TQ33", nome: "Tanque 33", capacidade: 5000, processo: "oleosos", status: "ativo" },
    { id: "4", codigo: "TQ34", nome: "Tanque 34", capacidade: 5000, processo: "oleosos", status: "ativo" },
    { id: "5", codigo: "TQ35", nome: "Tanque 35", capacidade: 5000, processo: "oleosos", status: "ativo" },
    { id: "6", codigo: "TQ41", nome: "Tanque 41", capacidade: 4000, processo: "fisico-quimico", status: "ativo" },
    { id: "7", codigo: "TQ42", nome: "Tanque 42", capacidade: 4000, processo: "fisico-quimico", status: "ativo" },
    { id: "8", codigo: "TQ43", nome: "Tanque 43", capacidade: 4000, processo: "fisico-quimico", status: "ativo" },
    { id: "9", codigo: "TQ44", nome: "Tanque 44", capacidade: 4000, processo: "fisico-quimico", status: "ativo" },
    { id: "10", codigo: "TQ51", nome: "Tanque 51", capacidade: 3000, processo: "fisico-quimico", status: "ativo" },
    { id: "11", codigo: "TQ52", nome: "Tanque 52", capacidade: 3000, processo: "fisico-quimico", status: "ativo" },
    { id: "12", codigo: "TQ53", nome: "Tanque 53", capacidade: 3000, processo: "fisico-quimico", status: "ativo" },
    { id: "13", codigo: "TQ61", nome: "Tanque 61", capacidade: 2000, processo: "concentrado", status: "ativo" },
    { id: "14", codigo: "TL01", nome: "Tanque Lodo 01", capacidade: 1500, processo: "lodo", status: "ativo" },
    { id: "15", codigo: "TL02", nome: "Tanque Lodo 02", capacidade: 1500, processo: "lodo", status: "ativo" },
    { id: "16", codigo: "TQ71", nome: "Tanque 71", capacidade: 3000, processo: "biologico", status: "ativo" },
    { id: "17", codigo: "TQ72", nome: "Tanque 72", capacidade: 3000, processo: "biologico", status: "ativo" },
    { id: "18", codigo: "TQ73", nome: "Tanque 73", capacidade: 2500, processo: "terciario", status: "ativo" },
    { id: "19", codigo: "TQ74", nome: "Tanque 74", capacidade: 2500, processo: "terciario", status: "ativo" },
    { id: "20", codigo: "TQ75", nome: "Tanque 75", capacidade: 2500, processo: "terciario", status: "ativo" },
  ])

  const adicionarTanque = () => {
    if (!novoTanque.codigo || !novoTanque.nome || !novoTanque.processo) {
      toast({
        title: "Erro ao adicionar tanque",
        description: "Código, nome e processo são obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const novoId = (tanques.length + 1).toString()
    const tanqueCompleto: Tanque = {
      id: novoId,
      codigo: novoTanque.codigo,
      nome: novoTanque.nome,
      capacidade: novoTanque.capacidade,
      processo: novoTanque.processo,
      status: novoTanque.status,
    }

    setTanques([...tanques, tanqueCompleto])
    setNovoTanque({
      codigo: "",
      nome: "",
      capacidade: 0,
      processo: "",
      status: "ativo",
    })
    setDialogOpen(false)

    toast({
      title: "Tanque adicionado",
      description: "O novo tanque foi adicionado com sucesso.",
    })
  }

  const editarTanque = (tanque: Tanque) => {
    setTanqueEmEdicao(tanque)
    setEditDialogOpen(true)
  }

  const salvarEdicaoTanque = () => {
    if (!tanqueEmEdicao) return

    setTanques(tanques.map((tanque) => (tanque.id === tanqueEmEdicao.id ? tanqueEmEdicao : tanque)))

    setEditDialogOpen(false)
    setTanqueEmEdicao(null)

    toast({
      title: "Tanque atualizado",
      description: "As informações do tanque foram atualizadas com sucesso.",
    })
  }

  const removerTanque = (id: string) => {
    setTanques(tanques.filter((tanque) => tanque.id !== id))

    toast({
      title: "Tanque removido",
      description: "O tanque foi removido com sucesso.",
    })
  }

  const salvarDados = () => {
    toast({
      title: "Dados salvos com sucesso!",
      description: "As informações dos tanques foram atualizadas.",
    })
  }

  const tanquesFiltrados =
    processoFiltro === "todos" ? tanques : tanques.filter((tanque) => tanque.processo === processoFiltro)

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Cadastro de Tanques</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="w-full md:w-1/2">
          <Label htmlFor="processo-filtro">Filtrar por Processo</Label>
          <Select value={processoFiltro} onValueChange={setProcessoFiltro}>
            <SelectTrigger id="processo-filtro">
              <SelectValue placeholder="Selecione o processo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Processos</SelectItem>
              <SelectItem value="oleosos">Oleosos</SelectItem>
              <SelectItem value="fisico-quimico">Físico Químico</SelectItem>
              <SelectItem value="concentrado">Concentrado/Beneficiamento</SelectItem>
              <SelectItem value="lodo">Tratamento de Lodo</SelectItem>
              <SelectItem value="biologico">Tratamento Biológico</SelectItem>
              <SelectItem value="terciario">Tratamento Terciário/Polimento</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="w-full md:w-1/2 flex items-end gap-4">
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex-1">
                <Plus className="mr-2 h-4 w-4" />
                Novo Tanque
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar Novo Tanque</DialogTitle>
                <DialogDescription>Preencha as informações do novo tanque para adicionar ao sistema.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="codigo-tanque">Código</Label>
                    <Input
                      id="codigo-tanque"
                      value={novoTanque.codigo}
                      onChange={(e) => setNovoTanque({ ...novoTanque, codigo: e.target.value })}
                      placeholder="Ex: TQ80"
                    />
                  </div>
                  <div>
                    <Label htmlFor="capacidade-tanque">Capacidade (m³)</Label>
                    <Input
                      id="capacidade-tanque"
                      type="number"
                      value={novoTanque.capacidade}
                      onChange={(e) => setNovoTanque({ ...novoTanque, capacidade: Number(e.target.value) })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="nome-tanque">Nome</Label>
                  <Input
                    id="nome-tanque"
                    value={novoTanque.nome}
                    onChange={(e) => setNovoTanque({ ...novoTanque, nome: e.target.value })}
                    placeholder="Nome do tanque"
                  />
                </div>
                <div>
                  <Label htmlFor="processo-tanque">Processo</Label>
                  <Select
                    value={novoTanque.processo}
                    onValueChange={(value) => setNovoTanque({ ...novoTanque, processo: value })}
                  >
                    <SelectTrigger id="processo-tanque">
                      <SelectValue placeholder="Selecione o processo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="oleosos">Oleosos</SelectItem>
                      <SelectItem value="fisico-quimico">Físico Químico</SelectItem>
                      <SelectItem value="concentrado">Concentrado/Beneficiamento</SelectItem>
                      <SelectItem value="lodo">Tratamento de Lodo</SelectItem>
                      <SelectItem value="biologico">Tratamento Biológico</SelectItem>
                      <SelectItem value="terciario">Tratamento Terciário/Polimento</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="status-tanque">Status</Label>
                  <Select
                    value={novoTanque.status}
                    onValueChange={(value) => setNovoTanque({ ...novoTanque, status: value })}
                  >
                    <SelectTrigger id="status-tanque">
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                      <SelectItem value="manutencao">Em Manutenção</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={adicionarTanque}>Adicionar Tanque</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Button variant="outline" onClick={salvarDados} className="flex-1">
            <Save className="mr-2 h-4 w-4" />
            Salvar Alterações
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Tanques</CardTitle>
          <CardDescription>
            {processoFiltro === "todos" ? "Todos os tanques cadastrados" : `Tanques do processo: ${processoFiltro}`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Nome</TableHead>
                <TableHead>Capacidade (m³)</TableHead>
                <TableHead>Processo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tanquesFiltrados.map((tanque) => (
                <TableRow key={tanque.id}>
                  <TableCell className="font-medium">{tanque.codigo}</TableCell>
                  <TableCell>{tanque.nome}</TableCell>
                  <TableCell>{tanque.capacidade}</TableCell>
                  <TableCell>
                    {tanque.processo === "oleosos" && "Oleosos"}
                    {tanque.processo === "fisico-quimico" && "Físico Químico"}
                    {tanque.processo === "concentrado" && "Concentrado/Beneficiamento"}
                    {tanque.processo === "lodo" && "Tratamento de Lodo"}
                    {tanque.processo === "biologico" && "Tratamento Biológico"}
                    {tanque.processo === "terciario" && "Tratamento Terciário/Polimento"}
                  </TableCell>
                  <TableCell>
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        tanque.status === "ativo"
                          ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
                          : tanque.status === "inativo"
                            ? "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
                            : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
                      }`}
                    >
                      {tanque.status === "ativo" && "Ativo"}
                      {tanque.status === "inativo" && "Inativo"}
                      {tanque.status === "manutencao" && "Em Manutenção"}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" onClick={() => editarTanque(tanque)}>
                        <Edit className="h-4 w-4 text-blue-500" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => removerTanque(tanque.id)}>
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Dialog para editar tanque */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Tanque</DialogTitle>
            <DialogDescription>Atualize as informações do tanque.</DialogDescription>
          </DialogHeader>
          {tanqueEmEdicao && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-codigo">Código</Label>
                  <Input
                    id="edit-codigo"
                    value={tanqueEmEdicao.codigo}
                    onChange={(e) => setTanqueEmEdicao({ ...tanqueEmEdicao, codigo: e.target.value })}
                    disabled
                  />
                </div>
                <div>
                  <Label htmlFor="edit-capacidade">Capacidade (m³)</Label>
                  <Input
                    id="edit-capacidade"
                    type="number"
                    value={tanqueEmEdicao.capacidade}
                    onChange={(e) => setTanqueEmEdicao({ ...tanqueEmEdicao, capacidade: Number(e.target.value) })}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="edit-nome">Nome</Label>
                <Input
                  id="edit-nome"
                  value={tanqueEmEdicao.nome}
                  onChange={(e) => setTanqueEmEdicao({ ...tanqueEmEdicao, nome: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="edit-processo">Processo</Label>
                <Select
                  value={tanqueEmEdicao.processo}
                  onValueChange={(value) => setTanqueEmEdicao({ ...tanqueEmEdicao, processo: value })}
                >
                  <SelectTrigger id="edit-processo">
                    <SelectValue placeholder="Selecione o processo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="oleosos">Oleosos</SelectItem>
                    <SelectItem value="fisico-quimico">Físico Químico</SelectItem>
                    <SelectItem value="concentrado">Concentrado/Beneficiamento</SelectItem>
                    <SelectItem value="lodo">Tratamento de Lodo</SelectItem>
                    <SelectItem value="biologico">Tratamento Biológico</SelectItem>
                    <SelectItem value="terciario">Tratamento Terciário/Polimento</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="edit-status">Status</Label>
                <Select
                  value={tanqueEmEdicao.status}
                  onValueChange={(value) => setTanqueEmEdicao({ ...tanqueEmEdicao, status: value })}
                >
                  <SelectTrigger id="edit-status">
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ativo">Ativo</SelectItem>
                    <SelectItem value="inativo">Inativo</SelectItem>
                    <SelectItem value="manutencao">Em Manutenção</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={salvarEdicaoTanque}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
